-- Block Blast для BlockPhone
-- Управление: нажми на фигуру снизу, затем на клетку поля,
-- чтобы поставить её левым верхним углом в выбранную клетку.
-- Бомба покупается за очки и взрывает область 3×3 вокруг выбранной клетки.

local N = 8
local CELL = 14
local GAP = 2
local BOARD_X = 23
local BOARD_Y = 48
local BOARD_SIZE = N * (CELL + GAP) - GAP

local TRAY_Y = 218
local TRAY_X = {12, 61, 110}
local PREVIEW_CELL = 7
local PREVIEW_GAP = 2

local COLORS = {
  "#42D6B5", "#58A6FF", "#FFB84D", "#C084FC",
  "#FF6B8A", "#F5D76E", "#6EDB76"
}
local BG = "#101521"
local PANEL = "#1B2434"
local EMPTY = "#263246"
local TEXT = "#F4F7FB"
local MUTED = "#A8B3C7"
local ACCENT = "#42D6B5"
local PREVIEW_OK = "#55E6A5"
local PREVIEW_BAD = "#FF2038"

local BOMB_COST = 150

local SHAPES = {
  {{0,0}},
  {{0,0},{1,0}},
  {{0,0},{0,1}},
  {{0,0},{1,0},{2,0}},
  {{0,0},{0,1},{0,2}},
  {{0,0},{1,0},{2,0},{3,0}},
  {{0,0},{0,1},{0,2},{0,3}},
  {{0,0},{1,0},{0,1},{1,1}},
  {{0,0},{1,0},{2,0},{0,1}},
  {{0,0},{1,0},{2,0},{2,1}},
  {{0,0},{0,1},{1,1},{2,1}},
  {{1,0},{0,1},{1,1},{2,1}},
  {{0,0},{0,1},{0,2},{1,2}},
  {{1,0},{1,1},{0,2},{1,2}},
  {{0,0},{1,0},{1,1},{2,1}},
  {{1,0},{2,0},{0,1},{1,1}},
  {{0,0},{1,0},{2,0},{1,1},{1,2}},
  {{0,0},{1,0},{2,0},{0,1},{2,1},{1,2}}
}

local board = {}
local pieces = {}
local score = 0
local best = 0
local bestCombo = 0
local selected = 0
local gameOver = false
local dragging = false
local dragX, dragY = 0, 0

local comboStreak = 0
local floating = {}

local bombMode = false

local function newBoard()
  board = {}
  for y = 1, N do
    board[y] = {}
    for x = 1, N do board[y][x] = false end
  end
end

local function randomPiece()
  local shape = SHAPES[math.random(1, #SHAPES)]
  local cells = {}
  local maxX, maxY = 0, 0
  for i, p in ipairs(shape) do
    cells[i] = {p[1], p[2]}
    if p[1] > maxX then maxX = p[1] end
    if p[2] > maxY then maxY = p[2] end
  end
  return {cells = cells, w = maxX + 1, h = maxY + 1,
          color = COLORS[math.random(1, #COLORS)]}
end

local function newPieces()
  pieces = {randomPiece(), randomPiece(), randomPiece()}
  selected = 0
end

local function fits(piece, gx, gy)
  if not piece then return false end
  for _, p in ipairs(piece.cells) do
    local x, y = gx + p[1], gy + p[2]
    if x < 1 or x > N or y < 1 or y > N then return false end
    if board[y][x] then return false end
  end
  return true
end

local function canAnyPieceFit()
  for i = 1, 3 do
    local piece = pieces[i]
    if piece then
      for y = 1, N do
        for x = 1, N do
          if fits(piece, x, y) then return true end
        end
      end
    end
  end
  return false
end

local function checkGameOver()
  gameOver = not canAnyPieceFit()
end

local function addFloat(text, x, y, color, scale)
  table.insert(floating, {
    text = text, x = x, y = y, life = 1.2,
    color = color or "#FFFFFF", scale = scale or 1.0
  })
end

local function clearLines()
  local rows, cols = {}, {}
  for y = 1, N do
    local full = true
    for x = 1, N do if not board[y][x] then full = false; break end end
    if full then rows[y] = true end
  end
  for x = 1, N do
    local full = true
    for y = 1, N do if not board[y][x] then full = false; break end end
    if full then cols[x] = true end
  end

  local count = 0
  for y = 1, N do
    if rows[y] then
      count = count + 1
      for x = 1, N do board[y][x] = false end
    end
  end
  for x = 1, N do
    if cols[x] then
      count = count + 1
      for y = 1, N do board[y][x] = false end
    end
  end

  if count > 0 then
    comboStreak = comboStreak + 1
    if comboStreak > bestCombo then
      bestCombo = comboStreak
      storage.set("best_combo", bestCombo)
    end

    local base = count * (count + 1) / 2 * 10
    local multiplier = math.min(comboStreak, 5)
    local gained = math.floor(base * multiplier)

    score = score + gained
    if score > best then
      best = score
      storage.set("best_score", best)
    end

    local cx = BOARD_X + BOARD_SIZE / 2
    local cy = BOARD_Y + BOARD_SIZE / 2
    addFloat("+" .. gained, cx, cy, "#F5D76E", 1.3)
    if comboStreak >= 2 then
      addFloat("COMBO x" .. comboStreak .. "!", cx, cy - 14, "#FF6B8A", 1.1)
    end
    if count >= 3 then
      addFloat(count .. " LINES!", cx, cy + 12, "#42D6B5", 1.0)
    end

    pcall(function() sound.play("entity.experience_orb.pickup", 0.7) end)
    if count >= 2 then
      pcall(function() sound.play("entity.player.levelup", 0.5) end)
    end
  else
    comboStreak = 0
  end

  return count
end

local function restart()
  newBoard()
  score = 0
  comboStreak = 0
  gameOver = false
  dragging = false
  bombMode = false
  selected = 0
  floating = {}
  newPieces()
end

local function explode(cx, cy, radius)
  local cleared = 0
  for y = cy - radius, cy + radius do
    for x = cx - radius, cx + radius do
      if x >= 1 and x <= N and y >= 1 and y <= N then
        if board[y][x] then
          board[y][x] = false
          cleared = cleared + 1
        end
      end
    end
  end
  return cleared
end

local function useBomb(gx, gy)
  local cleared = explode(gx, gy, 1)
  score = score + cleared * 5
  if score > best then
    best = score
    storage.set("best_score", best)
  end
  local px = BOARD_X + (gx - 1) * (CELL + GAP) + CELL / 2
  local py = BOARD_Y + (gy - 1) * (CELL + GAP) + CELL / 2
  addFloat("BOOM!", px, py, "#FF4D4D", 1.4)
  if cleared > 0 then
    addFloat("+" .. (cleared * 5), px, py - 12, "#F5D76E", 1.0)
  end
  pcall(function() sound.play("entity.generic.explode", 0.7) end)
  bombMode = false
  clearLines()
  checkGameOver()
end

local function buyBomb()
  if bombMode then
    toast("Бомба уже выбрана — тапни по полю")
    return
  end
  if score < BOMB_COST then
    toast("Нужно " .. BOMB_COST .. " очков")
    return
  end
  score = score - BOMB_COST
  bombMode = true
  selected = 0
  dragging = false
  pcall(function() sound.play("ui.button.click", 0.6) end)
end

local function placeSelected(gx, gy)
  local piece = pieces[selected]
  if not piece then return end
  if not fits(piece, gx, gy) then
    toast("Сюда поставить нельзя")
    return
  end
  for _, p in ipairs(piece.cells) do
    board[gy + p[2]][gx + p[1]] = piece.color
  end
  score = score + #piece.cells
  if score > best then
    best = score
    storage.set("best_score", best)
  end
  pieces[selected] = nil
  selected = 0
  clearLines()

  local empty = true
  for i = 1, 3 do if pieces[i] then empty = false end end
  if empty then newPieces() end
  checkGameOver()
  if gameOver then
    pcall(function() sound.play("entity.player.levelup", 0.8) end)
  end
end

function onStart()
  math.randomseed(time.now())
  best = tonumber(storage.get("best_score", 0)) or 0
  bestCombo = tonumber(storage.get("best_combo", 0)) or 0
  screen.title("Block Blast")
  screen.fullscreen(true)
  screen.captureKeys(true)
  restart()
end

function onShow()
  screen.captureKeys(true)
end

function onTick()
  local dt = 1 / 20
  local i = 1
  while i <= #floating do
    local f = floating[i]
    f.life = f.life - dt
    f.y = f.y - 20 * dt
    if f.life <= 0 then
      table.remove(floating, i)
    else
      i = i + 1
    end
  end
end

local function drawPreviewCell(px, py, fillColor, borderColor)
  gfx.roundRect(px, py, CELL, CELL, 2, fillColor)
  gfx.border(px, py, CELL, CELL, 2, borderColor)
  gfx.border(px + 1, py + 1, CELL - 2, CELL - 2, 2, borderColor)
end

function onDraw(dt)
  gfx.clear(BG)
  local sw, sh = screen.width(), screen.height()

  -- Верхняя панель
  gfx.textCenter("BLOCK BLAST", sw / 2, 6, ACCENT, 1.15, true)
  gfx.text("СЧЁТ", 12, 22, MUTED, 0.6)
  gfx.text(tostring(score), 12, 29, TEXT, 1.05, true)
  gfx.text("РЕКОРД", sw - 58, 22, MUTED, 0.6)
  gfx.text(tostring(best), sw - 58, 29, TEXT, 1.05, true)
  if bestCombo > 0 then
    gfx.textCenter("макс. комбо x" .. bestCombo, sw / 2, 22, MUTED, 0.55)
  end

  -- Поле
  gfx.roundRect(BOARD_X - 5, BOARD_Y - 5, BOARD_SIZE + 10, BOARD_SIZE + 10, 7, PANEL)
  for y = 1, N do
    for x = 1, N do
      local px = BOARD_X + (x - 1) * (CELL + GAP)
      local py = BOARD_Y + (y - 1) * (CELL + GAP)
      local c = board[y][x] or EMPTY
      gfx.roundRect(px, py, CELL, CELL, 2, c)
    end
  end

  -- Предпросмотр / режим бомбы
  if bombMode then
    local mx, my = input.mouse()
    local gx = math.floor((mx - BOARD_X) / (CELL + GAP)) + 1
    local gy = math.floor((my - BOARD_Y) / (CELL + GAP)) + 1
    if gx >= 1 and gx <= N and gy >= 1 and gy <= N then
      local bx0 = math.max(1, gx - 1)
      local by0 = math.max(1, gy - 1)
      local bx1 = math.min(N, gx + 1)
      local by1 = math.min(N, gy + 1)
      local px = BOARD_X + (bx0 - 1) * (CELL + GAP)
      local py = BOARD_Y + (by0 - 1) * (CELL + GAP)
      local pw = (bx1 - bx0 + 1) * (CELL + GAP) - GAP
      local ph = (by1 - by0 + 1) * (CELL + GAP) - GAP
      gfx.rect(px, py, pw, ph, "#40FF4D4D")
      gfx.border(px - 1, py - 1, pw + 2, ph + 2, 2, "#FF4D4D")
    end
    gfx.textCenter("Тапни по полю — взорвётся 3×3", sw / 2, 178, "#FF4D4D", 0.72)
  elseif selected > 0 and pieces[selected] then
    local mx, my = input.mouse()
    if dragging then mx, my = dragX, dragY end
    local gx = math.floor((mx - BOARD_X) / (CELL + GAP)) + 1
    local gy = math.floor((my - BOARD_Y) / (CELL + GAP)) + 1
    if gx >= 1 and gx <= N and gy >= 1 and gy <= N then
      local piece = pieces[selected]
      local valid = fits(piece, gx, gy)
      local previewColor = valid and PREVIEW_OK or PREVIEW_BAD
      for _, p in ipairs(piece.cells) do
        local bx, by = gx + p[1], gy + p[2]
        if bx >= 1 and bx <= N and by >= 1 and by <= N then
          local px = BOARD_X + (bx - 1) * (CELL + GAP)
          local py = BOARD_Y + (by - 1) * (CELL + GAP)
          drawPreviewCell(px, py, previewColor, "#FFFFFF")
        end
      end
    end
    gfx.textCenter(dragging and "Перетащи на поле и отпусти" or "Наведи на поле для предпросмотра",
      sw / 2, 178, ACCENT, 0.7)
  else
    gfx.textCenter("Выбери фигуру", sw / 2, 178, MUTED, 0.7)
  end

  -- Всплывающие надписи
  for _, f in ipairs(floating) do
    local alpha = math.min(1, f.life)
    local col = f.color
    if alpha < 1 then col = MUTED end
    gfx.textCenter(f.text, f.x, f.y, col, f.scale * (0.7 + 0.3 * alpha), true)
  end

  -- Кнопка покупки бомбы (справа, над лотком)
  if not gameOver then
    local bw, bh = 56, 18
    local bx, by = sw - bw - 10, TRAY_Y - 34
    local style = bombMode and "selected" or (score >= BOMB_COST and "primary" or "normal")
    local label = bombMode and "Бомба!" or ("Бомба " .. BOMB_COST)
    if ui.button(bx, by, bw, bh, label, style) then
      if bombMode then
        bombMode = false
        toast("Бомба отменена")
      else
        buyBomb()
      end
    end
  end

  -- Три фигуры в нижней части экрана
  for i = 1, 3 do
    local x0 = TRAY_X[i]
    local piece = pieces[i]
    if selected == i then
      gfx.roundRect(x0 - 5, TRAY_Y - 8, 39, 48, 5, "#304B50")
      gfx.border(x0 - 5, TRAY_Y - 8, 39, 48, 5, ACCENT)
    else
      gfx.roundRect(x0 - 5, TRAY_Y - 8, 39, 48, 5, PANEL)
    end
    if piece then
      local pw = piece.w * (PREVIEW_CELL + PREVIEW_GAP) - PREVIEW_GAP
      local ph = piece.h * (PREVIEW_CELL + PREVIEW_GAP) - PREVIEW_GAP
      local sx = x0 + (29 - pw) / 2
      local sy = TRAY_Y + (30 - ph) / 2
      for _, p in ipairs(piece.cells) do
        gfx.roundRect(sx + p[1] * (PREVIEW_CELL + PREVIEW_GAP),
          sy + p[2] * (PREVIEW_CELL + PREVIEW_GAP),
          PREVIEW_CELL, PREVIEW_CELL, 1.5, piece.color)
      end
    else
      gfx.textCenter("✓", x0 + 14, TRAY_Y + 7, MUTED, 1.1)
    end
  end

  -- Полоска комбо-серии
  if comboStreak >= 2 then
    gfx.textCenter("КОМБО x" .. comboStreak, sw / 2, 204, "#FF6B8A", 0.85, true)
  end

  -- Кнопка новой игры
  if ui.button(sw / 2 - 43, sh - 28, 86, 21, "Новая игра", "primary") then
    restart()
  end

  if gameOver then
    gfx.rect(0, 0, sw, sh, "#B8101521")
    gfx.roundRect(13, sh / 2 - 52, sw - 26, 104, 9, PANEL)
    gfx.textCenter("ИГРА ОКОНЧЕНА", sw / 2, sh / 2 - 38, "#FF6B8A", 1.05, true)
    gfx.textCenter("Счёт: " .. score, sw / 2, sh / 2 - 18, TEXT, 0.9)
    gfx.textCenter("Рекорд: " .. best, sw / 2, sh / 2 - 5, MUTED, 0.75)
    if bestCombo > 0 then
      gfx.textCenter("Лучшее комбо: x" .. bestCombo, sw / 2, sh / 2 + 7, MUTED, 0.7)
    end
    if ui.button(sw / 2 - 42, sh / 2 + 20, 84, 19, "Ещё раз", "primary") then
      restart()
    end
  end
end

function onClick(x, y, button)
  if button ~= 1 then return end
  local sw, sh = screen.width(), screen.height()

  if gameOver then
    if x >= sw / 2 - 48 and x <= sw / 2 + 48 and
       y >= sh / 2 + 15 and y <= sh / 2 + 43 then
      restart()
    end
    return
  end

  -- Новая игра
  if x >= sw / 2 - 48 and x <= sw / 2 + 48 and y >= sh - 32 then
    restart()
    return
  end

  -- Режим бомбы: тап по полю = взрыв
  if bombMode then
    if x >= BOARD_X and x < BOARD_X + BOARD_SIZE and
       y >= BOARD_Y and y < BOARD_Y + BOARD_SIZE then
      local gx = math.floor((x - BOARD_X) / (CELL + GAP)) + 1
      local gy = math.floor((y - BOARD_Y) / (CELL + GAP)) + 1
      if gx >= 1 and gx <= N and gy >= 1 and gy <= N then
        useBomb(gx, gy)
      end
      return
    end
  end

  -- Выбор фигуры и начало перетаскивания
  if y >= TRAY_Y - 10 and y <= TRAY_Y + 43 then
    for i = 1, 3 do
      if x >= TRAY_X[i] - 6 and x <= TRAY_X[i] + 34 and pieces[i] then
        selected = i
        dragging = true
        dragX, dragY = x, y
        pcall(function() sound.play("ui.button.click", 0.5) end)
        return
      end
    end
  end

  -- Альтернатива: выбери фигуру и нажми клетку поля
  if selected > 0 and x >= BOARD_X and y >= BOARD_Y then
    local gx = math.floor((x - BOARD_X) / (CELL + GAP)) + 1
    local gy = math.floor((y - BOARD_Y) / (CELL + GAP)) + 1
    if gx >= 1 and gx <= N and gy >= 1 and gy <= N then
      placeSelected(gx, gy)
      dragging = false
    end
  end
end

function onDrag(x, y, dx, dy)
  if dragging then
    dragX, dragY = x, y
  end
end

function onRelease(x, y, button)
  if button ~= 1 or not dragging then return end
  dragX, dragY = x, y
  dragging = false

  if gameOver or bombMode or selected <= 0 or not pieces[selected] then return end

  if x >= BOARD_X and x < BOARD_X + BOARD_SIZE and
     y >= BOARD_Y and y < BOARD_Y + BOARD_SIZE then
    local gx = math.floor((x - BOARD_X) / (CELL + GAP)) + 1
    local gy = math.floor((y - BOARD_Y) / (CELL + GAP)) + 1
    if fits(pieces[selected], gx, gy) then
      placeSelected(gx, gy)
    else
      toast("Сюда поставить нельзя")
    end
  end
end

function onKey(name)
  if name == "escape" or name == "back" then
    return false
  end
  if name == "r" then
    restart()
    return true
  end
  return false
end

function onBack()
  return false
end