-- Оружие от первого лица: 3D-модели guns.lua (kit.lua) и руки — блочные, как в Minecraft: брусок 4×12×4 со скином
-- агента (рука + рукав внешнего слоя), конец бруска — кисть у рукояти и у цевья. Модель рисуется в том же 3D-кадре, что и мир, но очень близко к глазу и уменьшенной (масштаб S): так она
-- не уходит в стены (игрок не подходит к стене ближе 0,25), а на экране выглядит обычного размера.
-- Единицы модели — метры: +Z вперёд (дуло), +Y вверх, +X вправо; начало координат — у спускового крючка.
local D = require("data")
local K = require("kit")
local GUNS = require("guns")

local VM = {}
-- Поворот и сдвиг оружия у глаза (общие для всех моделей): видно правый бок, дуло смотрит к прицелу.
VM.TUNE = {yaw = -4, pitch = 1, roll = -4, dx = 0.075, dy = -0.008, dz = 0.2}
-- Добавки по виду оружия: пистолеты и нож ближе и повёрнуты боком (видно затвор), гранаты — ближе.
VM.KIND = {pistol = {yaw = -16, dx = 0.012, dy = -0.005, dz = -0.11}, knife = {yaw = -6, dz = -0.08}, nade = {dz = -0.08}, zeus = {yaw = -16, dx = 0.012, dz = -0.11},
  c4 = {dz = -0.06}}
VM.FOVK = 1.6 -- tan(fov мира / 2) / tan(fov рук / 2)
local sin, cos, rad, sqrt, min, max, abs = math.sin, math.cos, math.rad, math.sqrt, math.min, math.max, math.abs

local S = 0.25 -- во сколько раз модель меньше «настоящей»

-- --- Сборка ---

local cache, worldCache = {}, {}

local function model(key) return GUNS[key] or GUNS.knife end

local function build(key, team)
  local id = key .. team
  if cache[id] then return cache[id] end
  local mdl = model(key)
  local m = K.new()
  mdl.build(m)
  cache[id] = {mesh = K.finish(m), mdl = mdl}
  return cache[id]
end

-- Для стенда: модель с руками (сетка).
function VM.debugBuild(key, team) return build(key, team).mesh end

-- Модель без рук — в руках у других игроков и на земле (render.lua).
function VM.worldModel(key)
  local id = worldCache[key]
  if id then return id end
  local m = K.new()
  model(key).build(m)
  id = K.finish(m)
  worldCache[key] = id
  return id
end

function VM.init()
  VM.tex = g3d.texture("textures/kit_atlas.png", {mipmap = false})
  VM.flashTex = g3d.texture("textures/muzzle.png")
end

-- Точка модели (в метрах, относительно глаза) → мир.
-- Блочная рука Minecraft (сетки и скины даёт render.lua: VM.arm, VM.sleeve, VM.skins[команда]).
-- Кисть — в точке hand (мир), локоть — elbow: брусок идёт от кисти назад через локоть и дальше за край экрана.
local ARM_PX = 1 / 32
VM.ARM_W = 0.62   -- толщина бруска (доля от размера руки агента)
VM.ARM_LEN = 1.35 -- длина: от кисти до локтя × это
local function blockArm(hx, hy, hz, ex, ey, ez, scale, team, flip, thin)
  if not VM.arm then return end
  local dx, dy, dz = hx - ex, hy - ey, hz - ez
  local l = sqrt(dx * dx + dy * dy + dz * dz)
  if l < 1e-6 then return end
  dx, dy, dz = dx / l, dy / l, dz / l
  -- ось Y бруска — от кисти к плечу, «перед» (+Z) — по возможности вверх (как у руки, вытянутой вперёд)
  local yx, yy, yz = -dx, -dy, -dz
  local ux, uy, uz = 0, 1, 0
  local dot = ux * yx + uy * yy + uz * yz
  local zx, zy, zz = ux - dot * yx, uy - dot * yy, uz - dot * yz
  local zl = sqrt(zx * zx + zy * zy + zz * zz)
  if zl < 1e-4 then zx, zy, zz, zl = 0, 0, 1, 1 end
  zx, zy, zz = zx / zl, zy / zl, zz / zl
  local xx, xy, xz = yy * zz - yz * zy, yz * zx - yx * zz, yx * zy - yy * zx
  local yaw, pitch, roll = K.toEuler({xx, yx, zx, xy, yy, zy, xz, yz, zz})
  local sy = l * VM.ARM_LEN / (12 * ARM_PX)
  local sw = scale * VM.ARM_W * (thin or 1)
  -- в сетке кисть — низ бруска (y = −10 «пикселей»), плечо — y = +2: начало сетки — на 10 «пикселей» выше кисти
  local o = 10 * ARM_PX * sy
  local px, py, pz = hx + yx * o, hy + yy * o, hz + yz * o
  local opt = {yaw = yaw, pitch = pitch, roll = roll, sx = flip and -sw or sw, sy = sy, sz = sw, texture = VM.skins[team]}
  g3d.draw(VM.arm, px, py, pz, opt)
  if VM.sleeve then g3d.draw(VM.sleeve, px, py, pz, opt) end
end

local function toWorld(cam, yaw, pitch, roll, ox, oy, oz)
  local R = K.euler(yaw, pitch, roll)
  local x, y, z = K.apply(R, ox, oy, oz)
  return cam.x + x * S, cam.y + y * S, cam.z + z * S
end

-- Нарисовать оружие в руках (своё или того, за кем наблюдаем). me — состояние: wpn, vx, vz, walkT, cool, switchT,
-- reload, reloadFor, nadeCool, crouch, flashT. team — цвет рукавов.
function VM.draw(cam, me, team, now)
  local w = D.WEAPONS[me.wpn] or D.WEAPONS[1]
  local entry = build(w.key, team)
  local mdl = entry.mdl
  local sp = sqrt((me.vx or 0) ^ 2 + (me.vz or 0) ^ 2)
  local walk = VM.bob == false and 0 or min(1, sp / 3)
  local wt = me.walkT or 0
  -- покачивание при ходьбе (восьмёрка), отдача, смена оружия, перезарядка, бросок гранаты, удар ножом
  local bx = sin(wt * 3.2) * 0.012 * walk
  local by = -abs(cos(wt * 3.2)) * 0.01 * walk
  local tn = VM.tune or VM.TUNE
  local kd = VM.KIND[mdl.kind] or {}
  local px = mdl.pos[1] + bx + tn.dx + (kd.dx or 0)
  local py = mdl.pos[2] + by + tn.dy + (kd.dy or 0)
  local pz = mdl.pos[3] + tn.dz + (kd.dz or 0)
  local pitch, yaw, roll = tn.pitch or 0, tn.yaw + (kd.yaw or 0), sin(wt * 3.2) * 1.5 * walk + (tn.roll or 0)
  local cool = me.cool or 0
  if w.clip and cool > 0 then
    local k = cool / w.cool
    k = k * k
    pz = pz - 0.04 * k * min(2, 0.6 + w.recoil * 0.3)
    pitch = pitch + 4 * k * min(2, 0.5 + w.recoil * 0.25)
  end
  if (me.switchT or 0) > 0 then
    local k = me.switchT / 0.35
    py = py - 0.25 * k
    pitch = pitch - 30 * k
  end
  if (me.reload or 0) > 0 then
    local wr = D.WEAPONS[me.reloadFor] or w
    local k = sin(math.pi * (1 - me.reload / (wr.reload or 1)))
    py = py - 0.07 * k
    pitch = pitch - 18 * k
    roll = roll + 28 * k
    px = px - 0.03 * k
  end
  if mdl.kind == "knife" and cool > 0 then
    local k = sin(math.pi * (1 - cool / w.cool))
    px, pz = px - 0.08 * k, pz + 0.12 * k
    yaw, pitch = yaw + 35 * k, pitch - 15 * k
  end
  if mdl.kind == "nade" and (me.nadeCool or 0) > 0 then
    local k = sin(math.pi * (1 - me.nadeCool / 0.8))
    py, pz = py + 0.08 * k, pz + 0.1 * k
    pitch = pitch + 30 * k
  end
  if me.crouch then py = py + 0.01 end
  local gyaw, gpitch = cam.yaw + yaw, max(-89, min(89, cam.pitch + pitch))
  -- Свой «угол обзора» для рук, уже, чем у мира (как viewmodel_fov в CS): модель дальше от глаза и шире по X/Y —
  -- на экране того же размера, но без сильной перспективы (задняя часть не раздувается и не уходит за край экрана).
  local k = VM.FOVK
  local function one(mirror)
    local ox = mirror and -px or px
    local wx, wy, wz = toWorld(cam, cam.yaw, cam.pitch, 0, ox * k, py * k, pz * k)
    local r = mirror and -roll or roll
    local myaw = gyaw + (mirror and 3 or 0)
    g3d.draw(entry.mesh, wx, wy, wz, {yaw = myaw, pitch = gpitch, roll = r,
      sx = (mirror and -S or S) * k, sy = S * k, sz = S, texture = VM.tex})
    -- руки: точки модели (хват, цевьё, локти) → мир с тем же поворотом и масштабом, что у оружия
    local Rg = K.euler(myaw, gpitch, r)
    local sg = mirror and -1 or 1
    local function pt(q)
      local x, y, z = K.apply(Rg, sg * q[1] * k * S, q[2] * k * S, q[3] * S)
      return wx + x, wy + y, wz + z
    end
    local g = mdl.grip
    local kind = mdl.kind
    -- кисть чуть дальше центра хвата — рукоять «в кулаке»
    local onePiece = kind == "pistol" or kind == "zeus"
    local hx, hy, hz, ex, ey, ez
    if onePiece then
      -- пистолет: кулак — у верха рукояти, под затвором; рука идёт вниз-назад по скосу рукояти — рукоять в кулаке
      hx, hy, hz = pt({g[1] + 0.004, g[2] + 0.055, g[3] - 0.002})
      ex, ey, ez = pt({g[1] + 0.07, g[2] - 0.3, g[3] - 0.2})
    else
      hx, hy, hz = pt({g[1] + 0.008, g[2] - 0.02, g[3] + 0.0})
      ex, ey, ez = pt({g[1] + 0.13, g[2] - 0.2, g[3] - 0.34})
    end
    blockArm(hx, hy, hz, ex, ey, ez, S * k, team, mirror, onePiece and 0.8 or 1)
    local f = mdl.fore
    if f and not mdl.dual then
      local fx, fy, fz = pt({f[1] - 0.01, f[2] - 0.045, f[3]})
      local lx, ly, lz
      if onePiece then
        -- вторая рука поддерживает снизу-слева, кулак рядом с правым
        fx, fy, fz = pt({f[1] - 0.022, f[2] + 0.035, f[3] - 0.006})
        lx, ly, lz = pt({f[1] - 0.15, f[2] - 0.3, f[3] - 0.2})
      else
        lx, ly, lz = pt({f[1] - 0.2, f[2] - 0.24, f[3] - 0.3})
      end
      blockArm(fx, fy, fz, lx, ly, lz, S * k, team, true, onePiece and 0.8 or 1)
    end
    -- вспышка у дула (у оружия с глушителем — нет)
    if w.clip and not w.silenced and now - (me.flashT or -9) < 0.05 then
      local mz = mdl.muzzle or {0, 0, 0.3}
      local fx, fy, fz = toWorld({x = 0, y = 0, z = 0}, gyaw, gpitch, r, (mirror and -mz[1] or mz[1]) * k, mz[2] * k, mz[3])
      local size = (mdl.kind == "pistol" and 0.1 or 0.14) * S * (0.8 + math.random() * 0.4)
      g3d.sprite(VM.flashTex, wx + fx, wy + fy, wz + fz, size, size, g3d.static and {blend = "add", pick = false} or nil)
    end
  end
  one(false)
  if mdl.dual then one(true) end
end

-- Для tools/gen_strike.py (иконки оружия рисуются из этих же моделей) и render.lua.
VM.GUNS = GUNS

return VM
