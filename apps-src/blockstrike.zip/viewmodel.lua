-- Оружие от первого лица: 3D-модели guns.lua (kit.lua) и руки — рукава цвета команды, перчатки, пальцы на рукояти
-- и цевье. Модель рисуется в том же 3D-кадре, что и мир, но очень близко к глазу и уменьшенной (масштаб S): так она
-- не уходит в стены (игрок не подходит к стене ближе 0,25), а на экране выглядит обычного размера.
-- Единицы модели — метры: +Z вперёд (дуло), +Y вверх, +X вправо; начало координат — у спускового крючка.
local D = require("data")
local K = require("kit")
local GUNS = require("guns")

local VM = {}
-- Поворот и сдвиг оружия у глаза (общие для всех моделей): видно правый бок, дуло смотрит к прицелу.
VM.TUNE = {yaw = -14, dx = 0.05, dy = -0.015, dz = 0.04}
local sin, cos, rad, sqrt, min, max, abs = math.sin, math.cos, math.rad, math.sqrt, math.min, math.max, math.abs

local S = 0.25 -- во сколько раз модель меньше «настоящей»
local SLEEVE = {"t_jacket", "ct_shirt"}
local GLOVE = {"glove_tan", "glove_black"}
local CUFF = {"t_pants", "ct_vest"}

-- --- Руки ---

-- Предплечье от локтя к запястью: рукав (конус) и манжета.
local function forearm(m, elbow, wrist, team)
  local dx, dy, dz = wrist[1] - elbow[1], wrist[2] - elbow[2], wrist[3] - elbow[3]
  local l = sqrt(dx * dx + dy * dy + dz * dz)
  local cut = {wrist[1] - dx / l * 0.03, wrist[2] - dy / l * 0.03, wrist[3] - dz / l * 0.03}
  K.cyl(m, elbow, cut, 0.05, 0.036, 10, SLEEVE[team], {caps = false})
  K.cyl(m, cut, {cut[1] + dx / l * 0.02, cut[2] + dy / l * 0.02, cut[3] + dz / l * 0.02}, 0.039, 0.037, 10, CUFF[team])
  K.cyl(m, {cut[1] + dx / l * 0.02, cut[2] + dy / l * 0.02, cut[3] + dz / l * 0.02}, wrist, 0.03, 0.028, 10, GLOVE[team])
end

-- Кисть: ладонь вокруг рукояти, пальцы спереди, большой палец сверху-слева. g — центр хвата.
local function gripHand(m, g, team, tilt)
  local gl = GLOVE[team]
  K.push(m)
  K.move(m, g[1], g[2], g[3])
  K.turn(m, 0, tilt or -12, 0)
  K.box(m, 0.006, -0.045, -0.035, 0.032, 0.03, 0.022, gl, {soft = 0.7}) -- ладонь справа
  for k = 0, 3 do
    local y = 0.012 - k * 0.019
    K.box(m, -0.022, y - 0.016, 0.014, 0.024, y, 0.034, gl, {soft = 0.8}) -- пальцы обхватывают спереди
  end
  K.box(m, -0.026, -0.005, -0.03, -0.006, 0.014, 0.025, gl, {soft = 0.8}) -- большой палец слева
  K.pop(m)
end

-- Левая кисть под цевьём: ладонь снизу, пальцы по левой стороне вверх.
local function foreHand(m, f, team)
  local gl = GLOVE[team]
  K.box(m, f[1] - 0.03, f[2] - 0.05, f[3] - 0.035, f[1] + 0.02, f[2] - 0.02, f[3] + 0.04, gl, {soft = 0.7})
  for k = 0, 3 do
    local z = f[3] - 0.026 + k * 0.019
    K.box(m, f[1] - 0.04, f[2] - 0.04, z, f[1] - 0.024, f[2] + 0.012, z + 0.016, gl, {soft = 0.8})
  end
  K.box(m, f[1] + 0.012, f[2] - 0.03, f[3] - 0.03, f[1] + 0.03, f[2] + 0.004, f[3] + 0.03, gl, {soft = 0.8})
end

local function arms(m, mdl, team)
  local g = mdl.grip
  local kind = mdl.kind
  forearm(m, {g[1] + 0.2, g[2] - 0.3, g[3] - 0.34}, {g[1] + 0.024, g[2] - 0.045, g[3] - 0.048}, team)
  gripHand(m, g, team, kind == "knife" and 0 or (kind == "nade" and 10 or -12))
  local f = mdl.fore
  if f then
    if kind == "pistol" then
      -- двуручный хват пистолета: левая ладонь под правой
      forearm(m, {f[1] - 0.16, f[2] - 0.3, f[3] - 0.32}, {f[1] - 0.02, f[2] - 0.04, f[3] - 0.04}, team)
      K.box(m, f[1] - 0.036, f[2] - 0.045, f[3] - 0.03, f[1] + 0.004, f[2] + 0.02, f[3] + 0.04, GLOVE[team], {soft = 0.7})
    else
      forearm(m, {f[1] - 0.26, f[2] - 0.3, f[3] - 0.28}, {f[1] - 0.01, f[2] - 0.055, f[3] - 0.03}, team)
      foreHand(m, f, team)
    end
  end
end

-- --- Сборка ---

local cache, worldCache = {}, {}

local function model(key) return GUNS[key] or GUNS.knife end

local function build(key, team)
  local id = key .. team
  if cache[id] then return cache[id] end
  local mdl = model(key)
  local m = K.new()
  mdl.build(m)
  arms(m, mdl, mdl.dual and team or team)
  cache[id] = {mesh = K.finish(m), mdl = mdl}
  return cache[id]
end

-- Для стенда: модель с руками (сетка).
function VM.debugBuild(key, team) return build(key, team).mesh end

-- Модель без рук — в руках у других игроков и на земле (render.lua).
function VM.worldModel(key)
  local id = worldCache[key]
  if id then return id end
  local m = K.new()
  model(key).build(m)
  id = K.finish(m)
  worldCache[key] = id
  return id
end

function VM.init()
  VM.tex = g3d.texture("textures/kit_atlas.png", {mipmap = false})
  VM.flashTex = g3d.texture("textures/muzzle.png")
end

-- Точка модели (в метрах, относительно глаза) → мир.
local function toWorld(cam, yaw, pitch, roll, ox, oy, oz)
  local R = K.euler(yaw, pitch, roll)
  local x, y, z = K.apply(R, ox, oy, oz)
  return cam.x + x * S, cam.y + y * S, cam.z + z * S
end

-- Нарисовать оружие в руках (своё или того, за кем наблюдаем). me — состояние: wpn, vx, vz, walkT, cool, switchT,
-- reload, reloadFor, nadeCool, crouch, flashT. team — цвет рукавов.
function VM.draw(cam, me, team, now)
  local w = D.WEAPONS[me.wpn] or D.WEAPONS[1]
  local entry = build(w.key, team)
  local mdl = entry.mdl
  local sp = sqrt((me.vx or 0) ^ 2 + (me.vz or 0) ^ 2)
  local walk = min(1, sp / 3)
  local wt = me.walkT or 0
  -- покачивание при ходьбе (восьмёрка), отдача, смена оружия, перезарядка, бросок гранаты, удар ножом
  local bx = sin(wt * 3.2) * 0.012 * walk
  local by = -abs(cos(wt * 3.2)) * 0.01 * walk
  local tn = VM.tune or VM.TUNE
  local px, py, pz = mdl.pos[1] + bx + tn.dx, mdl.pos[2] + by + tn.dy, mdl.pos[3] + tn.dz
  local pitch, yaw, roll = tn.pitch or 0, tn.yaw, sin(wt * 3.2) * 1.5 * walk + (tn.roll or 0)
  local cool = me.cool or 0
  if w.clip and cool > 0 then
    local k = cool / w.cool
    k = k * k
    pz = pz - 0.04 * k * min(2, 0.6 + w.recoil * 0.3)
    pitch = pitch + 4 * k * min(2, 0.5 + w.recoil * 0.25)
  end
  if (me.switchT or 0) > 0 then
    local k = me.switchT / 0.35
    py = py - 0.25 * k
    pitch = pitch - 30 * k
  end
  if (me.reload or 0) > 0 then
    local wr = D.WEAPONS[me.reloadFor] or w
    local k = sin(math.pi * (1 - me.reload / (wr.reload or 1)))
    py = py - 0.07 * k
    pitch = pitch - 18 * k
    roll = roll + 28 * k
    px = px - 0.03 * k
  end
  if mdl.kind == "knife" and cool > 0 then
    local k = sin(math.pi * (1 - cool / w.cool))
    px, pz = px - 0.08 * k, pz + 0.12 * k
    yaw, pitch = yaw + 35 * k, pitch - 15 * k
  end
  if mdl.kind == "nade" and (me.nadeCool or 0) > 0 then
    local k = sin(math.pi * (1 - me.nadeCool / 0.8))
    py, pz = py + 0.08 * k, pz + 0.1 * k
    pitch = pitch + 30 * k
  end
  if me.crouch then py = py + 0.01 end
  local gyaw, gpitch = cam.yaw + yaw, max(-89, min(89, cam.pitch + pitch))
  local function one(mirror)
    local ox = mirror and -px or px
    local wx, wy, wz = toWorld(cam, cam.yaw, cam.pitch, 0, ox, py, pz)
    local r = mirror and -roll or roll
    g3d.draw(entry.mesh, wx, wy, wz, {yaw = gyaw + (mirror and 3 or 0), pitch = gpitch, roll = r, sx = mirror and -S or S, sy = S,
      sz = S, texture = VM.tex})
    -- вспышка у дула (у оружия с глушителем — нет)
    if w.clip and not w.silenced and now - (me.flashT or -9) < 0.05 then
      local mz = mdl.muzzle or {0, 0, 0.3}
      local fx, fy, fz = toWorld({x = 0, y = 0, z = 0}, gyaw, gpitch, r, mirror and -mz[1] or mz[1], mz[2], mz[3])
      local size = (mdl.kind == "pistol" and 0.1 or 0.14) * S * (0.8 + math.random() * 0.4)
      g3d.sprite(VM.flashTex, wx + fx, wy + fy, wz + fz, size, size, g3d.static and {blend = "add", pick = false} or nil)
    end
  end
  one(false)
  if mdl.dual then one(true) end
end

-- Для tools/gen_strike.py (иконки оружия рисуются из этих же моделей) и render.lua.
VM.GUNS = GUNS

return VM
