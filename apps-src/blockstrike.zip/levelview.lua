-- Вид цельной карты (levels/*.lua): из клеток levelgen — дома (стены до своей высоты, фасады, крыши с карнизом),
-- комнаты (стены изнутри, пол, потолок), проёмы (перемычки, подоконники), ступени; поверх — фасадные окна, двери,
-- вывески, навесы, кондиционеры, балконы; затем предметы (props.lua), стенки и створки дверей.
-- Тот же порядок работы, что у city.lua: LV.begin(map) → LV.step(job, строк) до готовности → LV.commit(job, T).
local M = require("maps")
local K = require("kit")
local Props = require("props")

local LV = {}
local floor, min, max, abs = math.floor, math.min, math.max, math.abs

local REP = 2.0 -- текстура стен и полов повторяется каждые 2 блока
local STOREY = 1.6
local TRIM = 0.25

-- Направления: 1 — z−, 2 — z+, 3 — x−, 4 — x+; сосед, нормаль, «вправо» для зрителя снаружи.
local DIRS = {
  {0, -1, nx = 0, nz = -1, ax = 1, az = 0},
  {0, 1, nx = 0, nz = 1, ax = -1, az = 0},
  {-1, 0, nx = -1, nz = 0, ax = 0, az = -1},
  {1, 0, nx = 1, nz = 0, ax = 0, az = 1},
}

local function hash(a, b, c)
  local v = (a * 127 + b * 311 + (c or 0) * 53 + 977) * 2654435761 % 4294967296
  v = (v * 2246822519 + 3266489917) % 4294967296
  return v / 4294967296
end

local function bucket(S, key)
  local m = S.B[key]
  if not m then
    m = K.new()
    S.B[key] = m
  end
  return m
end

-- --- Интервалы твёрдого в клетке ---

local function isWallCell(m, i)
  return m.c[i] == "#" and m.kind[i] ~= "prop" and m.kind[i] ~= "wall"
end

local function intervals(m, i)
  local c = m.c[i]
  if isWallCell(m, i) then return {{-1, m.bh[i] or m.wallH, "wall"}} end
  local low = c == "W" and m.top[i] or m.base[i]
  local list = {{-1, low, c == "W" and "sill" or "ledge"}}
  if m.roof[i] then list[2] = {m.roof[i], m.bh[i] or (m.roof[i] + 0.4), "upper"} end
  return list
end

-- Куски [a, b], не закрытые твёрдым соседа.
local function subtract(a, b, nlist)
  local pieces = {{a, b}}
  for _, n in ipairs(nlist) do
    local out = {}
    for _, p in ipairs(pieces) do
      if n[2] <= p[1] or n[1] >= p[2] then
        out[#out + 1] = p
      else
        if n[1] > p[1] then out[#out + 1] = {p[1], n[1]} end
        if n[2] < p[2] then out[#out + 1] = {n[2], p[2]} end
      end
    end
    pieces = out
  end
  local res = {}
  for _, p in ipairs(pieces) do if p[2] - p[1] > 0.005 then res[#res + 1] = p end end
  return res
end

-- Вертикальный прямоугольник на грани клетки (cx, cz) в сторону d от y0 до y1; текстура по миру.
local function face(S, tex, cx, cz, d, y0, y1, off, uvMode)
  local m = S.map
  local cs = m.cs
  local D = DIRS[d]
  local x0, z0, x1, z1
  if d == 1 then x0, z0, x1, z1 = cx * cs, cz * cs, (cx + 1) * cs, cz * cs
  elseif d == 2 then x0, z0, x1, z1 = (cx + 1) * cs, (cz + 1) * cs, cx * cs, (cz + 1) * cs
  elseif d == 3 then x0, z0, x1, z1 = cx * cs, (cz + 1) * cs, cx * cs, cz * cs
  else x0, z0, x1, z1 = (cx + 1) * cs, cz * cs, (cx + 1) * cs, (cz + 1) * cs end
  off = off or 0
  x0, z0, x1, z1 = x0 + D.nx * off, z0 + D.nz * off, x1 + D.nx * off, z1 + D.nz * off
  local k = 1 / REP
  local ua, ub = (x0 * D.ax + z0 * D.az) * k, (x1 * D.ax + z1 * D.az) * k
  local v0, v1 = -y1 * k, -y0 * k
  if uvMode == "band" then v0, v1 = 0, 1 end
  K.quad(bucket(S, tex), {x0, y1, z0}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z0}, nil, {D.nx, 0, D.nz}, {ua, v0, ub, v1})
end

-- Декаль на плоскости грани: прямоугольник вдоль стены (t0..t1 — в блоках от начала полосы) с картинкой целиком.
local function decal(S, tex, run, t0, t1, y0, y1, off)
  local D = DIRS[run.d]
  local bx, bz = run.x + D.nx * (off or 0.012), run.z + D.nz * (off or 0.012)
  local xa, za = bx + D.ax * t0, bz + D.az * t0
  local xb, zb = bx + D.ax * t1, bz + D.az * t1
  K.quad(bucket(S, tex), {xa, y1, za}, {xb, y1, zb}, {xb, y0, zb}, {xa, y0, za}, nil, {D.nx, 0, D.nz}, {0, 0, 1, 1})
end

-- --- Построение по строкам ---

local function cellFaces(S, cx, cz)
  local m = S.map
  local W, H = m.W, m.H
  local i = cz * W + cx + 1
  local mine = intervals(m, i)
  local wall = isWallCell(m, i)
  for d = 1, 4 do
    local nx, nz = cx + DIRS[d][1], cz + DIRS[d][2]
    if nx >= 0 and nz >= 0 and nx < W and nz < H then
      local j = nz * W + nx + 1
      local theirs = intervals(m, j)
      for _, iv in ipairs(mine) do
        for _, p in ipairs(subtract(iv[1], iv[2], theirs)) do
          local a, b = max(p[1], -0.2), p[2]
          if iv[3] == "wall" then
            local inside = m.roof[j] and a < m.roof[j] - 0.01
            if inside then
              -- стена комнаты изнутри: от пола до потолка соседа
              local rf = m.roof[j]
              face(S, m.itex[i] or "city/des_inwall", cx, cz, d, a, min(b, rf), 0, nil)
              if b > rf + 0.01 then face(S, m.wtex[i] or S.facade, cx, cz, d, rf, b) end
            else
              local top = m.bh[i] or m.wallH
              if b >= top - 0.01 and b - a > 0.8 then
                face(S, m.wtex[i] or S.facade, cx, cz, d, a, b - TRIM)
                face(S, S.trim, cx, cz, d, b - TRIM, b, 0, "band")
              else
                face(S, m.wtex[i] or S.facade, cx, cz, d, a, b)
              end
              -- запомнить для украшений: фасад от земли улицы, сосед — открытая клетка без крыши
              if not m.roof[j] and m.c[j] ~= "#" and abs(a - max(-0.2, m.base[j])) < 0.02 and b - a > 1.4 then
                local key = (m.owner[i] or 0) .. "|" .. d .. "|" .. ((d <= 2) and cz or cx)
                local r = S.runs[key]
                if not r then
                  r = {d = d, cells = {}, owner = m.owner[i], ground = a, top = b, tex = m.wtex[i]}
                  S.runs[key] = r
                end
                r.cells[#r.cells + 1] = (d <= 2) and cx or cz
                r.line = (d <= 2) and cz or cx
              end
            end
          elseif iv[3] == "ledge" then
            face(S, m.mat[i] or S.ground, cx, cz, d, a, b)
          elseif iv[3] == "sill" then
            face(S, S.trim, cx, cz, d, a, b)
          else
            -- верхняя масса над проёмом/комнатой
            local inside = m.roof[j] and m.roof[j] > a - 0.01 and m.c[j] ~= "#"
            face(S, inside and (m.itex[i] or "city/des_inwall") or (m.wtex[i] or S.facade), cx, cz, d, a, b)
          end
        end
      end
    end
  end
end

local function rowFlats(S, cz)
  local m = S.map
  local W, cs = m.W, m.cs
  local k = 1 / REP
  local runs = {}
  local function push(kind, key, x, y, down)
    local list = runs[kind]
    if not list then list = {} runs[kind] = list end
    local r = list[#list]
    if r and r.key == key and r.y == y and r.x1 == x then r.x1 = x + 1 else list[#list + 1] = {key = key, x0 = x, x1 = x + 1, y = y, down = down} end
  end
  for cx = 0, W - 1 do
    local i = cz * W + cx + 1
    if isWallCell(m, i) then
      push("top", S.roof, cx, m.bh[i] or m.wallH)
    else
      local y = m.c[i] == "W" and m.top[i] or m.base[i]
      push("floor", m.c[i] == "W" and S.trim or (m.mat[i] or S.ground), cx, y)
      if m.roof[i] then
        local isRoom = m.ceil and m.ceil[i]
        push("ceil", isRoom and m.ceil[i] or S.trim, cx, m.roof[i], true)
        push("rtop", (m.roofTex and m.roofTex[i]) or S.roof, cx, m.bh[i] or m.roof[i] + 0.4)
      end
    end
  end
  for kind, list in pairs(runs) do
    for _, r in ipairs(list) do
      local x0, x1, z0, z1 = r.x0 * cs, r.x1 * cs, cz * cs, (cz + 1) * cs
      local mb = bucket(S, r.key)
      if r.down then
        K.quad(mb, {x0, r.y, z1}, {x1, r.y, z1}, {x1, r.y, z0}, {x0, r.y, z0}, nil, {0, -1, 0}, {x0 * k, z1 * k, x1 * k, z0 * k})
      else
        K.quad(mb, {x0, r.y, z0}, {x1, r.y, z0}, {x1, r.y, z1}, {x0, r.y, z1}, nil, {0, 1, 0}, {x0 * k, z0 * k, x1 * k, z1 * k})
      end
    end
  end
end

-- --- Украшения фасадов ---

local function decorate(S)
  local m = S.map
  local cs = m.cs
  local th = S.theme
  for key, r in pairs(S.runs) do
    table.sort(r.cells)
    -- непрерывные куски полосы
    local s = 1
    while s <= #r.cells do
      local e = s
      while e < #r.cells and r.cells[e + 1] == r.cells[e] + 1 do e = e + 1 end
      local c0, c1 = r.cells[s], r.cells[e]
      local D = DIRS[r.d]
      -- начало полосы (левый край для зрителя снаружи) и длина
      local len = (c1 - c0 + 1) * cs
      local run = {d = r.d}
      local line = r.line
      if r.d == 1 then run.x, run.z = c0 * cs, line * cs
      elseif r.d == 2 then run.x, run.z = (c1 + 1) * cs, (line + 1) * cs
      elseif r.d == 3 then run.x, run.z = line * cs, (c1 + 1) * cs
      else run.x, run.z = (line + 1) * cs, c0 * cs end
      local g, top = r.ground, r.top
      local seed = (c0 + 1) * 31 + line * 17 + r.d
      -- окна по этажам: шаг ~2 блока, по краям — отступ
      local n = floor((len - 0.6) / 2.0)
      if n >= 1 then
        local step = len / (n + 0.0)
        local winTex = th.windows[1 + floor(hash(seed, 1) * #th.windows)]
        for k = 0, n - 1 do
          local t = (k + 0.5) * step
          for st = 1, 3 do
            local yb = g + 0.35 + st * STOREY - 0.2
            if yb + 1.0 < top - TRIM - 0.15 and hash(seed, k, st) < 0.85 then
              decal(S, winTex, run, t - 0.38, t + 0.38, yb, yb + 0.95)
              local rr = hash(seed, k, st + 10)
              if rr < 0.12 then
                -- балкон с решёткой
                local mb = bucket(S, "kit")
                local bx, bz = run.x + D.ax * t, run.z + D.az * t
                local x0, z0 = bx - D.ax * 0.55, bz - D.az * 0.55
                local x1, z1 = bx + D.ax * 0.55 + D.nx * 0.45, bz + D.az * 0.55 + D.nz * 0.45
                K.box(mb, min(x0, x1), yb - 0.12, min(z0, z1), max(x0, x1), yb - 0.04, max(z0, z1), "stone", {})
                decal(S, "city/railing", run, t - 0.55, t + 0.55, yb - 0.04, yb + 0.45, 0.45)
              elseif rr < 0.24 then
                local mb = bucket(S, "kit")
                local bx, bz = run.x + D.ax * t + D.nx * 0.12, run.z + D.az * t + D.nz * 0.12
                K.push(mb)
                K.move(mb, bx, yb - 0.45, bz)
                K.turn(mb, (r.d == 1 and 180) or (r.d == 2 and 0) or (r.d == 3 and -90) or 90, 0, 0)
                K.box(mb, -0.32, 0, -0.12, 0.32, 0.36, 0.12, "metal_grey", {soft = 0.3})
                K.cyl(mb, {0.1, 0.18, 0.12}, {0.1, 0.18, 0.125}, 0.12, 0.12, 10, "grille")
                K.pop(mb)
              end
            end
          end
          -- первый этаж: двери, ставни, вывески
          local r1 = hash(seed, k, 50)
          if top - g > 1.8 then
            if r1 < 0.18 then
              local dt = th.doors[1 + floor(hash(seed, k, 51) * #th.doors)]
              decal(S, dt, run, t - 0.45, t + 0.45, g, g + 1.25)
              if hash(seed, k, 52) < 0.55 and th.awning then
                local mb = bucket(S, th.awning)
                local bx, bz = run.x + D.ax * t, run.z + D.az * t
                local xa, za = bx - D.ax * 0.6 + D.nx * 0.02, bz - D.az * 0.6 + D.nz * 0.02
                local xb, zb = bx + D.ax * 0.6 + D.nx * 0.02, bz + D.az * 0.6 + D.nz * 0.02
                local ox, oz = D.nx * 0.5, D.nz * 0.5
                K.quad(mb, {xa, g + 1.5, za}, {xb, g + 1.5, zb}, {xb + ox, g + 1.3, zb + oz}, {xa + ox, g + 1.3, za + oz}, nil,
                  {D.nx * 0.4, 0.9, D.nz * 0.4}, {0, 0, 1, 1})
              end
            elseif r1 < 0.32 and th.signs then
              decal(S, th.signs[1 + floor(hash(seed, k, 53) * #th.signs)], run, t - 0.6, t + 0.6, g + 1.3, g + 1.6, 0.025)
            elseif r1 < 0.6 then
              decal(S, winTex, run, t - 0.3, t + 0.3, g + 0.5, g + 1.2)
            end
          end
        end
      end
      -- водосточная труба на краю
      if len > 3 and hash(seed, 99) < 0.35 then
        local mb = bucket(S, "kit")
        local bx, bz = run.x + D.ax * 0.12 + D.nx * 0.05, run.z + D.az * 0.12 + D.nz * 0.05
        K.cyl(mb, {bx, g, bz}, {bx, top - 0.1, bz}, 0.04, 0.04, 6, "metal_grey")
      end
      s = e + 1
    end
  end
end

-- --- Публично ---

local THEMES = {
  desert = {windows = {"city/des_window", "city/des_window2", "city/des_window3", "city/oas_window2"},
    doors = {"city/des_door", "city/des_door2", "city/oas_door", "d2_door"}, awning = "city/des_awning",
    signs = {"city/sign2", "city/sign4", "city/sign1"}},
}

function LV.begin(map)
  local def = map.def
  return {map = map, B = {}, runs = {}, row = 0, phase = "rows", propIdx = 1, theme = THEMES[def.theme or "desert"] or THEMES.desert,
    facade = def.facade or "city/des_plaster", trim = def.trim or "city/des_trim", roof = def.roof or "city/des_roof",
    ground = def.ground or "city/des_road"}
end

function LV.step(S, rows)
  local m = S.map
  if S.phase == "rows" then
    local stop = min(m.H, S.row + (rows or 6))
    for z = S.row, stop - 1 do
      for x = 0, m.W - 1 do cellFaces(S, x, z) end
      rowFlats(S, z)
    end
    S.row = stop
    if S.row >= m.H then S.phase = "props" end
    return false
  elseif S.phase == "props" then
    local ents = m.def.entities
    local n = 0
    while S.propIdx <= #ents and n < 8 do
      local e = ents[S.propIdx]
      S.propIdx = S.propIdx + 1
      local B = function(tex) return bucket(S, tex) end
      if e.t == "prop" then
        Props.build(e, B)
        n = n + 1
      elseif e.t == "wall" then
        local i = M.idx(m, (e.x1 + e.x2) / 2, (e.z1 + e.z2) / 2)
        local y = i and m.base[i] or 0
        local o = e.o
        if o.h and o.h >= 99 and i and m.roof[i] then o.top = m.roof[i] - y end
        Props.wall(e, B, y)
        n = n + 1
      elseif e.t == "door" then
        local i = M.idx(m, (e.x1 + e.x2) / 2, (e.z1 + e.z2) / 2)
        Props.door(e, B, i and m.base[i] or 0, (e.x2 - e.x1) > (e.z2 - e.z1))
      end
    end
    if S.propIdx > #ents then S.phase = "decor" end
    return false
  elseif S.phase == "decor" then
    decorate(S)
    S.phase = "done"
    S.done = true
    return true
  end
  return S.done == true
end

-- Сетки → статическая сцена. T(name) — номер текстуры («kit» — атлас).
function LV.commit(S, T)
  local tris, ids = 0, {}
  for key, mb in pairs(S.B) do
    if #mb.i > 0 then
      local id = g3d.mesh({vertices = mb.v, indices = mb.i, normals = mb.n})
      ids[#ids + 1] = id
      local tex = key == "kit" and T("kit") or T(key)
      local solid = key ~= "city/railing" and key ~= S.theme.awning
      g3d.static(id, 0, 0, 0, {texture = tex, solid = solid})
      tris = tris + #mb.i / 3
    end
  end
  S.B, S.runs = nil, nil
  return ids, tris
end

-- Лампы под потолками комнат (для запекания света).
function LV.lamps(map)
  local out = {}
  for _, e in ipairs(map.def.entities) do
    if e.t == "room" then
      local o = e.o
      local fl, ce = o.floor or 0, o.ceil or 1.6
      local w, d = e.x2 - e.x1, e.z2 - e.z1
      local nx, nz = math.max(1, floor(w / 5)), math.max(1, floor(d / 5))
      for a = 1, nx do
        for b = 1, nz do
          out[#out + 1] = {e.x1 + w * (a - 0.5) / nx, fl + ce - 0.15, e.z1 + d * (b - 0.5) / nz, color = "#FFFFE0B0", radius = 5,
            power = 0.9}
        end
      end
    end
  end
  return out
end

return LV
