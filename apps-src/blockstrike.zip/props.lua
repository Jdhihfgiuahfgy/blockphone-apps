-- Предметы цельных карт (машины, ящики, бочки, прилавки, деревья, фонари, ворота…) из деталей kit.lua.
-- Размеры — в блоках (1 блок ≈ 1,8 м), совпадают с LG.PROPS (там — твёрдая часть для логики).
-- P.build(e, B): e — предмет из levelgen (kind, x, z, y, rot, o), B(текстура) → построитель kit для этой текстуры
-- ("kit" — атлас материалов, иначе — картинка textures/<имя>.png целиком на грань).
local K = require("kit")

local P = {}
local sin, cos, rad, floor = math.sin, math.cos, math.rad, math.floor
local FULL = {0, 0, 1, 1}

local function hash(a, b) return ((a * 92821 + b * 68917 + 12345) % 100003) / 100003 end

local CAR = {red = "car_red", blue = "car_blue", white = "car_white", yellow = "car_yellow", green = "car_green"}

local function place(m, e, extraYaw)
  K.push(m)
  K.move(m, e.x, e.y or 0, e.z)
  K.turn(m, (e.rot or 0) + (extraYaw or 0), 0, 0)
end

local function wheel(m, x, z, r, w)
  K.cyl(m, {x - w / 2, r, z}, {x + w / 2, r, z}, r, r, 12, "tire", {capMat = "rim"})
end

-- --- Машины ---

local function car(m, o)
  local paint = CAR[o.color or "red"] or "car_red"
  -- кузов: низ, капот, багажник
  K.box(m, -0.47, 0.14, -1.22, 0.47, 0.46, 1.22, paint, {soft = 0.5})
  K.box(m, -0.46, 0.46, 0.45, 0.46, 0.5, 1.2, paint, {soft = 0.6})
  K.box(m, -0.46, 0.46, -1.2, 0.46, 0.52, -0.62, paint, {soft = 0.6})
  -- салон: стойки и стёкла
  K.box(m, -0.43, 0.5, -0.6, 0.43, 0.8, 0.42, paint, {soft = 0.5, taper = 0.12, taperZ = 0.4})
  K.box(m, -0.44, 0.53, -0.52, 0.44, 0.76, 0.34, "car_glass", {taper = 0.12, taperZ = 0.4})
  K.box(m, -0.4, 0.795, -0.48, 0.4, 0.81, 0.3, paint, {soft = 0.4})
  -- колёса, бамперы, фары, номер
  for _, z in ipairs({-0.78, 0.8}) do
    wheel(m, -0.44, z, 0.16, 0.12)
    wheel(m, 0.44, z, 0.16, 0.12)
  end
  K.box(m, -0.48, 0.12, 1.2, 0.48, 0.24, 1.26, "black_matte", {soft = 0.5})
  K.box(m, -0.48, 0.12, -1.26, 0.48, 0.24, -1.2, "black_matte", {soft = 0.5})
  for s = -1, 1, 2 do
    K.box(m, s * 0.32 - 0.08, 0.34, 1.215, s * 0.32 + 0.08, 0.42, 1.225, "headlight")
    K.box(m, s * 0.34 - 0.07, 0.34, -1.225, s * 0.34 + 0.07, 0.42, -1.215, "taillight")
    K.box(m, s * 0.47, 0.6, 0.28, s * 0.5, 0.64, 0.36, paint) -- зеркала
  end
  K.box(m, -0.12, 0.16, 1.262, 0.12, 0.23, 1.268, "plate")
  K.box(m, -0.2, 0.3, 1.226, 0.2, 0.4, 1.232, "grille")
end

local function van(m, o)
  local paint = CAR[o.color or "white"] or "car_white"
  K.box(m, -0.72, 0.18, -1.48, 0.72, 1.24, 0.9, paint, {soft = 0.35})
  K.box(m, -0.72, 0.18, 0.9, 0.72, 0.85, 1.48, paint, {soft = 0.5, taper = 0.05})
  K.box(m, -0.66, 0.85, 0.9, 0.66, 1.2, 1.25, "car_glass", {tilt = -18})
  for s = -1, 1, 2 do
    K.box(m, s * 0.725 - 0.01, 0.7, 0.95, s * 0.725 + 0.01, 1.05, 1.35, "car_glass")
    K.box(m, s * 0.5 - 0.1, 0.45, 1.475, s * 0.5 + 0.1, 0.56, 1.485, "headlight")
    K.box(m, s * 0.55 - 0.08, 0.5, -1.485, s * 0.55 + 0.08, 0.7, -1.475, "taillight")
  end
  K.box(m, -0.74, 0.14, 1.45, 0.74, 0.3, 1.55, "black_matte")
  K.box(m, -0.02, 0.25, -1.49, 0.02, 1.15, -1.48, "black_matte") -- шов задних дверей
  K.box(m, 0.725, 0.3, -1.0, 0.735, 1.1, 0.3, "metal_grey") -- сдвижная дверь
  for _, z in ipairs({-1.0, 1.0}) do
    wheel(m, -0.68, z, 0.2, 0.15)
    wheel(m, 0.68, z, 0.2, 0.15)
  end
end

local function truck(m, o)
  local paint = CAR[o.color or "green"] or "car_green"
  -- кабина
  K.box(m, -0.74, 0.3, 1.25, 0.74, 1.35, 2.22, paint, {soft = 0.4})
  K.box(m, -0.68, 0.95, 2.1, 0.68, 1.3, 2.225, "car_glass")
  K.box(m, -0.76, 0.25, 2.2, 0.76, 0.45, 2.28, "black_matte")
  K.box(m, -0.4, 0.5, 2.225, 0.4, 0.85, 2.23, "grille")
  for s = -1, 1, 2 do
    K.box(m, s * 0.62 - 0.08, 0.55, 2.225, s * 0.62 + 0.08, 0.66, 2.235, "headlight")
    K.box(m, s * 0.745, 0.95, 1.4, s * 0.755, 1.25, 2.0, "car_glass")
  end
  -- рама и кузов с тентом
  K.box(m, -0.5, 0.3, -2.2, 0.5, 0.45, 1.25, "metal_dark")
  K.box(m, -0.74, 0.45, -2.22, 0.74, 0.75, 1.2, "plank", {soft = 0.2})
  K.box(m, -0.74, 0.75, -2.2, 0.74, 1.6, 1.15, "tarp_green", {soft = 0.6, taper = 0.04})
  for _, z in ipairs({-1.6, -0.8, 1.7}) do
    wheel(m, -0.7, z, 0.27, 0.2)
    wheel(m, 0.7, z, 0.27, 0.2)
  end
end

-- --- Ящики, бочки, мешки ---

local function crate(m, w, d, h, tex)
  K.box(m, -w / 2 + 0.01, 0, -d / 2 + 0.01, w / 2 - 0.01, h, d / 2 - 0.01, tex, {uvr = FULL})
end

local function barrel(m, x, z, mat, tilt)
  K.cyl(m, {x, 0, z}, {x, 0.55, z}, 0.2, 0.2, 12, mat, {capMat = "barrel_top"})
  K.cyl(m, {x, 0.18, z}, {x, 0.2, z}, 0.205, 0.205, 12, "metal_dark", {caps = false})
  K.cyl(m, {x, 0.37, z}, {x, 0.39, z}, 0.205, 0.205, 12, "metal_dark", {caps = false})
end

local function sandbags(m, w)
  local n = floor(w / 0.42)
  for row = 0, 2 do
    local off = row % 2 == 0 and 0 or 0.21
    for k = 0, n - (row % 2) - 1 do
      local x = -w / 2 + 0.21 + off + k * 0.42
      K.box(m, x - 0.21, row * 0.16, -0.22, x + 0.21, row * 0.16 + 0.17, 0.22, "sandbag", {soft = 0.9})
    end
  end
end

local function pallets(m)
  for k = 0, 2 do
    local y = k * 0.105
    K.box(m, -0.48, y, -0.48, 0.48, y + 0.025, 0.48, "pallet")
    for s = -1, 1 do K.box(m, s * 0.4 - 0.05, y + 0.025, -0.48, s * 0.4 + 0.05, y + 0.085, 0.48, "plank") end
    K.box(m, -0.48, y + 0.085, -0.48, 0.48, y + 0.105, 0.48, "pallet")
  end
end

-- --- Улица ---

local function dumpster(m)
  K.box(m, -0.74, 0.08, -0.48, 0.74, 0.72, 0.48, "dumpster", {soft = 0.3, taper = -0.04})
  K.box(m, -0.76, 0.72, -0.52, 0.76, 0.76, 0.5, "black_matte", {tilt = -4})
  for _, x in ipairs({-0.6, 0.6}) do
    for _, z in ipairs({-0.38, 0.38}) do K.cyl(m, {x, 0, z - 0.03}, {x, 0, z + 0.03}, 0.07, 0.07, 8, "rubber") end
  end
end

local function stall(m, o)
  local cloth = (o.color == "green") and "awning_green" or "awning_red"
  K.box(m, -0.98, 0.38, -0.48, 0.98, 0.45, 0.48, "plank")
  for _, x in ipairs({-0.9, 0.9}) do
    for _, z in ipairs({-0.42, 0.42}) do K.box(m, x - 0.03, 0, z - 0.03, x + 0.03, 0.38, z + 0.03, "plank") end
  end
  K.box(m, -0.95, 0.45, -0.4, -0.3, 0.6, 0.4, "fabric_white", {soft = 0.8}) -- мешки с товаром
  K.box(m, -0.2, 0.45, -0.35, 0.3, 0.55, 0.35, "pallet")
  K.box(m, 0.4, 0.45, -0.3, 0.9, 0.62, 0.3, "terracotta", {soft = 0.8})
  for _, x in ipairs({-0.95, 0.95}) do
    K.box(m, x - 0.025, 0.45, -0.5, x + 0.025, 1.45, -0.45, "plank")
    K.box(m, x - 0.025, 0.45, 0.45, x + 0.025, 1.3, 0.5, "plank")
  end
  -- навес под наклоном
  K.quad(m, {-1.05, 1.47, -0.6}, {1.05, 1.47, -0.6}, {1.05, 1.28, 0.62}, {-1.05, 1.28, 0.62}, cloth)
  K.quad(m, {1.05, 1.47, -0.6}, {-1.05, 1.47, -0.6}, {-1.05, 1.28, 0.62}, {1.05, 1.28, 0.62}, cloth)
end

local function planter(m)
  K.box(m, -0.45, 0, -0.45, 0.45, 0.42, 0.45, "terracotta", {soft = 0.4, taper = -0.08})
  K.box(m, -0.4, 0.4, -0.4, 0.4, 0.44, 0.4, "stone")
  K.ball(m, {0, 0.72, 0}, 0.36, 0.34, 0.36, 10, "leaves")
end

local function tree(m)
  K.cyl(m, {0, 0, 0}, {0.05, 2.0, 0.02}, 0.14, 0.09, 8, "bark")
  K.ball(m, {0.05, 2.5, 0.0}, 0.9, 0.65, 0.9, 12, "leaves")
  K.ball(m, {0.4, 2.2, 0.4}, 0.6, 0.45, 0.6, 10, "leaves")
  K.ball(m, {-0.35, 2.3, -0.3}, 0.6, 0.5, 0.6, 10, "leaves")
end

local function lamp(m)
  K.cyl(m, {0, 0, 0}, {0, 0.25, 0}, 0.09, 0.07, 8, "metal_dark")
  K.cyl(m, {0, 0.25, 0}, {0, 2.25, 0}, 0.045, 0.035, 8, "metal_dark")
  K.box(m, -0.02, 2.2, -0.02, 0.02, 2.24, 0.45, "metal_dark")
  K.box(m, -0.1, 2.08, 0.32, 0.1, 2.2, 0.55, "metal_dark", {taper = 0.3})
  K.box(m, -0.07, 2.07, 0.35, 0.07, 2.08, 0.52, "lamp")
end

local function pole(m)
  K.cyl(m, {0, 0, 0}, {0, 3.6, 0}, 0.08, 0.06, 8, "bark")
  K.box(m, -0.7, 3.35, -0.04, 0.7, 3.43, 0.04, "bark")
  for _, x in ipairs({-0.6, -0.2, 0.2, 0.6}) do K.cyl(m, {x, 3.43, 0}, {x, 3.5, 0}, 0.025, 0.02, 6, "fabric_white") end
end

local function bench(m)
  K.box(m, -0.72, 0.2, -0.2, 0.72, 0.24, 0.2, "plank")
  K.box(m, -0.72, 0.3, -0.22, 0.72, 0.5, -0.18, "plank")
  for _, x in ipairs({-0.6, 0.6}) do K.box(m, x - 0.04, 0, -0.2, x + 0.04, 0.5, 0.18, "metal_dark") end
end

local function cart(m)
  K.box(m, -0.45, 0.25, -0.7, 0.45, 0.32, 0.7, "plank")
  for s = -1, 1, 2 do K.box(m, s * 0.45 - 0.03, 0.32, -0.7, s * 0.45 + 0.03, 0.55, 0.7, "plank") end
  K.box(m, -0.45, 0.32, 0.67, 0.45, 0.55, 0.7, "plank")
  K.box(m, -0.4, 0.32, -0.6, 0.35, 0.58, 0.2, "sandbag", {soft = 0.9})
  K.cyl(m, {-0.5, 0.25, 0.2}, {-0.44, 0.25, 0.2}, 0.25, 0.25, 12, "wood_dark")
  K.cyl(m, {0.44, 0.25, 0.2}, {0.5, 0.25, 0.2}, 0.25, 0.25, 12, "wood_dark")
  K.box(m, -0.3, 0.2, -1.2, -0.26, 0.26, -0.7, "plank")
  K.box(m, 0.26, 0.2, -1.2, 0.3, 0.26, -0.7, "plank")
end

local function fountain(m)
  local seg = 16
  for k = 0, seg - 1 do
    local a0, a1 = k / seg * math.pi * 2, (k + 1) / seg * math.pi * 2
    local r0, r1 = 1.25, 1.48
    local p = function(a, r, y) return {cos(a) * r, y, sin(a) * r} end
    K.quad(m, p(a0, r1, 0.45), p(a1, r1, 0.45), p(a1, r1, 0), p(a0, r1, 0), "stone")
    K.quad(m, p(a1, r0, 0.45), p(a0, r0, 0.45), p(a0, r0, 0.2), p(a1, r0, 0.2), "stone")
    K.quad(m, p(a0, r0, 0.45), p(a1, r0, 0.45), p(a1, r1, 0.45), p(a0, r1, 0.45), "stone")
  end
  K.cyl(m, {0, 0.2, 0}, {0, 0.21, 0}, 1.26, 1.26, 16, "water")
  K.cyl(m, {0, 0.2, 0}, {0, 0.75, 0}, 0.18, 0.12, 10, "stone")
  K.cyl(m, {0, 0.75, 0}, {0, 0.85, 0}, 0.45, 0.4, 12, "stone")
  K.cyl(m, {0, 0.85, 0}, {0, 1.05, 0}, 0.08, 0.06, 8, "stone")
end

local function ac(m)
  K.box(m, -0.45, 0.05, -0.2, 0.45, 0.55, 0.22, "metal_grey", {soft = 0.3})
  K.cyl(m, {0.15, 0.3, 0.22}, {0.15, 0.3, 0.225}, 0.16, 0.16, 12, "grille")
end

local BUILD = {
  car = function(m, e) car(m, e.o) end,
  van = function(m, e) van(m, e.o) end,
  truck = function(m, e) truck(m, e.o) end,
  barrel = function(m, e) barrel(m, 0, 0, e.o.mat or "barrel_blue") end,
  barrels = function(m, e)
    local mats = {"barrel_blue", "barrel_red", "barrel_rust"}
    local h = hash(e.x * 10, e.z * 10)
    barrel(m, -0.24, -0.24, mats[1 + floor(h * 3)])
    barrel(m, 0.24, -0.2, mats[1 + floor(h * 7) % 3])
    barrel(m, -0.2, 0.25, mats[1 + floor(h * 11) % 3])
    if h > 0.4 then barrel(m, 0.26, 0.26, "barrel_rust") end
  end,
  pallets = function(m) pallets(m) end,
  sandbags = function(m, e) sandbags(m, 2) end,
  dumpster = function(m) dumpster(m) end,
  stall = function(m, e) stall(m, e.o) end,
  planter = function(m) planter(m) end,
  tree = function(m) tree(m) end,
  lamp = function(m) lamp(m) end,
  pole = function(m) pole(m) end,
  bench = function(m) bench(m) end,
  cart = function(m) cart(m) end,
  fountain = function(m) fountain(m) end,
  ac = function(m) ac(m) end,
}

local CRATES = {crate = {1, 1, 0.62}, crate_big = {1, 1, 1.1}, crate_long = {2, 1, 0.62}}

function P.build(e, B)
  local c = CRATES[e.kind]
  if c then
    local m = B(e.kind == "crate_big" and "d2_crate" or "crate")
    place(m, e, (hash(e.x, e.z) - 0.5) * 6)
    crate(m, c[1], c[2], c[3], nil)
    K.pop(m)
    return
  end
  local fn = BUILD[e.kind]
  if not fn then return end
  local m = B("kit")
  place(m, e, e.o.yaw)
  fn(m, e)
  K.pop(m)
end

-- --- Стенки, заборы, ворота ---

function P.wall(e, B, y)
  local o = e.o
  local kind = o.kind or "stone"
  local h = o.h or 0.55
  local x1, z1, x2, z2 = e.x1, e.z1, e.x2, e.z2
  if kind == "mesh" then
    local m = B("kit")
    K.box(m, x1, y, z1, x2, y + h, z2, "metal_dark", {})
    return
  end
  if kind == "fence" then
    local m = B("kit")
    local along = (x2 - x1) > (z2 - z1)
    local len = along and x2 - x1 or z2 - z1
    local n = floor(len / 0.18)
    for k = 0, n - 1 do
      local a = k * len / n
      if along then K.box(m, x1 + a + 0.01, y, (z1 + z2) / 2 - 0.03, x1 + a + len / n - 0.02, y + h, (z1 + z2) / 2 + 0.03, "plank")
      else K.box(m, (x1 + x2) / 2 - 0.03, y, z1 + a + 0.01, (x1 + x2) / 2 + 0.03, y + h, z1 + a + len / n - 0.02, "plank") end
    end
    return
  end
  local tex = kind == "plaster" and "city/des_inwall" or "city/des_blocks"
  local m = B(tex)
  -- стенка: текстура по миру (повтор каждые 2 блока)
  local top = h >= 99 and (o.top or 1.6) or h
  local k = 0.5
  local function face(ax, az, bx, bz, nx, nz)
    local ua, ub = (ax + az) * k, (bx + bz) * k
    K.quad(m, {ax, y + top, az}, {bx, y + top, bz}, {bx, y, bz}, {ax, y, az}, nil, {nx, 0, nz}, {ua, -(y + top) * k, ub, -y * k})
  end
  face(x1, z2, x2, z2, 0, 1)
  face(x2, z1, x1, z1, 0, -1)
  face(x1, z1, x1, z2, -1, 0)
  face(x2, z2, x2, z1, 1, 0)
  K.quad(m, {x1, y + top, z1}, {x2, y + top, z1}, {x2, y + top, z2}, {x1, y + top, z2}, nil, {0, 1, 0},
    {x1 * k, z1 * k, x2 * k, z2 * k})
end

-- Створки двери/ворот в проёме: приоткрыты внутрь.
function P.door(e, B, y, alongX)
  local o = e.o
  if not o.leaf then return end
  local m = B("kit")
  local mat = o.leaf == "gate" and "door_blue" or "door_wood"
  local x1, z1, x2, z2 = e.x1, e.z1, e.x2, e.z2
  local top = y + (o.top or 1.3) - 0.02
  if alongX then
    local zc = (z1 + z2) / 2
    local half = (x2 - x1) / 2
    -- две створки, открыты под углом ~70°
    for s = -1, 1, 2 do
      local hx = s < 0 and x1 or x2
      K.push(m)
      K.move(m, hx, y, zc)
      K.turn(m, s < 0 and 70 or -70, 0, 0)
      K.box(m, s < 0 and 0 or -half, 0, -0.03, s < 0 and half or 0, top - y, 0.03, mat, {})
      K.pop(m)
    end
  else
    local xc = (x1 + x2) / 2
    K.push(m)
    K.move(m, xc, y, z1)
    K.turn(m, 75, 0, 0)
    K.box(m, -0.03, 0, 0, 0.03, top - y, z2 - z1, mat, {})
    K.pop(m)
  end
end

return P
