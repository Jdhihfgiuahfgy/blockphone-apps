-- Цельные карты: описание предметами → клетки для игровой логики (maps.lua) и список предметов для вида (levelview.lua).
-- Карта (levels/<имя>.lua) строится так:
--   local L = require("levelgen").new{key = "...", name = "...", size = {ширина, глубина}, ...}
--   L:floor(x1, z1, x2, z2, {y = высота, mat = "текстура"})     -- пол (последний задаёт материал и высоту)
--   L:stairs(x1, z1, x2, z2, {from = y0, to = y1, dir = "+z"})   -- лестница/пандус ступенями по 0,25
--   L:block(x1, z1, x2, z2, {h = 5, facade = "...", ...})        -- дом без входа: стены до h, фасад с окнами
--   L:room(x1, z1, x2, z2, {floor = 0, ceil = 1.6, h = 4, ...})  -- дом с комнатой внутри: стены 0,5, потолок
--   L:door(x1, z1, x2, z2, {top = 1.3, leaf = "wood"})            -- проём в стене (дверь, арка)
--   L:window(x1, z1, x2, z2, {sill = 0.45, top = 1.05})           -- окно-проём: видно и стреляют, не пролезть
--   L:wall(x1, z1, x2, z2, {h = 0.55, kind = "stone|plaster|fence|mesh|sandbags"}) -- отдельная стенка/забор
--   L:prop("crate", x, z, {rot = 0, y = 0})                        -- предмет (ящик, бочка, машина…, см. PROPS)
--   L:site("A", x1, z1, x2, z2); L:spawn("T", x1, z1, x2, z2); L:lane("A", x, z)
--   return L:done()
-- Координаты — в блоках (1 блок ≈ 1,8 м), X — на восток, Z — на юг; всё кратно 0,5 (размер клетки).
-- В клетке: base — пол, top — верх твёрдого (стена — 99), roof — потолок, see — сквозь видно (сетка),
-- mat — материал пола, wtex/itex — текстура стены снаружи/внутри, bh — высота дома (для вида), c — символ для ботов.
local LG = {}
local floor, ceil, min, max = math.floor, math.ceil, math.min, math.max

-- Предметы: размер (вдоль X и Z при rot = 0), высота твёрдого, символ (x — запрыгнуть, X — нет).
LG.PROPS = {
  crate = {w = 1, d = 1, h = 0.62},           -- ящик (на него можно запрыгнуть)
  crate_big = {w = 1, d = 1, h = 1.1},        -- большой ящик
  crate_long = {w = 2, d = 1, h = 0.62},
  barrel = {w = 0.5, d = 0.5, h = 0.55},
  barrels = {w = 1, d = 1, h = 0.55},         -- 3–4 бочки кучкой
  pallets = {w = 1, d = 1, h = 0.32},
  sandbags = {w = 2, d = 0.5, h = 0.5},
  car = {w = 1, d = 2.5, h = 0.8},            -- легковая (носом к +Z)
  van = {w = 1.5, d = 3, h = 1.25},
  truck = {w = 1.5, d = 4.5, h = 1.6},
  dumpster = {w = 1.5, d = 1, h = 0.75},
  stall = {w = 2, d = 1, h = 0.45},           -- рыночный прилавок с навесом (стрелять поверх)
  planter = {w = 1, d = 1, h = 0.45},
  tree = {w = 0.5, d = 0.5, h = 99},          -- ствол; крона — только вид
  lamp = {w = 0.5, d = 0.5, h = 99, see = true},
  bench = {w = 1.5, d = 0.5, h = 0.25},
  cart = {w = 1, d = 1.5, h = 0.6},           -- деревянная тележка
  fountain = {w = 3, d = 3, h = 0.45},
  ac = {w = 1, d = 0.5, h = 0.6},             -- кондиционер у стены
  pole = {w = 0.5, d = 0.5, h = 99, see = true}, -- столб с проводами
}

local Builder = {}
Builder.__index = Builder

function LG.new(def)
  local b = setmetatable({def = def, ents = {}}, Builder)
  def.level = true
  def.cs = def.cs or 0.5
  def.size = def.size or {48, 48}
  def.lanes = def.lanes or {A = {}, B = {}}
  return b
end

local function add(b, e) b.ents[#b.ents + 1] = e return e end

function Builder:floor(x1, z1, x2, z2, o) return add(self, {t = "floor", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:stairs(x1, z1, x2, z2, o) return add(self, {t = "stairs", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:block(x1, z1, x2, z2, o) return add(self, {t = "block", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:room(x1, z1, x2, z2, o) return add(self, {t = "room", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:door(x1, z1, x2, z2, o) return add(self, {t = "door", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:window(x1, z1, x2, z2, o) return add(self, {t = "window", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:wall(x1, z1, x2, z2, o) return add(self, {t = "wall", x1 = x1, z1 = z1, x2 = x2, z2 = z2, o = o or {}}) end
function Builder:site(name, x1, z1, x2, z2) return add(self, {t = "site", name = name, x1 = x1, z1 = z1, x2 = x2, z2 = z2}) end
function Builder:spawn(team, x1, z1, x2, z2) return add(self, {t = "spawn", team = team, x1 = x1, z1 = z1, x2 = x2, z2 = z2}) end
function Builder:lane(site, x, z)
  local l = self.def.lanes[site] or {}
  l[#l + 1] = {x, z}
  self.def.lanes[site] = l
end

function Builder:prop(kind, x, z, o)
  o = o or {}
  local P = LG.PROPS[kind]
  if not P then error("levelgen: unknown prop " .. kind) end
  local rot = o.rot or 0
  local w, d = P.w, P.d
  if rot == 90 or rot == 270 then w, d = d, w end
  return add(self, {t = "prop", kind = kind, x = x, z = z, rot = rot, o = o, x1 = x - w / 2, x2 = x + w / 2, z1 = z - d / 2,
    z2 = z + d / 2, h = o.h or P.h, see = P.see})
end

function Builder:done()
  self.def.entities = self.ents
  return self.def
end

-- --- Раскладка в клетки ---

-- Клетки, чьи центры внутри прямоугольника.
local function cells(m, x1, z1, x2, z2, fn)
  local cs = m.cs
  local cx1, cz1 = max(0, floor(x1 / cs + 0.5)), max(0, floor(z1 / cs + 0.5))
  local cx2, cz2 = min(m.W - 1, ceil(x2 / cs - 0.5) - 1), min(m.H - 1, ceil(z2 / cs - 0.5) - 1)
  for cz = cz1, cz2 do
    for cx = cx1, cx2 do fn(cz * m.W + cx + 1, cx, cz) end
  end
end
LG.cells = cells

function LG.load(def, index)
  local cs = def.cs
  local W, H = floor(def.size[1] / cs + 0.5), floor(def.size[2] / cs + 0.5)
  local m = {def = def, index = index, W = W, H = H, cs = cs, c = {}, base = {}, top = {}, roof = {}, see = {}, mat = {},
    wtex = {}, itex = {}, bh = {}, kind = {}, owner = {}, spawns = {{}, {}}, site = {A = {}, B = {}}, flows = {}, flowCount = 0,
    wallH = def.wallH or 3, level = true}
  local defMat = def.ground or "city/des_road"
  -- всё, что не задано полом или комнатой, — застройка (дома без входа)
  for i = 1, W * H do
    m.c[i], m.base[i], m.top[i], m.mat[i] = "#", 0, 99, defMat
  end
  local function solid(i, top, wtex, itex, bh, owner)
    m.c[i], m.top[i] = "#", 99
    m.wtex[i], m.itex[i], m.bh[i], m.owner[i] = wtex, itex, bh, owner
    m.roof[i] = nil
  end
  local ents = def.entities
  -- 1. полы и лестницы
  for _, e in ipairs(ents) do
    if e.t == "floor" then
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        m.c[i] = "."
        m.base[i] = e.o.y or 0
        m.top[i] = m.base[i]
        if e.o.mat then m.mat[i] = e.o.mat end
      end)
    elseif e.t == "stairs" then
      local o = e.o
      local dir = o.dir or "+z"
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i, cx, cz)
        local x, z = (cx + 0.5) * cs, (cz + 0.5) * cs
        local t
        if dir == "+z" then t = (z - e.z1) / (e.z2 - e.z1)
        elseif dir == "-z" then t = (e.z2 - z) / (e.z2 - e.z1)
        elseif dir == "+x" then t = (x - e.x1) / (e.x2 - e.x1)
        else t = (e.x2 - x) / (e.x2 - e.x1) end
        local y = o.from + (o.to - o.from) * t
        y = floor(y / 0.25 + 0.5) * 0.25
        m.c[i] = "."
        m.base[i], m.top[i] = y, y
        if o.mat then m.mat[i] = o.mat end
        m.kind[i] = "stairs"
      end)
    end
  end
  -- 2. дома и комнаты
  for k, e in ipairs(ents) do
    local o = e.o
    if e.t == "block" then
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i) solid(i, 99, o.facade or def.facade, nil, o.h or m.wallH, k) end)
    elseif e.t == "room" then
      local fl, ce = o.floor or 0, o.ceil or 1.6
      local wt = 0.5
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i, cx, cz)
        local x, z = (cx + 0.5) * cs, (cz + 0.5) * cs
        local walls = o.walls or {n = true, s = true, e = true, w = true}
        local edge = (walls.w and x < e.x1 + wt) or (walls.e and x > e.x2 - wt) or (walls.n and z < e.z1 + wt) or (walls.s and z > e.z2 - wt)
        if edge then
          solid(i, 99, o.facade or def.facade, o.inwall or "city/des_inwall", o.h or m.wallH, k)
        else
          m.c[i], m.base[i], m.top[i] = ".", fl, fl
          m.roof[i] = fl + ce
          m.mat[i] = o.infloor or "city/des_infloor"
          m.owner[i] = k
          m.bh[i] = o.h or m.wallH
          m.itex[i] = o.inwall or "city/des_inwall"
          m.ceil = m.ceil or {}
          m.ceil[i] = o.ceiling or "city/des_ceiling"
          m.roofTex = m.roofTex or {}
          m.roofTex[i] = o.roof or "city/des_roof"
        end
      end)
    end
  end
  -- 3. проёмы: двери и окна
  for _, e in ipairs(ents) do
    local o = e.o
    if e.t == "door" or e.t == "window" then
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        if m.c[i] == "#" then
          local fl = o.y
          if not fl then
            -- пол проёма — как у соседа снаружи (самый низкий непустой рядом)
            local best = nil
            for _, n in ipairs({i - 1, i + 1, i - W, i + W}) do
              if n >= 1 and n <= W * H and m.c[n] ~= "#" then best = best and min(best, m.base[n]) or m.base[n] end
            end
            fl = best or 0
          end
          m.base[i] = fl
          if e.t == "door" then
            m.c[i], m.top[i] = ".", fl
            m.roof[i] = fl + (o.top or 1.3)
            m.kind[i] = "door"
          else
            m.c[i], m.top[i] = "W", fl + (o.sill or 0.45)
            m.roof[i] = fl + (o.top or 1.05)
            m.kind[i] = "window"
          end
          m.mat[i] = o.mat or m.mat[i]
        end
      end)
    end
  end
  -- 4. стенки и заборы
  for k, e in ipairs(ents) do
    if e.t == "wall" then
      local o = e.o
      local h = o.h or 0.55
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        m.top[i] = m.base[i] + h
        m.c[i] = h >= 99 and "#" or (h > 0.66 and "X" or "x")
        if o.kind == "mesh" then m.see[i] = true end
        m.kind[i] = "wall"
        m.owner[i] = k
      end)
    end
  end
  -- 5. предметы
  for k, e in ipairs(ents) do
    if e.t == "prop" then
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        local y = (e.o.y or m.base[i])
        e.y = e.y or y
        local t = e.h >= 99 and 99 or y + e.h
        if t > m.top[i] then
          m.top[i] = t
          m.c[i] = t >= 99 and "#" or (t - m.base[i] > 0.66 and "X" or "x")
        end
        if e.see then m.see[i] = true end
        m.kind[i] = "prop"
      end)
      e.y = e.y or 0
    end
  end
  -- 6. точки и базы
  for _, e in ipairs(ents) do
    if e.t == "site" then
      m.siteOf = m.siteOf or {}
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        m.siteOf[i] = e.name
        if m.c[i] == "." then m.c[i] = e.name end
        local list = m.site[e.name]
        list[#list + 1] = i
      end)
    elseif e.t == "spawn" then
      local team = e.team == "T" and 1 or 2
      cells(m, e.x1, e.z1, e.x2, e.z2, function(i)
        if m.c[i] == "." then
          m.c[i] = e.team == "T" and "T" or "C"
          local list = m.spawns[team]
          list[#list + 1] = i
        end
      end)
    end
  end
  -- застройка: свободные от комнат сплошные клетки — прямоугольники-дома (жадно по строкам), у каждого своя
  -- высота и фасад; список — для вида (levelview.lua)
  local hash = function(a, b) return ((a * 73856093 + b * 19349663) % 1000003) / 1000003 end
  local facades = def.facades or {def.facade or "city/des_plaster"}
  local used = {}
  m.blocks = {}
  for cz = 0, H - 1 do
    for cx = 0, W - 1 do
      local i = cz * W + cx + 1
      if m.c[i] == "#" and not m.owner[i] and not used[i] then
        local w = 1
        while cx + w < W and m.c[i + w] == "#" and not m.owner[i + w] and not used[i + w] and w < 24 do w = w + 1 end
        local h = 1
        local ok = true
        while ok and cz + h < H and h < 24 do
          for k2 = 0, w - 1 do
            local j = (cz + h) * W + cx + k2 + 1
            if m.c[j] ~= "#" or m.owner[j] or used[j] then ok = false break end
          end
          if ok then h = h + 1 end
        end
        local b = #m.blocks + 1
        local r = hash(cx * 7 + 3, cz * 13 + 5)
        local edge = cx == 0 or cz == 0 or cx + w == W or cz + h == H
        local bh = m.wallH + 0.5 + floor(r * 6) * 0.5 + (edge and 2.5 or 0)
        local tex = facades[1 + floor(hash(cz + 11, cx + 29) * #facades)]
        m.blocks[b] = {x1 = cx * cs, z1 = cz * cs, x2 = (cx + w) * cs, z2 = (cz + h) * cs, h = bh, tex = tex}
        for dz = 0, h - 1 do
          for dx = 0, w - 1 do
            local j = (cz + dz) * W + cx + dx + 1
            used[j] = true
            m.bh[j], m.wtex[j], m.owner[j] = bh, tex, -b
          end
        end
      end
    end
  end
  -- клетки точек, занятые предметами, — не для ботов (они ставят бомбу на свободной)
  for _, s in ipairs({"A", "B"}) do
    local free = {}
    for _, i in ipairs(m.site[s]) do if m.c[i] == s then free[#free + 1] = i end end
    if #free > 0 then m.site[s] = free end
  end
  return m
end

return LG
