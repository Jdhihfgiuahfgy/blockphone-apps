-- 3D-модели оружия, гранат, бомбы и ножа (kit.lua). Единицы — метры, +Z — к дулу, +Y — вверх, +X — вправо;
-- начало координат — у спускового крючка. Каждая модель возвращает таблицу:
--   build(m) — детали в построитель kit; grip — где правая рука (кисть на рукояти), fore — левая (цевьё/магазин),
--   muzzle — дуло (вспышка), pos — где модель у экрана (от глаза: вправо, вниз, вперёд), kind — вид (анимации).
local K = require("kit")

local G = {}
local P = K.pts

-- --- Общие части ---

local function cylZ(m, z1, z2, y, r1, r2, mat, seg, o)
  K.cyl(m, {0, y, z1}, {0, y, z2}, r1, r2 or r1, seg or 10, mat, o)
end

-- Пистолетная рукоять (наклон назад) с насечкой, спусковая скоба и крючок.
local function lower(m, o)
  o = o or {}
  local gm, w = o.grip or "gun_black", o.gw or 0.016
  local top, bot = o.top or -0.008, o.bot or -0.112
  local z0, z1, back = o.z0 or -0.022, o.z1 or -0.058, o.back or 0.04
  K.prism(m, {{z0, top}, {z1, top}, {z1 - back, bot}, {z0 - back + 0.008, bot}}, -w, w, gm, {round = 0.5})
  K.box(m, -w * 1.05, bot - 0.006, z1 - back - 0.004, w * 1.05, bot, z0 - back + 0.012, gm, {soft = 0.6})
  if not o.noGuard then
    local gy = o.guardY or -0.04
    K.box(m, -0.005, gy - 0.005, z0 - 0.002, 0.005, gy, (o.guardZ or 0.035), o.guardMat or gm)
    K.box(m, -0.005, gy - 0.003, (o.guardZ or 0.035) - 0.006, 0.005, top, (o.guardZ or 0.035), o.guardMat or gm)
    K.box(m, -0.003, gy + 0.006, -0.004, 0.003, top, 0.004, "gun_steel", {tilt = 12})
  end
end

-- Планка Пикатинни: брусок с поперечными рёбрами.
local function rail(m, z1, z2, y, w, mat)
  w = w or 0.011
  mat = mat or "gun_black"
  K.box(m, -w, y, z1, w, y + 0.008, z2, mat)
  local n = math.floor((z2 - z1) / 0.012)
  for k = 0, n - 1 do
    local z = z1 + 0.004 + k * 0.012
    K.box(m, -w * 1.15, y + 0.008, z, w * 1.15, y + 0.013, z + 0.007, mat)
  end
end

-- Оптический прицел: труба с объективом и окуляром, кольца.
local function scope(m, z1, z2, y, r, o)
  o = o or {}
  local mat = o.mat or "gun_black"
  cylZ(m, z1, z1 + 0.04, y, r * 1.25, r, mat, 14)
  cylZ(m, z1 + 0.04, z2 - 0.06, y, r * 0.78, r * 0.78, mat, 14)
  cylZ(m, z2 - 0.06, z2, y, r * 0.9, r * 1.35, mat, 14, {capMat = "scope_glass"})
  K.cyl(m, {0, y, z1 - 0.002}, {0, y, z1}, r * 1.2, r * 1.2, 14, "scope_glass")
  K.box(m, -0.008, y + r * 0.7, (z1 + z2) / 2 - 0.012, 0.008, y + r * 1.05, (z1 + z2) / 2 + 0.012, mat, {soft = 0.5})
  K.box(m, r * 0.7, y - 0.008, (z1 + z2) / 2 - 0.012, r * 1.05, y + 0.008, (z1 + z2) / 2 + 0.012, mat, {soft = 0.5})
  for _, z in ipairs(o.rings or {z1 + 0.06, z2 - 0.09}) do
    K.cyl(m, {0, y, z - 0.008}, {0, y, z + 0.008}, r * 0.92, r * 0.92, 12, "gun_metal")
    K.box(m, -0.008, o.base or (y - r - 0.012), z - 0.008, 0.008, y - r * 0.7, z + 0.008, "gun_metal")
  end
end

-- Коллиматор (красная точка) на планке.
local function reddot(m, z, y)
  K.box(m, -0.012, y, z - 0.02, 0.012, y + 0.012, z + 0.02, "gun_black", {soft = 0.5})
  K.cyl(m, {0, y + 0.03, z - 0.018}, {0, y + 0.03, z + 0.018}, 0.016, 0.017, 12, "gun_black", {capMat = "scope_glass"})
end

-- Глушитель.
local function suppressor(m, z, y, r, len)
  cylZ(m, z, z + 0.012, y, r * 0.7, r, "gun_metal", 12)
  cylZ(m, z + 0.012, z + len, y, r, r, "black_matte", 14)
  cylZ(m, z + len, z + len + 0.006, y, r, r * 0.85, "gun_metal", 14)
end

-- --- Пистолеты ---

-- Затвор + рамка + рукоять. o: len (длина затвора), h, w, back (зад затвора), slide/frame/grip — материалы,
-- muzzleExt (ствол торчит), serr — насечки, suppressor, rail.
local function pistol(o)
  local len, h, w, back = o.len or 0.185, o.h or 0.03, o.w or 0.0135, o.back or -0.07
  return {
    kind = "pistol", pos = o.pos or {0.072, -0.072, 0.30}, grip = {0, -0.07, -0.05}, fore = {-0.012, -0.08, -0.04},
    muzzle = {0, h * 0.55 + 0.004, back + len + (o.suppressor and 0.16 or 0.006) + (o.muzzleExt or 0)},
    build = function(m)
      local sm = o.slide or "gun_metal"
      -- затвор со скосами
      K.prism(m, {{back, 0.004}, {back + len, 0.004}, {back + len, h - 0.004}, {back + len - 0.008, h},
        {back + 0.006, h}, {back, h - 0.006}}, -w, w, sm, {round = 0.25})
      -- насечки
      for k = 0, (o.serr or 6) - 1 do
        local z = back + 0.012 + k * 0.006
        K.box(m, -w - 0.0008, h * 0.25, z, w + 0.0008, h * 0.85, z + 0.0025, "gun_black")
      end
      -- окно выброса гильзы
      K.box(m, w - 0.001, h * 0.45, back + len * 0.45, w + 0.0006, h * 0.92, back + len * 0.7, "gun_black")
      -- мушка и целик
      K.box(m, -0.0025, h, back + len - 0.018, 0.0025, h + 0.006, back + len - 0.01, "gun_black")
      K.box(m, -w * 0.8, h, back + 0.004, w * 0.8, h + 0.007, back + 0.012, "gun_black")
      -- ствол
      cylZ(m, back + len - 0.01, back + len + 0.006 + (o.muzzleExt or 0), h * 0.55 + 0.004, 0.0065, 0.0065, "gun_steel", 10)
      -- рамка
      local fm = o.frame or "gun_black"
      K.prism(m, {{back + 0.01, 0.004}, {back + len - 0.012, 0.004}, {back + len - 0.012, -0.006}, {0.04, -0.012},
        {-0.03, -0.012}, {back + 0.01, -0.006}}, -w * 0.92, w * 0.92, fm, {round = 0.3})
      if o.rail ~= false then
        for k = 0, 2 do
          local z = back + len - 0.06 + k * 0.012
          K.box(m, -w * 0.9, -0.016, z, w * 0.9, -0.012, z + 0.006, fm)
        end
      end
      lower(m, {grip = o.grip or fm, gw = w * 1.05, z0 = -0.018, z1 = -0.055, back = 0.022, bot = o.gripBot or -0.105,
        guardY = -0.035, guardZ = 0.03, guardMat = fm})
      -- курок / хвост рамки
      K.box(m, -0.005, h * 0.2, back - 0.008, 0.005, h * 0.7, back, "gun_steel", {tilt = -20})
      if o.suppressor then suppressor(m, back + len + 0.006, h * 0.55 + 0.004, 0.015, 0.155) end
      if o.extra then o.extra(m) end
    end,
  }
end

G.glock = pistol({len = 0.18, slide = "gun_black", frame = "gun_black", serr = 7})
G.usp = pistol({len = 0.2, suppressor = true, slide = "gun_metal", frame = "gun_black", pos = {0.072, -0.07, 0.27}})
G.p2000 = pistol({len = 0.185, slide = "gun_metal", frame = "gun_black"})
G.p250 = pistol({len = 0.18, slide = "gun_steel", frame = "gun_black"})
G.fiveseven = pistol({len = 0.2, h = 0.032, slide = "gun_black", frame = "poly_fde", grip = "poly_fde", serr = 8})
G.cz75 = pistol({len = 0.19, h = 0.028, slide = "gun_blued", frame = "gun_blued", grip = "wood_dark",
  extra = function(m) K.box(m, -0.012, -0.11, -0.03, 0.012, -0.03, 0.005, "gun_blued") end})
G.deagle = pistol({len = 0.25, h = 0.04, w = 0.017, back = -0.085, slide = "gun_silver", frame = "gun_steel",
  grip = "black_matte", serr = 8, pos = {0.075, -0.078, 0.29},
  extra = function(m)
    -- характерный треугольный «нос» и планка сверху
    K.box(m, -0.012, 0.04, -0.06, 0.012, 0.046, 0.15, "gun_silver")
  end})

-- Две «Беретты»: модель — одна, вторая рисуется в левой руке (dual).
G.dualies = pistol({len = 0.19, slide = "gun_silver", frame = "gun_silver", grip = "black_matte", muzzleExt = 0.008,
  extra = function(m) K.box(m, -0.0142, 0.012, -0.02, 0.0142, 0.024, 0.1, "gun_black") end})
G.dualies.dual = true

-- Tec-9: магазин перед спуском, прямой корпус.
G.tec9 = {kind = "pistol", pos = {0.07, -0.07, 0.29}, grip = {0, -0.07, -0.05}, fore = {-0.01, -0.13, 0.05},
  muzzle = {0, 0.022, 0.22},
  build = function(m)
    K.prism(m, P("-0.09,0.0 0.13,0.0 0.13,0.035 0.11,0.04 -0.08,0.04 -0.09,0.03"), -0.016, 0.016, "gun_black", {round = 0.3})
    cylZ(m, 0.13, 0.2, 0.022, 0.012, 0.012, "gun_black", 12) -- кожух ствола
    for k = 0, 4 do K.box(m, -0.0125, 0.03, 0.135 + k * 0.012, 0.0125, 0.034, 0.142 + k * 0.012, "gun_metal") end
    cylZ(m, 0.2, 0.22, 0.022, 0.006, 0.006, "gun_steel")
    K.box(m, -0.012, -0.17, 0.03, 0.012, 0.0, 0.065, "mag_steel", {tilt = 6})
    lower(m, {grip = "gun_black", gw = 0.016, back = 0.025, bot = -0.1, guardZ = 0.03})
    K.box(m, 0.016, 0.018, -0.03, 0.026, 0.03, -0.01, "gun_steel")
  end}

-- R8: револьвер с барабаном.
G.r8 = {kind = "pistol", pos = {0.074, -0.074, 0.29}, grip = {0, -0.07, -0.06}, fore = {-0.012, -0.08, -0.05},
  muzzle = {0, 0.026, 0.2},
  build = function(m)
    K.prism(m, P("-0.06,0.0 0.03,0.0 0.03,0.045 -0.04,0.045 -0.06,0.03"), -0.012, 0.012, "gun_steel", {round = 0.3})
    K.cyl(m, {0, 0.018, -0.005}, {0, 0.018, 0.04}, 0.02, 0.02, 12, "gun_silver", {flat = true})
    cylZ(m, 0.03, 0.2, 0.026, 0.0085, 0.0085, "gun_steel", 12)
    K.box(m, -0.006, 0.022, 0.04, 0.006, 0.037, 0.2, "gun_steel")
    K.box(m, -0.0025, 0.037, 0.18, 0.0025, 0.045, 0.195, "gun_black")
    cylZ(m, 0.04, 0.17, 0.008, 0.004, 0.004, "gun_steel", 8)
    lower(m, {grip = "wood_dark", gw = 0.016, back = 0.035, bot = -0.105, z0 = -0.03, z1 = -0.065, guardZ = 0.02})
    K.box(m, -0.004, 0.03, -0.075, 0.004, 0.05, -0.058, "gun_steel", {tilt = -30})
  end}

-- --- Пистолеты-пулемёты ---

G.mac10 = {kind = "smg", pos = {0.085, -0.085, 0.28}, grip = {0, -0.075, -0.03}, fore = {-0.005, -0.15, -0.02},
  muzzle = {0, 0.028, 0.2},
  build = function(m)
    K.prism(m, P("-0.12,0.0 0.13,0.0 0.13,0.055 -0.12,0.055"), -0.022, 0.022, "gun_black", {round = 0.2})
    cylZ(m, 0.13, 0.2, 0.028, 0.008, 0.008, "gun_steel")
    K.box(m, -0.014, -0.22, -0.05, 0.014, 0.0, -0.012, "mag_steel")
    K.box(m, -0.016, -0.12, -0.055, 0.016, 0.0, -0.008, "gun_black", {soft = 0.4})
    K.box(m, -0.005, -0.04, -0.002, 0.005, 0.0, 0.035, "gun_black")
    K.box(m, -0.006, 0.055, 0.05, 0.006, 0.065, 0.1, "gun_metal") -- ручка затвора
    -- складной приклад-проволока
    K.box(m, 0.018, 0.012, -0.32, 0.022, 0.018, -0.12, "gun_steel")
    K.box(m, -0.022, 0.012, -0.32, -0.018, 0.018, -0.12, "gun_steel")
    K.box(m, -0.022, -0.03, -0.33, 0.022, 0.02, -0.318, "gun_steel")
    K.box(m, -0.018, -0.005, 0.13, 0.018, 0.0, 0.15, "rubber")
  end}

G.mp9 = {kind = "smg", pos = {0.085, -0.085, 0.28}, grip = {0, -0.07, -0.04}, fore = {0, -0.1, 0.075},
  muzzle = {0, 0.026, 0.26},
  build = function(m)
    K.prism(m, P("-0.11,0.0 0.17,0.0 0.17,0.045 0.15,0.05 -0.1,0.05 -0.11,0.04"), -0.021, 0.021, "gun_black", {round = 0.3})
    rail(m, -0.09, 0.15, 0.05, 0.01)
    cylZ(m, 0.17, 0.26, 0.026, 0.0085, 0.0085, "gun_steel")
    K.box(m, -0.015, -0.2, -0.065, 0.015, 0.0, -0.028, "gun_black", {tilt = 4, soft = 0.3})
    K.box(m, -0.012, -0.21, -0.064, 0.012, -0.195, -0.03, "mag_steel")
    K.box(m, -0.012, -0.1, 0.06, 0.012, 0.0, 0.09, "gun_black", {tilt = 10, soft = 0.4}) -- передняя рукоятка
    K.box(m, -0.005, -0.035, -0.02, 0.005, 0.0, 0.03, "gun_black")
    K.box(m, -0.006, 0.0, -0.34, 0.006, 0.018, -0.11, "gun_black")
    K.box(m, -0.018, -0.05, -0.355, 0.018, 0.02, -0.335, "gun_black", {soft = 0.4})
  end}

G.mp7 = {kind = "smg", pos = {0.085, -0.085, 0.27}, grip = {0, -0.075, -0.05}, fore = {0, -0.1, 0.1},
  muzzle = {0, 0.028, 0.26},
  build = function(m)
    K.prism(m, P("-0.16,0.0 0.17,0.0 0.17,0.05 0.15,0.058 -0.15,0.058 -0.16,0.045"), -0.022, 0.022, "gun_black", {round = 0.3})
    rail(m, -0.14, 0.14, 0.058, 0.011)
    cylZ(m, 0.17, 0.26, 0.028, 0.008, 0.008, "gun_steel")
    K.box(m, -0.014, -0.21, -0.07, 0.014, 0.0, -0.035, "mag_steel", {tilt = 6})
    lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.03, z1 = -0.075, back = 0.01, bot = -0.11})
    K.box(m, -0.011, -0.11, 0.085, 0.011, 0.0, 0.115, "gun_black", {tilt = 8, soft = 0.4})
    K.box(m, -0.02, -0.01, -0.28, 0.02, 0.04, -0.16, "gun_black")
    K.box(m, -0.022, -0.05, -0.29, 0.022, 0.045, -0.275, "rubber", {soft = 0.4})
    reddot(m, 0.0, 0.07)
  end}

G.mp5sd = {kind = "smg", pos = {0.085, -0.088, 0.25}, grip = {0, -0.075, -0.07}, fore = {0, -0.025, 0.12},
  muzzle = {0, 0.025, 0.42},
  build = function(m)
    K.prism(m, P("-0.17,0.0 0.08,0.0 0.08,0.055 -0.17,0.055"), -0.021, 0.021, "gun_metal", {round = 0.3})
    K.box(m, -0.018, 0.055, -0.14, 0.018, 0.064, 0.06, "gun_metal")
    K.box(m, -0.004, 0.055, 0.0, 0.004, 0.075, 0.012, "gun_black")
    cylZ(m, 0.08, 0.4, 0.025, 0.023, 0.023, "black_matte", 14) -- встроенный глушитель
    cylZ(m, 0.4, 0.42, 0.025, 0.023, 0.018, "gun_metal", 14)
    K.prism(m, P("0.0,-0.005 0.012,-0.005 0.05,-0.18 0.035,-0.185 0.0,-0.08"), -0.013, 0.013, "mag_steel")
    lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.04, z1 = -0.08, back = 0.03, bot = -0.115})
    K.prism(m, P("0.08,0.0 0.2,0.0 0.2,0.04 0.08,0.04"), -0.024, 0.024, "gun_black", {round = 0.5})
    K.box(m, -0.02, 0.0, -0.36, 0.02, 0.05, -0.17, "gun_black")
    K.box(m, -0.022, -0.06, -0.37, 0.022, 0.052, -0.35, "rubber", {soft = 0.4})
  end}

G.ump45 = {kind = "smg", pos = {0.085, -0.088, 0.25}, grip = {0, -0.075, -0.07}, fore = {0, -0.03, 0.12},
  muzzle = {0, 0.027, 0.33},
  build = function(m)
    K.prism(m, P("-0.17,-0.01 0.22,-0.01 0.22,0.045 0.2,0.06 -0.16,0.06 -0.17,0.04"), -0.024, 0.024, "gun_black", {round = 0.35})
    rail(m, -0.15, 0.1, 0.06, 0.012)
    cylZ(m, 0.22, 0.33, 0.027, 0.009, 0.009, "gun_steel")
    K.box(m, -0.016, -0.19, 0.0, 0.016, 0.0, 0.05, "gun_black", {tilt = 3})
    lower(m, {grip = "gun_black", gw = 0.018, z0 = -0.04, z1 = -0.085, back = 0.025, bot = -0.12})
    K.box(m, -0.02, -0.04, -0.36, 0.02, 0.05, -0.17, "gun_black")
    K.box(m, -0.022, -0.07, -0.37, 0.022, 0.05, -0.35, "rubber", {soft = 0.4})
  end}

G.p90 = {kind = "smg", pos = {0.088, -0.08, 0.22}, grip = {0, -0.08, 0.0}, fore = {0, -0.05, 0.14},
  muzzle = {0, 0.0, 0.29},
  build = function(m)
    K.prism(m, P("-0.32,-0.09 -0.12,-0.09 -0.05,-0.04 0.18,-0.04 0.25,0.0 0.25,0.02 0.18,0.04 -0.3,0.04 -0.33,0.0"),
      -0.032, 0.032, "p90_body", {round = 0.6, smooth = 55})
    K.box(m, -0.026, 0.04, -0.16, 0.026, 0.06, 0.16, "gun_black", {soft = 0.3}) -- магазин сверху
    K.box(m, -0.024, 0.06, -0.15, 0.024, 0.064, 0.15, "scope_glass")
    K.box(m, -0.02, 0.064, -0.04, 0.02, 0.09, 0.06, "gun_black", {soft = 0.4}) -- прицел
    cylZ(m, 0.25, 0.29, 0.0, 0.008, 0.008, "gun_steel")
    K.prism(m, P("-0.06,-0.04 0.06,-0.04 0.04,-0.11 -0.03,-0.11"), -0.03, 0.03, "p90_body", {round = 0.5})
  end}

G.bizon = {kind = "smg", pos = {0.085, -0.088, 0.25}, grip = {0, -0.075, -0.07}, fore = {0, -0.06, 0.12},
  muzzle = {0, 0.028, 0.32},
  build = function(m)
    K.prism(m, P("-0.15,0.0 0.13,0.0 0.13,0.055 -0.15,0.055"), -0.022, 0.022, "gun_metal", {round = 0.3})
    K.prism(m, P("0.13,0.0 0.24,0.005 0.24,0.05 0.13,0.055"), -0.02, 0.02, "wood_dark", {round = 0.4})
    cylZ(m, 0.24, 0.32, 0.028, 0.009, 0.009, "gun_steel")
    K.cyl(m, {0, -0.04, -0.01}, {0, -0.04, 0.24}, 0.028, 0.028, 14, "gun_black") -- шнековый магазин
    lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.04, z1 = -0.08, back = 0.03, bot = -0.115})
    K.box(m, -0.006, -0.005, -0.4, 0.006, 0.012, -0.15, "gun_steel")
    K.box(m, -0.006, -0.06, -0.4, 0.006, -0.045, -0.2, "gun_steel")
    K.box(m, -0.02, -0.08, -0.41, 0.02, 0.02, -0.395, "gun_metal", {soft = 0.4})
  end}

-- --- Винтовки ---

local function akBody(m, o)
  -- ствольная коробка, крышка, приклад, цевьё, газовая трубка, ствол
  local wood = o.wood or "wood_red"
  K.prism(m, P("-0.14,0.0 0.13,0.0 0.13,0.055 -0.14,0.055"), -0.024, 0.024, o.recv or "gun_metal", {round = 0.25})
  K.prism(m, P("-0.13,0.055 0.1,0.055 0.1,0.062 0.08,0.07 -0.12,0.07 -0.13,0.064"), -0.021, 0.021, o.recv or "gun_metal",
    {round = 0.6, smooth = 60})
  if o.stock ~= false then
    K.prism(m, P("-0.14,0.052 -0.14,-0.005 -0.46,-0.07 -0.47,-0.07 -0.47,0.03 -0.44,0.036"), -0.02, 0.02, o.stockMat or wood,
      {round = 0.6, smooth = 50})
    K.box(m, -0.021, -0.075, -0.48, 0.021, 0.035, -0.468, "gun_metal", {tilt = -4})
  end
  K.prism(m, P("0.13,0.0 0.31,0.002 0.31,0.048 0.13,0.05 0.13,0.0"), -0.025, 0.025, o.hand or wood, {round = 0.6, smooth = 60})
  K.cyl(m, {0, 0.064, 0.12}, {0, 0.064, 0.31}, 0.014, 0.013, 12, o.hand or wood)
  K.box(m, -0.012, 0.03, 0.31, 0.012, 0.074, 0.34, "gun_metal", {soft = 0.3})
  cylZ(m, 0.31, o.barrelEnd or 0.55, 0.035, 0.0092, 0.0092, "gun_steel", 10)
  cylZ(m, 0.34, (o.barrelEnd or 0.55) - 0.06, 0.016, 0.003, 0.003, "gun_steel", 6)
  K.box(m, -0.004, 0.035, (o.barrelEnd or 0.55) - 0.07, 0.004, 0.08, (o.barrelEnd or 0.55) - 0.055, "gun_metal", {taper = 0.5})
  K.box(m, -0.012, 0.055, 0.1, 0.012, 0.075, 0.13, "gun_metal") -- целик
  K.box(m, 0.024, 0.03, 0.02, 0.04, 0.042, 0.04, "gun_steel", {soft = 0.5}) -- рукоятка затвора
  K.box(m, 0.024, 0.008, -0.11, 0.027, 0.02, 0.0, "gun_steel") -- переводчик
end

G.ak47 = {kind = "rifle", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.07}, fore = {0, -0.005, 0.22},
  muzzle = {0, 0.035, 0.61},
  build = function(m)
    akBody(m, {})
    cylZ(m, 0.55, 0.61, 0.035, 0.0135, 0.0135, "gun_metal", 12) -- дульный тормоз
    K.prism(m, P("0.0,0.0 0.075,0.0 0.1,-0.07 0.115,-0.14 0.11,-0.2 0.06,-0.205 0.055,-0.15 0.04,-0.085 0.005,-0.02"),
      -0.014, 0.014, "mag_steel", {round = 0.4, smooth = 50})
    for k = 0, 3 do
      local y = -0.04 - k * 0.04
      K.box(m, -0.0146, y - 0.004, 0.045 + k * 0.012, 0.0146, y + 0.002, 0.075 + k * 0.012, "gun_black", {tilt = 25})
    end
    lower(m, {grip = "wood_red", gw = 0.016, z0 = -0.035, z1 = -0.07, back = 0.04, bot = -0.12, guardZ = 0.0})
  end}

G.galil = {kind = "rifle", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.07}, fore = {0, -0.005, 0.21},
  muzzle = {0, 0.035, 0.6},
  build = function(m)
    akBody(m, {recv = "poly_od", hand = "wood_light", stock = false, barrelEnd = 0.56})
    K.box(m, -0.006, -0.05, -0.42, 0.006, -0.035, -0.14, "gun_metal")
    K.box(m, -0.006, 0.02, -0.42, 0.006, 0.035, -0.14, "gun_metal")
    K.box(m, -0.02, -0.065, -0.43, 0.02, 0.045, -0.415, "rubber", {soft = 0.4})
    cylZ(m, 0.56, 0.6, 0.035, 0.012, 0.012, "gun_black")
    K.prism(m, P("0.0,0.0 0.06,0.0 0.08,-0.09 0.085,-0.18 0.04,-0.185 0.035,-0.1 0.005,-0.02"), -0.014, 0.014, "gun_black",
      {round = 0.4})
    lower(m, {grip = "gun_black", gw = 0.016, z0 = -0.035, z1 = -0.07, back = 0.035, bot = -0.12, guardZ = 0.0})
  end}

-- AR-15: M4A4, M4A1-S.
local function ar15(m, o)
  K.prism(m, P("-0.15,0.0 0.08,0.0 0.08,0.048 -0.15,0.048"), -0.024, 0.024, "gun_black", {round = 0.3})
  K.prism(m, P("-0.12,0.0 0.0,-0.002 0.02,-0.015 -0.1,-0.015"), -0.02, 0.02, "gun_black")
  rail(m, -0.14, 0.07, 0.048, 0.012)
  -- цевьё с отверстиями
  K.prism(m, P("0.08,-0.006 0.31,-0.006 0.31,0.054 0.08,0.054"), -0.026, 0.026, o.hand or "gun_metal", {round = 0.5, smooth = 60})
  for k = 0, 6 do
    local z = 0.1 + k * 0.028
    K.box(m, -0.0265, 0.012, z, 0.0265, 0.03, z + 0.012, "gun_black")
  end
  rail(m, 0.09, 0.3, 0.054, 0.011)
  -- приклад: труба + регулируемый
  cylZ(m, -0.31, -0.15, 0.03, 0.013, 0.013, "gun_black", 10)
  K.prism(m, P("-0.33,0.05 -0.2,0.045 -0.2,0.005 -0.32,-0.04 -0.34,-0.045 -0.345,0.05"), -0.022, 0.022, "gun_black",
    {round = 0.5})
  K.box(m, -0.023, -0.05, -0.355, 0.023, 0.055, -0.34, "rubber", {soft = 0.4})
  -- прямой магазин (слегка изогнутый)
  K.prism(m, P("-0.005,0.0 0.055,0.0 0.065,-0.08 0.07,-0.15 0.025,-0.155 0.02,-0.08 0.0,-0.02"), -0.013, 0.013, "mag_steel",
    {round = 0.4})
  K.box(m, -0.016, -0.03, -0.003, 0.016, 0.0, 0.062, "gun_black")
  lower(m, {grip = "gun_black", gw = 0.016, z0 = -0.03, z1 = -0.065, back = 0.035, bot = -0.12, guardZ = 0.005})
  K.box(m, 0.024, 0.02, -0.03, 0.03, 0.034, -0.005, "gun_black") -- досылатель
  K.box(m, -0.012, 0.048, -0.15, 0.012, 0.062, -0.13, "gun_black") -- ручка затвора сзади
  cylZ(m, 0.31, o.barrel or 0.5, 0.03, 0.0085, 0.0085, "gun_black", 10)
  K.box(m, -0.005, 0.03, 0.4, 0.005, 0.085, 0.416, "gun_black", {taper = 0.4}) -- мушка
end

G.m4a4 = {kind = "rifle", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.065}, fore = {0, -0.01, 0.2},
  muzzle = {0, 0.03, 0.56},
  build = function(m)
    ar15(m, {})
    cylZ(m, 0.5, 0.56, 0.03, 0.012, 0.011, "gun_black", 10)
    K.box(m, -0.011, 0.06, -0.12, 0.011, 0.075, -0.09, "gun_black") -- целик
  end}

G.m4a1s = {kind = "rifle", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.065}, fore = {0, -0.01, 0.2},
  muzzle = {0, 0.03, 0.68},
  build = function(m)
    ar15(m, {hand = "gun_black", barrel = 0.46})
    suppressor(m, 0.46, 0.03, 0.017, 0.21)
    K.box(m, -0.011, 0.06, -0.12, 0.011, 0.075, -0.09, "gun_black")
  end}

G.famas = {kind = "rifle", pos = {0.092, -0.09, 0.15}, grip = {0, -0.09, 0.04}, fore = {0, -0.06, 0.2},
  muzzle = {0, 0.0, 0.46},
  build = function(m)
    K.prism(m, P("-0.42,-0.075 -0.18,-0.06 0.24,-0.06 0.26,-0.03 0.26,0.035 -0.4,0.035 -0.43,0.0"), -0.03, 0.03, "poly_grey",
      {round = 0.6, smooth = 55})
    K.box(m, -0.007, 0.035, 0.12, 0.007, 0.08, 0.15, "gun_black")
    K.box(m, -0.007, 0.035, -0.2, 0.007, 0.08, -0.17, "gun_black")
    K.box(m, -0.011, 0.075, -0.22, 0.011, 0.092, 0.17, "gun_black", {soft = 0.4}) -- ручка для переноски
    lower(m, {grip = "gun_black", gw = 0.017, top = -0.06, z0 = 0.06, z1 = 0.02, back = 0.03, bot = -0.17,
      guardY = -0.09, guardZ = 0.11})
    K.box(m, -0.016, -0.2, -0.18, 0.016, -0.06, -0.12, "mag_steel", {tilt = 4})
    cylZ(m, 0.26, 0.42, 0.0, 0.009, 0.009, "gun_steel")
    cylZ(m, 0.42, 0.46, 0.0, 0.012, 0.012, "gun_black")
    K.box(m, -0.031, -0.075, -0.44, 0.031, 0.04, -0.425, "rubber", {soft = 0.5})
    -- сошки сложены
    K.box(m, -0.012, -0.015, 0.26, -0.006, -0.008, 0.4, "gun_metal")
    K.box(m, 0.006, -0.015, 0.26, 0.012, -0.008, 0.4, "gun_metal")
  end}

G.sg553 = {kind = "rifle", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.07}, fore = {0, -0.01, 0.2},
  muzzle = {0, 0.032, 0.58},
  build = function(m)
    K.prism(m, P("-0.15,0.0 0.1,0.0 0.1,0.052 -0.15,0.052"), -0.024, 0.024, "gun_black", {round = 0.3})
    K.prism(m, P("0.1,-0.004 0.31,-0.004 0.31,0.052 0.1,0.052"), -0.027, 0.027, "poly_fde", {round = 0.6, smooth = 60})
    for k = 0, 5 do K.box(m, -0.0275, 0.01, 0.12 + k * 0.03, 0.0275, 0.03, 0.135 + k * 0.03, "gun_black") end
    cylZ(m, 0.31, 0.58, 0.032, 0.009, 0.009, "gun_black")
    cylZ(m, 0.52, 0.58, 0.032, 0.012, 0.012, "gun_metal")
    K.prism(m, P("-0.15,0.045 -0.15,0.0 -0.42,-0.05 -0.43,-0.05 -0.43,0.045"), -0.02, 0.02, "poly_fde", {round = 0.6})
    K.box(m, -0.021, -0.055, -0.44, 0.021, 0.05, -0.43, "rubber")
    K.prism(m, P("0.0,0.0 0.06,0.0 0.075,-0.09 0.08,-0.17 0.035,-0.175 0.03,-0.09 0.0,-0.02"), -0.014, 0.014, "poly_od",
      {round = 0.4})
    lower(m, {grip = "gun_black", gw = 0.016, z0 = -0.035, z1 = -0.07, back = 0.035, bot = -0.12, guardZ = 0.0})
    scope(m, -0.12, 0.08, 0.085, 0.017, {rings = {-0.07, 0.03}, base = 0.052})
  end}

G.aug = {kind = "rifle", pos = {0.092, -0.09, 0.14}, grip = {0, -0.09, 0.05}, fore = {0, -0.1, 0.2},
  muzzle = {0, 0.0, 0.47},
  build = function(m)
    K.prism(m, P("-0.44,-0.07 -0.2,-0.075 0.1,-0.07 0.17,-0.03 0.17,0.03 -0.42,0.03 -0.45,-0.01"), -0.034, 0.034, "poly_od",
      {round = 0.7, smooth = 60})
    lower(m, {grip = "poly_od", gw = 0.018, top = -0.07, z0 = 0.07, z1 = 0.03, back = 0.025, bot = -0.17, guardY = -0.1,
      guardZ = 0.13})
    K.box(m, -0.012, -0.17, 0.15, 0.012, -0.07, 0.18, "poly_od", {tilt = -10, soft = 0.5}) -- вертикальная рукоятка
    K.box(m, -0.016, -0.2, -0.17, 0.016, -0.07, -0.11, "scope_glass", {tilt = 4})
    cylZ(m, 0.17, 0.43, 0.0, 0.0095, 0.0095, "gun_steel")
    cylZ(m, 0.43, 0.47, 0.0, 0.013, 0.012, "gun_black")
    scope(m, -0.1, 0.1, 0.07, 0.018, {rings = {-0.06, 0.06}, base = 0.03, mat = "poly_od"})
    K.box(m, -0.035, -0.08, -0.46, 0.035, 0.035, -0.445, "rubber", {soft = 0.5})
  end}

local function bolt(m, z, y)
  K.box(m, 0.024, y - 0.004, z - 0.008, 0.06, y + 0.004, z + 0.002, "gun_steel")
  K.ball(m, {0.064, y - 0.006, z - 0.003}, 0.009, 0.009, 0.009, 8, "gun_black")
end

G.awp = {kind = "sniper", pos = {0.095, -0.098, 0.2}, grip = {0, -0.085, -0.1}, fore = {0, -0.035, 0.18},
  muzzle = {0, 0.025, 0.8},
  build = function(m)
    K.prism(m, P("-0.56,-0.09 -0.5,-0.11 -0.36,-0.1 -0.3,-0.06 -0.2,-0.05 0.3,-0.035 0.3,0.04 -0.16,0.04 -0.2,0.055 -0.56,0.055"),
      -0.032, 0.032, "gun_green", {round = 0.6, smooth = 55})
    K.box(m, -0.033, -0.1, -0.57, 0.033, 0.058, -0.555, "rubber", {soft = 0.4})
    K.prism(m, P("-0.08,0.04 -0.04,0.04 -0.1,-0.11 -0.135,-0.11"), -0.017, 0.017, "gun_green", {round = 0.6})
    K.box(m, -0.005, -0.045, -0.04, 0.005, -0.032, 0.02, "gun_black")
    K.box(m, -0.016, -0.11, -0.02, 0.016, -0.035, 0.04, "mag_steel")
    K.box(m, -0.022, 0.03, -0.18, 0.022, 0.058, 0.12, "gun_metal", {soft = 0.3})
    scope(m, -0.2, 0.18, 0.095, 0.024, {rings = {-0.14, 0.08}, base = 0.058})
    cylZ(m, 0.3, 0.78, 0.025, 0.012, 0.0095, "gun_metal", 12)
    cylZ(m, 0.74, 0.8, 0.025, 0.016, 0.016, "gun_black", 12)
    bolt(m, -0.12, 0.04)
  end}

G.ssg08 = {kind = "sniper", pos = {0.095, -0.098, 0.2}, grip = {0, -0.08, -0.08}, fore = {0, -0.03, 0.18},
  muzzle = {0, 0.025, 0.72},
  build = function(m)
    K.prism(m, P("-0.5,-0.085 -0.36,-0.085 -0.3,-0.05 -0.2,-0.045 0.28,-0.03 0.28,0.035 -0.15,0.035 -0.2,0.05 -0.5,0.05"),
      -0.028, 0.028, "poly_grey", {round = 0.6, smooth = 55})
    K.box(m, -0.029, -0.09, -0.51, 0.029, 0.053, -0.497, "rubber", {soft = 0.4})
    K.prism(m, P("-0.06,0.035 -0.025,0.035 -0.09,-0.1 -0.12,-0.1"), -0.016, 0.016, "poly_grey", {round = 0.6})
    K.box(m, -0.005, -0.04, -0.03, 0.005, -0.03, 0.025, "gun_black")
    K.box(m, -0.014, -0.08, -0.01, 0.014, -0.03, 0.035, "mag_steel")
    K.box(m, -0.02, 0.025, -0.16, 0.02, 0.05, 0.11, "gun_black")
    scope(m, -0.17, 0.16, 0.085, 0.02, {rings = {-0.12, 0.08}, base = 0.05})
    cylZ(m, 0.28, 0.69, 0.025, 0.011, 0.009, "gun_black", 12)
    cylZ(m, 0.66, 0.72, 0.025, 0.014, 0.014, "gun_metal")
    bolt(m, -0.1, 0.035)
  end}

local function autoSniper(m, o)
  K.prism(m, P("-0.17,0.0 0.14,0.0 0.14,0.055 -0.17,0.055"), -0.025, 0.025, o.recv, {round = 0.3})
  K.prism(m, P("0.14,-0.005 0.36,-0.005 0.36,0.055 0.14,0.055"), -0.028, 0.028, o.hand, {round = 0.6, smooth = 60})
  cylZ(m, 0.36, 0.72, 0.03, 0.01, 0.01, "gun_black", 12)
  cylZ(m, 0.66, 0.74, 0.03, 0.015, 0.015, "gun_metal")
  K.prism(m, P(o.stock), -0.024, 0.024, o.stockMat or o.recv, {round = 0.6, smooth = 55})
  K.box(m, -0.016, -0.14, 0.0, 0.016, 0.0, 0.06, "mag_steel", {tilt = 4})
  lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.035, z1 = -0.07, back = 0.035, bot = -0.12, guardZ = 0.0})
  rail(m, -0.15, 0.13, 0.055, 0.012)
  scope(m, -0.16, 0.16, 0.1, 0.022, {rings = {-0.1, 0.08}, base = 0.063})
end

G.g3sg1 = {kind = "sniper", pos = {0.095, -0.098, 0.2}, grip = {0, -0.08, -0.07}, fore = {0, -0.02, 0.24},
  muzzle = {0, 0.03, 0.74},
  build = function(m)
    autoSniper(m, {recv = "gun_black", hand = "gun_metal", stockMat = "gun_black",
      stock = "-0.17,0.05 -0.17,-0.01 -0.5,-0.07 -0.51,-0.07 -0.51,0.05"})
  end}

G.scar20 = {kind = "sniper", pos = {0.095, -0.098, 0.2}, grip = {0, -0.08, -0.07}, fore = {0, -0.02, 0.24},
  muzzle = {0, 0.03, 0.74},
  build = function(m)
    autoSniper(m, {recv = "poly_fde", hand = "poly_fde", stockMat = "gun_black",
      stock = "-0.17,0.055 -0.17,-0.015 -0.46,-0.06 -0.48,-0.06 -0.48,0.055"})
  end}

-- --- Дробовики и пулемёты ---

G.nova = {kind = "shotgun", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.08}, fore = {0, -0.04, 0.26},
  muzzle = {0, 0.02, 0.66},
  build = function(m)
    K.prism(m, P("-0.12,-0.005 0.12,-0.005 0.12,0.05 -0.1,0.05 -0.12,0.04"), -0.025, 0.025, "gun_black", {round = 0.4})
    K.prism(m, P("-0.12,0.045 -0.12,-0.01 -0.48,-0.08 -0.49,-0.08 -0.49,0.035 -0.45,0.04"), -0.022, 0.022, "gun_black",
      {round = 0.6})
    K.box(m, -0.023, -0.085, -0.5, 0.023, 0.04, -0.49, "rubber", {soft = 0.4})
    cylZ(m, 0.12, 0.66, 0.028, 0.012, 0.012, "gun_metal", 12)
    cylZ(m, 0.12, 0.56, 0.0, 0.011, 0.011, "gun_black", 10)
    K.prism(m, P("0.18,-0.02 0.34,-0.02 0.34,0.018 0.18,0.018"), -0.026, 0.026, "gun_black", {round = 0.7, smooth = 70})
    for k = 0, 5 do K.box(m, -0.0265, -0.016, 0.19 + k * 0.024, 0.0265, 0.014, 0.2 + k * 0.024, "rubber") end
    K.ball(m, {0, 0.045, 0.64}, 0.004, 0.004, 0.004, 6, "orange")
    lower(m, {grip = "gun_black", gw = 0.016, z0 = -0.04, z1 = -0.075, back = 0.04, bot = -0.11, guardZ = 0.0})
  end}

G.xm1014 = {kind = "shotgun", pos = {0.092, -0.096, 0.2}, grip = {0, -0.075, -0.08}, fore = {0, -0.03, 0.25},
  muzzle = {0, 0.026, 0.62},
  build = function(m)
    K.prism(m, P("-0.14,-0.005 0.14,-0.005 0.14,0.052 -0.14,0.052"), -0.024, 0.024, "gun_black", {round = 0.3})
    rail(m, -0.12, 0.12, 0.052, 0.011)
    cylZ(m, -0.35, -0.14, 0.03, 0.013, 0.013, "gun_black")
    K.prism(m, P("-0.36,0.05 -0.26,0.045 -0.26,0.0 -0.36,-0.05 -0.38,-0.05 -0.38,0.05"), -0.022, 0.022, "gun_black", {round = 0.5})
    cylZ(m, 0.14, 0.62, 0.026, 0.012, 0.012, "gun_metal", 12)
    cylZ(m, 0.14, 0.52, -0.002, 0.012, 0.012, "gun_black", 10)
    K.prism(m, P("0.14,-0.02 0.34,-0.02 0.34,0.016 0.14,0.016"), -0.027, 0.027, "gun_black", {round = 0.6, smooth = 60})
    K.box(m, 0.024, 0.025, 0.02, 0.042, 0.04, 0.045, "gun_steel")
    lower(m, {grip = "gun_black", gw = 0.016, z0 = -0.04, z1 = -0.075, back = 0.04, bot = -0.11, guardZ = 0.0})
  end}

G.sawedoff = {kind = "shotgun", pos = {0.09, -0.094, 0.24}, grip = {0, -0.07, -0.07}, fore = {0, -0.03, 0.2},
  muzzle = {0, 0.024, 0.42},
  build = function(m)
    K.prism(m, P("-0.12,-0.005 0.1,-0.005 0.1,0.048 -0.12,0.048"), -0.024, 0.024, "gun_steel", {round = 0.3})
    cylZ(m, 0.1, 0.42, 0.026, 0.0125, 0.0125, "gun_steel", 12)
    cylZ(m, 0.1, 0.32, 0.0, 0.012, 0.012, "gun_metal", 10)
    K.prism(m, P("0.14,-0.02 0.28,-0.02 0.28,0.016 0.14,0.016"), -0.026, 0.026, "wood_dark", {round = 0.6, smooth = 60})
    K.prism(m, P("-0.12,0.04 -0.12,-0.01 -0.2,-0.1 -0.24,-0.1 -0.22,-0.04 -0.16,0.04"), -0.02, 0.02, "wood_dark", {round = 0.6})
    K.box(m, -0.005, -0.04, -0.04, 0.005, -0.03, 0.02, "gun_steel")
  end}

G.mag7 = {kind = "shotgun", pos = {0.088, -0.092, 0.22}, grip = {0, -0.075, -0.07}, fore = {0, -0.11, 0.16},
  muzzle = {0, 0.022, 0.42},
  build = function(m)
    K.prism(m, P("-0.2,-0.01 0.18,-0.01 0.18,0.05 -0.19,0.05 -0.2,0.04"), -0.028, 0.028, "gun_black", {round = 0.4})
    cylZ(m, 0.18, 0.42, 0.022, 0.013, 0.013, "gun_metal", 12)
    K.box(m, -0.018, -0.16, -0.05, 0.018, -0.01, -0.005, "gun_black") -- рукоять-магазин
    K.box(m, -0.014, -0.13, 0.13, 0.014, -0.01, 0.18, "gun_black", {tilt = 8, soft = 0.4})
    K.box(m, -0.006, -0.02, -0.4, 0.006, 0.0, -0.2, "gun_steel")
    K.box(m, -0.02, -0.06, -0.41, 0.02, 0.01, -0.395, "rubber", {soft = 0.4})
    rail(m, -0.12, 0.15, 0.05, 0.011)
  end}

G.m249 = {kind = "lmg", pos = {0.095, -0.1, 0.18}, grip = {0, -0.075, -0.08}, fore = {0, -0.02, 0.25},
  muzzle = {0, 0.035, 0.7},
  build = function(m)
    K.prism(m, P("-0.17,-0.01 0.2,-0.01 0.2,0.06 -0.17,0.06"), -0.03, 0.03, "gun_black", {round = 0.3})
    K.box(m, -0.028, 0.06, -0.12, 0.028, 0.075, 0.16, "gun_metal", {soft = 0.3}) -- крышка ленты
    K.prism(m, P("-0.17,0.055 -0.17,-0.01 -0.48,-0.07 -0.5,-0.07 -0.5,0.05"), -0.024, 0.024, "gun_black", {round = 0.6})
    K.box(m, -0.022, -0.17, -0.06, 0.06, -0.01, 0.1, "tarp_green", {soft = 0.5}) -- короб с лентой
    cylZ(m, 0.2, 0.66, 0.035, 0.013, 0.013, "gun_metal", 12)
    cylZ(m, 0.2, 0.44, 0.012, 0.009, 0.009, "gun_black", 8)
    cylZ(m, 0.62, 0.7, 0.035, 0.016, 0.016, "gun_black")
    K.prism(m, P("0.2,-0.015 0.38,-0.015 0.38,0.03 0.2,0.03"), -0.031, 0.031, "gun_black", {round = 0.6})
    K.box(m, -0.012, 0.035, 0.6, -0.006, 0.06, 0.64, "gun_black")
    lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.04, z1 = -0.08, back = 0.035, bot = -0.12, guardZ = 0.0})
    K.box(m, 0.03, 0.02, 0.02, 0.05, 0.034, 0.05, "gun_steel")
  end}

G.negev = {kind = "lmg", pos = {0.095, -0.1, 0.18}, grip = {0, -0.075, -0.08}, fore = {0, -0.02, 0.26},
  muzzle = {0, 0.035, 0.7},
  build = function(m)
    K.prism(m, P("-0.18,-0.01 0.22,-0.01 0.22,0.062 -0.18,0.062"), -0.03, 0.03, "gun_metal", {round = 0.3})
    K.prism(m, P("-0.18,0.055 -0.18,-0.01 -0.46,-0.06 -0.48,-0.06 -0.48,0.05"), -0.022, 0.022, "gun_black", {round = 0.6})
    K.box(m, -0.026, -0.16, -0.08, 0.06, -0.01, 0.08, "gun_black", {soft = 0.3})
    cylZ(m, 0.22, 0.65, 0.035, 0.0135, 0.0135, "gun_black", 12)
    for k = 0, 8 do cylZ(m, 0.24 + k * 0.035, 0.25 + k * 0.035, 0.035, 0.017, 0.017, "gun_metal", 12) end
    cylZ(m, 0.65, 0.7, 0.035, 0.015, 0.015, "gun_metal")
    rail(m, -0.15, 0.2, 0.062, 0.012)
    lower(m, {grip = "gun_black", gw = 0.017, z0 = -0.04, z1 = -0.08, back = 0.035, bot = -0.12, guardZ = 0.0})
    K.box(m, -0.012, -0.12, 0.3, 0.012, -0.01, 0.33, "gun_black", {tilt = 6, soft = 0.4})
  end}

-- --- Нож, Zeus, гранаты, бомба ---

G.knife = {kind = "knife", pos = {0.08, -0.085, 0.3}, grip = {0, 0.0, -0.05},
  build = function(m)
    K.prism(m, P("-0.11,-0.018 0.0,-0.02 0.0,0.018 -0.11,0.014 -0.118,0.0"), -0.012, 0.012, "rubber", {round = 0.8, smooth = 70})
    for k = 0, 4 do K.box(m, -0.0125, -0.019, -0.1 + k * 0.02, 0.0125, 0.016, -0.094 + k * 0.02, "black_matte") end
    K.box(m, -0.016, -0.026, 0.0, 0.016, 0.026, 0.008, "gun_metal", {soft = 0.4})
    -- клинок: обух прямой, спуск к острию
    K.prism(m, P("0.008,-0.016 0.13,-0.016 0.19,0.01 0.17,0.02 0.008,0.02"), -0.0028, 0.0028, "knife_blade", {round = 0.1})
    K.prism(m, P("0.03,-0.006 0.15,-0.006 0.17,0.004 0.03,0.004"), -0.0034, 0.0034, "gun_steel")
  end}

G.zeus = {kind = "pistol", pos = {0.072, -0.074, 0.3}, grip = {0, -0.07, -0.05}, fore = {-0.012, -0.08, -0.04},
  muzzle = {0, 0.02, 0.13},
  build = function(m)
    K.prism(m, P("-0.07,0.0 0.12,0.0 0.13,0.012 0.13,0.035 -0.06,0.04 -0.07,0.03"), -0.018, 0.018, "black_matte", {round = 0.4})
    K.box(m, -0.019, 0.015, -0.05, 0.019, 0.03, 0.1, "zeus_yellow")
    K.box(m, -0.012, 0.012, 0.13, 0.012, 0.034, 0.136, "orange")
    lower(m, {grip = "black_matte", gw = 0.018, back = 0.02, bot = -0.105, guardZ = 0.03})
  end}

local function nadeBase(m, body, o)
  o = o or {}
  K.box(m, -0.009, o.top, -0.009, 0.009, o.top + 0.018, 0.009, "gun_metal", {soft = 0.5}) -- запал
  K.box(m, 0.008, o.top - 0.05, -0.006, 0.014, o.top + 0.012, 0.006, "gun_steel") -- рычаг
  K.cyl(m, {0.012, o.top + 0.012, -0.012}, {0.012, o.top + 0.012, 0.012}, 0.011, 0.011, 10, "brass", {caps = false})
end

G.he = {kind = "nade", pos = {0.08, -0.085, 0.3}, grip = {0.01, -0.03, -0.01},
  build = function(m)
    K.ball(m, {0, 0, 0}, 0.032, 0.038, 0.032, 12, "nade_he")
    for k = -1, 1 do K.cyl(m, {0, k * 0.016 - 0.002, 0}, {0, k * 0.016 + 0.002, 0}, 0.0335, 0.0335, 12, "gun_black", {caps = false}) end
    nadeBase(m, nil, {top = 0.036})
  end}
G.flash = {kind = "nade", pos = {0.08, -0.085, 0.3}, grip = {0.01, -0.03, -0.01},
  build = function(m)
    K.cyl(m, {0, -0.05, 0}, {0, 0.035, 0}, 0.024, 0.024, 12, "nade_flash")
    for k = 0, 3 do K.cyl(m, {0, -0.035 + k * 0.018, 0}, {0, -0.03 + k * 0.018, 0}, 0.0245, 0.0245, 12, "gun_black", {caps = false}) end
    nadeBase(m, nil, {top = 0.035})
  end}
G.smoke = {kind = "nade", pos = {0.08, -0.085, 0.3}, grip = {0.01, -0.03, -0.01},
  build = function(m)
    K.cyl(m, {0, -0.055, 0}, {0, 0.035, 0}, 0.027, 0.027, 12, "nade_smoke")
    K.cyl(m, {0, 0.0, 0}, {0, 0.012, 0}, 0.0275, 0.0275, 12, "gun_black", {caps = false})
    nadeBase(m, nil, {top = 0.035})
  end}
G.decoy = {kind = "nade", pos = {0.08, -0.085, 0.3}, grip = {0.01, -0.03, -0.01},
  build = function(m)
    K.cyl(m, {0, -0.05, 0}, {0, 0.035, 0}, 0.023, 0.023, 12, "nade_decoy")
    K.cyl(m, {0, -0.02, 0}, {0, -0.005, 0}, 0.0235, 0.0235, 12, "orange", {caps = false})
    nadeBase(m, nil, {top = 0.035})
  end}
G.incgrenade = {kind = "nade", pos = {0.08, -0.085, 0.3}, grip = {0.01, -0.03, -0.01},
  build = function(m)
    K.cyl(m, {0, -0.055, 0}, {0, 0.035, 0}, 0.026, 0.026, 12, "gun_metal")
    K.cyl(m, {0, 0.005, 0}, {0, 0.035, 0}, 0.0265, 0.0265, 12, "inc_red", {caps = false})
    nadeBase(m, nil, {top = 0.035})
  end}
G.molotov = {kind = "nade", pos = {0.08, -0.08, 0.3}, grip = {0.0, -0.04, -0.01},
  build = function(m)
    K.cyl(m, {0, -0.08, 0}, {0, 0.02, 0}, 0.03, 0.03, 12, "bottle_glass")
    K.cyl(m, {0, 0.02, 0}, {0, 0.05, 0}, 0.03, 0.012, 12, "bottle_glass")
    K.cyl(m, {0, 0.05, 0}, {0, 0.085, 0}, 0.012, 0.012, 10, "bottle_glass")
    K.cyl(m, {0, 0.075, 0}, {0.01, 0.13, 0.004}, 0.012, 0.008, 8, "rag")
  end}

G.c4 = {kind = "c4", pos = {0.03, -0.11, 0.32}, grip = {0.05, -0.04, -0.03}, fore = {-0.06, -0.04, -0.02},
  build = function(m)
    for k = 0, 2 do
      K.box(m, -0.075 + k * 0.05, -0.03, -0.05, -0.028 + k * 0.05, 0.015, 0.05, "c4_body", {soft = 0.5})
    end
    K.box(m, -0.045, 0.015, -0.03, 0.045, 0.028, 0.03, "black_matte", {soft = 0.3})
    K.box(m, -0.038, 0.0281, -0.022, 0.038, 0.029, 0.005, "c4_screen")
    for r = 0, 2 do
      for c = 0, 3 do
        K.box(m, -0.03 + c * 0.016, 0.028, 0.01 + r * 0.0, -0.02 + c * 0.016, 0.031, 0.018, "gun_steel")
      end
    end
    K.box(m, -0.078, -0.012, -0.052, 0.078, -0.004, 0.052, "wire_red")
    K.cyl(m, {0.04, 0.02, 0.03}, {0.07, -0.01, 0.05}, 0.003, 0.003, 6, "wire_red")
  end}

return G
