-- «Квартал» — первая цельная карта: старый южный город. Всё, что не улица, двор или комната, — сплошная застройка
-- (дома разной высоты с фасадами), за стенами нет пустот и недоступных мест.
-- Схема (север — сверху; X — на восток, Z — на юг; 1 блок ≈ 1,8 м):
--   база спецназа (CT) — север по центру; от неё: на запад — улица к B, на восток — пандус к A, на юг — мид;
--   мид — широкая улица с машиной и ящиками; из «окна» (комната CT у мида) простреливается верх мида;
--   A — двор с платформой, стопкой ящиков, фургоном; туда ведут «лонг» (улица с воротами) и «шорт» (арка из мида);
--   B — рыночная площадь с прилавками, грузовиком и фонтаном; туда ведут «туннели» (дом с комнатами) и проулок из мида;
--   база террористов (T) — юг по центру: на север — мид, на восток — к лонгу, на запад — к туннелям.
local L = require("levelgen").new({
  key = "quarter", name = "Квартал", size = {60, 56}, cs = 0.5, wallH = 3.2,
  sky = "#FF9CC7E8", fog = "#FFE2D9C8", fogNear = 30, fogFar = 90,
  light = {-0.55, -1, -0.35, 0.5},
  theme = "desert", ground = "city/des_road", facade = "city/des_plaster",
  facades = {"city/des_plaster", "city/des_plaster2", "city/des_blocks", "city/des_adobe", "city/oas_blocks", "city/ita_ochre"},
  steps = {floor = "sand", floor2 = "stone", box = "wood"},
  tex = {site = "d2_site"},
})

-- --- Проходимые места ---

-- база спецназа и выходы
L:floor(23, 1.5, 37, 9, {mat = "city/des_paving"})
L:floor(11, 1.5, 23, 5, {mat = "city/des_road"})                 -- улица к B
L:floor(37, 2.5, 43, 9, {mat = "city/des_paving"})                -- проход к A
-- мид
L:floor(26, 9, 34, 38.5, {mat = "city/des_road"})
L:floor(27, 39.5, 33, 45, {mat = "city/des_road"})                -- от базы T к миду
-- база террористов и выходы
L:floor(21, 45, 39, 53, {mat = "city/des_paving"})
L:floor(39, 46, 47, 50, {mat = "city/des_road"})                  -- к лонгу
L:floor(15, 45, 21, 51, {mat = "city/des_road"})                  -- к туннелям
-- точка A, платформа, лонг (с воротами), шорт (арка из мида)
L:floor(43, 2.5, 56, 25, {mat = "city/des_paving"})
L:floor(48, 2.5, 56, 9, {y = 0.5, mat = "city/oas_paving"})
L:stairs(48, 9, 56, 10.5, {from = 0.5, to = 0, dir = "+z", mat = "city/oas_paving"})
L:floor(47, 25, 55, 33, {mat = "city/des_road"})
L:floor(47, 34, 55, 50, {mat = "city/des_road"})
L:door(50, 33, 52.5, 34, {top = 1.6, leaf = "gate"})              -- ворота лонга
L:room(34, 20.5, 43, 25.5, {ceil = 1.5, h = 4.2, walls = {n = true, s = true}, infloor = "city/des_infloor",
  inwall = "city/des_inwall", facade = "city/des_blocks"})          -- арка шорта
-- точка B, проулок из мида, выход туннелей
L:floor(4, 5, 19, 24, {mat = "city/des_paving"})
L:floor(4, 5, 8.5, 9.5, {y = 0.5, mat = "city/oas_paving"})        -- платформа у стены
L:stairs(8.5, 5, 10, 9.5, {from = 0.5, to = 0, dir = "+x", mat = "city/oas_paving"})
L:floor(19, 27, 26, 31, {mat = "city/des_road"})                  -- проулок из мида
L:floor(14, 24, 19, 31, {mat = "city/des_road"})
L:floor(5, 24, 13, 32, {mat = "city/des_paving"})                 -- двор у выхода туннелей

-- ворота мида: стена поперёк, проход посередине — с базы T не простреливается весь мид до базы CT
L:door(29, 38.5, 31, 39.5, {top = 1.7, leaf = "gate"})

-- --- Комнаты ---

-- «окно» спецназа: комната у верха мида, вход с базы, окно на мид
L:room(19.5, 8.5, 26, 16, {ceil = 1.65, h = 4.6, infloor = "city/des_infloor", inwall = "city/des_inwall",
  facade = "city/des_plaster2"})
L:door(23, 8.5, 24.5, 9, {top = 1.35, leaf = "wood"})
L:window(25.5, 11, 26, 13.5, {sill = 0.5, top = 1.15})
L:window(19.5, 12, 20, 13.5, {sill = 0.55, top = 1.1})
-- туннели: большой дом с перегородкой, вход от базы T, выход во двор у B
L:room(5, 32, 15, 47, {ceil = 1.6, h = 4.4, infloor = "city/des_infloor", inwall = "city/des_inwall", facade = "city/des_adobe"})
L:wall(9.5, 32.5, 10, 41, {h = 99, kind = "plaster"})              -- перегородка
L:door(14.5, 44, 15, 46, {top = 1.35, leaf = "wood"})
L:door(7, 32, 9, 32.5, {top = 1.4})
L:door(11, 32, 12.5, 32.5, {top = 1.35, leaf = "wood"})
L:window(5, 36, 5.5, 37.5, {sill = 0.55, top = 1.1})

-- --- Базы, точки, маршруты ботов ---

L:spawn("CT", 25, 2.5, 35, 8)
L:spawn("T", 23, 47, 37, 52)
L:site("A", 44, 5, 55, 18)
L:site("B", 5, 7, 17, 21)
L:lane("A", 51, 41)   -- лонг
L:lane("A", 30, 23)   -- мид → шорт
L:lane("B", 10, 42)   -- туннели
L:lane("B", 29, 28)   -- мид → проулок

-- --- Наполнение ---

-- база CT: колонны-кадки, скамейки, фонари
L:prop("planter", 24.5, 3, {})
L:prop("planter", 35.5, 3, {})
L:prop("bench", 30, 2.25, {})
L:prop("lamp", 26.25, 8.25, {})
L:prop("lamp", 33.75, 8.25, {})
L:prop("crate", 36.5, 7.5, {})
L:prop("barrels", 41.5, 3.5, {})
-- улица к B
L:prop("car", 15.5, 2.75, {rot = 90, color = "white"})
L:prop("crate", 12, 4.25, {})
-- мид: ящики, машина, мешки
L:prop("crate_big", 31.5, 21.5, {})
L:prop("crate", 32.5, 21.5, {})
L:prop("crate", 31.5, 21.5, {y = 1.1})
L:prop("car", 28.5, 30.5, {color = "red"})
L:prop("sandbags", 27.5, 36.75, {})
L:prop("barrel", 33.25, 34.75, {})
L:prop("barrel", 33.25, 35.25, {})
L:prop("pole", 26.25, 25.75, {})
L:prop("pole", 33.75, 16.25, {})
L:prop("dumpster", 33, 12.5, {rot = 90})
-- от базы T к миду
L:prop("crate", 27.5, 42.5, {})
L:prop("pallets", 32.5, 40.5, {})
-- база T: грузовик, ящики, бочки
L:prop("truck", 25.5, 51.75, {rot = 90, color = "green"})
L:prop("crate_big", 36.5, 46.5, {})
L:prop("crate", 37.5, 46.5, {})
L:prop("barrels", 22, 46, {})
L:prop("cart", 34, 51.5, {rot = 90})
-- к лонгу и сам лонг
L:prop("crate", 43.5, 49, {})
L:prop("car", 49.5, 41, {color = "blue"})
L:prop("dumpster", 54, 28, {rot = 90})
L:prop("barrels", 47.5, 35, {})
L:prop("crate_big", 54.5, 25.5, {})
L:prop("crate", 54.5, 26.5, {})
L:prop("pole", 47.25, 45.75, {})
-- A: стопка ящиков в центре, фургон, бочки, кадки, ограда платформы
L:prop("crate_big", 49.5, 14.5, {})
L:prop("crate_big", 50.5, 14.5, {})
L:prop("crate", 49.5, 15.5, {})
L:prop("crate", 50.5, 14.5, {y = 1.1})
L:prop("van", 45, 7.5, {color = "white"})
L:prop("barrels", 54.5, 19.5, {})
L:prop("planter", 44, 19.5, {})
L:prop("planter", 44, 15.5, {})
L:wall(48, 9, 51, 9.5, {h = 0.55, kind = "stone"})                  -- бортик платформы
L:wall(54, 9, 56, 9.5, {h = 0.55, kind = "stone"})
L:prop("crate", 54.5, 4, {y = 0.5})
L:prop("tree", 46.25, 22.75, {})
-- шорт: ящики у выхода на A
L:prop("crate", 42, 21.5, {})
L:prop("pallets", 36, 24.5, {})
-- B: прилавки, грузовик, фонтан, ящики, мешки
L:prop("stall", 9, 13, {rot = 90, color = "red"})
L:prop("stall", 9, 17.5, {rot = 90, color = "green"})
L:prop("stall", 13, 11, {color = "red"})
L:prop("truck", 16.75, 10.5, {color = "white"})
L:prop("fountain", 12.5, 18.5, {})
L:prop("crate_big", 5.5, 22.5, {})
L:prop("crate", 6.5, 22.5, {})
L:prop("crate", 5.5, 21.5, {})
L:prop("sandbags", 15, 23.25, {})
L:prop("barrels", 6, 6.5, {y = 0.5})
L:prop("cart", 18, 20, {})
-- проулок и двор у туннелей
L:prop("crate", 24.5, 27.5, {})
L:prop("barrel", 19.25, 30.25, {})
L:prop("pallets", 15, 29.5, {})
L:prop("crate_big", 12, 30.5, {})
L:prop("barrels", 6, 26, {})
-- туннели внутри: ящики и мешки
L:prop("crate", 12, 38, {})
L:prop("crate", 6.5, 44.5, {})
L:prop("sandbags", 7.5, 34.75, {})
L:prop("barrel", 13.75, 33.25, {})
L:prop("crate_big", 13.5, 41.5, {})
L:prop("crate", 13.5, 42.5, {})
L:prop("pallets", 6.5, 39, {})
L:prop("barrels", 8.5, 46, {})
L:prop("crate_long", 11.5, 35.5, {rot = 90})
-- у входа в туннели
L:prop("crate", 16, 46, {})
L:prop("barrels", 20, 50, {})

return L:done()
