-- Случайные события фона по видам фона (sounds/ae_<фон>_<имя>.wav). Создаёт tools/gen_strike_sounds.py.
return {
  desert = {"ae_desert_gust", "ae_desert_dog", "ae_desert_hawk", "ae_desert_moto", "ae_desert_car"},
  city = {"ae_city_car", "ae_city_horn", "ae_city_siren", "ae_city_pigeons", "ae_city_bell", "ae_city_dog"},
  industrial = {"ae_industrial_ship", "ae_industrial_clank", "ae_industrial_gulls", "ae_industrial_steam", "ae_industrial_beeps", "ae_industrial_truck"},
  nature = {"ae_nature_birds", "ae_nature_woodpecker", "ae_nature_crow", "ae_nature_cicada", "ae_nature_branch", "ae_nature_dog"},
  snow = {"ae_snow_howl", "ae_snow_creak", "ae_snow_crow", "ae_snow_rumble", "ae_snow_gust"},
  indoor = {"ae_indoor_drip", "ae_indoor_pipe", "ae_indoor_vent", "ae_indoor_door", "ae_indoor_buzz"},
}
