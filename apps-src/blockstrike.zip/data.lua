-- Данные игры: команды, оружие (весь арсенал CS2), снаряжение, экономика, имена ботов.
local D = {}

D.T, D.CT = 1, 2
D.TEAM_NAME = {"Террористы", "Спецназ"}
D.TEAM_SHORT = {"Т", "КТ"}
D.TEAM_COLOR = {"#FFE8B04A", "#FF6FA8FF"}
D.TEAM_DARK = {"#C05A3A10", "#C0102A5A"}

-- Слоты: 1 — основное, 2 — пистолет, 3 — нож (и Zeus), 4 — гранаты, 5 — бомба.
-- dmg — урон в тело без брони; pen — сколько урона проходит через броню; cool — пауза между выстрелами (с);
-- spread — разброс стоя (радианы), move — добавка на бегу; recoil — отдача (градусы вверх за выстрел);
-- range — множитель урона за каждые 10 блоков; speed — скорость бега с этим оружием (нож — 1); reward — награда за
-- убийство; team — только для этой команды (нет — для обеих); scope — поле зрения при прицеливании (ПКМ), scoped —
-- разброс в прицеле; silenced — с глушителем (звук тише, без вспышки); kind — вид для звуков перезарядки и модели в руках.
-- Числа — по CS2 (урон, бронебойность, темп, магазины, цены), скорость — доля от 250.
D.WEAPONS = {
  {id = 1, key = "knife", name = "Нож", slot = 3, dmg = 40, cool = 0.5, reach = 1.6, speed = 1.0, reward = 1500, kind = "knife"},
  {id = 2, key = "glock", name = "Glock-18", slot = 2, team = 1, price = 200, clip = 20, reserve = 120, dmg = 30, pen = 0.47,
    cool = 0.15, spread = 0.010, move = 0.035, recoil = 1.2, reload = 2.2, range = 0.85, speed = 0.96, reward = 300, kind = "pistol"},
  {id = 3, key = "usp", name = "USP-S", slot = 2, team = 2, price = 200, clip = 12, reserve = 24, dmg = 35, pen = 0.505,
    cool = 0.17, spread = 0.006, move = 0.03, recoil = 1.5, reload = 2.2, range = 0.88, speed = 0.96, reward = 300,
    silenced = true, kind = "pistol"},
  {id = 4, key = "p250", name = "P250", slot = 2, price = 300, clip = 13, reserve = 26, dmg = 38, pen = 0.64,
    cool = 0.15, spread = 0.009, move = 0.035, recoil = 1.8, reload = 2.2, range = 0.85, speed = 0.96, reward = 300, kind = "pistol"},
  {id = 5, key = "deagle", name = "Desert Eagle", slot = 2, price = 700, clip = 7, reserve = 35, dmg = 63, pen = 0.93,
    cool = 0.25, spread = 0.008, move = 0.07, recoil = 4.5, reload = 2.2, range = 0.9, speed = 0.92, reward = 300, kind = "pistol"},
  {id = 6, key = "nova", name = "Nova", slot = 1, price = 1050, clip = 8, reserve = 32, dmg = 26, pen = 0.5, pellets = 9,
    cool = 0.88, spread = 0.055, move = 0.02, recoil = 3.0, reload = 3.4, range = 0.6, speed = 0.88, reward = 900, kind = "shotgun"},
  {id = 7, key = "mp9", name = "MP9", slot = 1, team = 2, price = 1250, clip = 30, reserve = 120, dmg = 26, pen = 0.6, auto = true,
    cool = 0.07, spread = 0.012, move = 0.02, recoil = 0.7, reload = 2.1, range = 0.8, speed = 0.96, reward = 600, kind = "smg"},
  {id = 8, key = "p90", name = "P90", slot = 1, price = 2350, clip = 50, reserve = 100, dmg = 26, pen = 0.69, auto = true,
    cool = 0.07, spread = 0.014, move = 0.02, recoil = 0.6, reload = 3.3, range = 0.86, speed = 0.92, reward = 300, kind = "smg"},
  {id = 9, key = "galil", name = "Galil AR", slot = 1, team = 1, price = 1800, clip = 35, reserve = 90, dmg = 30, pen = 0.775,
    auto = true, cool = 0.09, spread = 0.006, move = 0.07, recoil = 0.85, reload = 2.9, range = 0.95, speed = 0.86, reward = 300, kind = "rifle"},
  {id = 10, key = "famas", name = "FAMAS", slot = 1, team = 2, price = 2050, clip = 25, reserve = 90, dmg = 30, pen = 0.7,
    auto = true, cool = 0.09, spread = 0.006, move = 0.07, recoil = 0.8, reload = 3.3, range = 0.95, speed = 0.88, reward = 300, kind = "rifle"},
  {id = 11, key = "ak47", name = "AK-47", slot = 1, team = 1, price = 2700, clip = 30, reserve = 90, dmg = 36, pen = 0.775,
    auto = true, cool = 0.1, spread = 0.004, move = 0.09, recoil = 1.0, reload = 2.5, range = 0.98, speed = 0.86, reward = 300, kind = "rifle"},
  {id = 12, key = "m4a4", name = "M4A4", slot = 1, team = 2, price = 3100, clip = 30, reserve = 90, dmg = 33, pen = 0.7,
    auto = true, cool = 0.09, spread = 0.004, move = 0.085, recoil = 0.85, reload = 3.1, range = 0.97, speed = 0.9, reward = 300, kind = "rifle"},
  {id = 13, key = "awp", name = "AWP", slot = 1, price = 4750, clip = 5, reserve = 30, dmg = 115, pen = 0.975,
    cool = 1.45, spread = 0.07, scoped = 0.0015, move = 0.2, recoil = 5.0, reload = 3.6, range = 0.99, speed = 0.8, reward = 100,
    scope = {38, 14}, kind = "sniper"},
  {id = 14, key = "he", name = "Осколочная граната", slot = 4, price = 300, max = 1, speed = 0.98, reward = 300, kind = "nade"},
  {id = 15, key = "flash", name = "Световая граната", slot = 4, price = 200, max = 2, speed = 0.98, reward = 300, kind = "nade"},
  {id = 16, key = "smoke", name = "Дымовая граната", slot = 4, price = 300, max = 1, speed = 0.98, reward = 300, kind = "nade"},
  {id = 17, key = "c4", name = "Бомба C4", slot = 5, speed = 0.97, kind = "c4"},
  -- Пистолеты
  {id = 18, key = "p2000", name = "P2000", slot = 2, team = 2, price = 200, clip = 13, reserve = 52, dmg = 35, pen = 0.505,
    cool = 0.17, spread = 0.007, move = 0.03, recoil = 1.5, reload = 2.2, range = 0.88, speed = 0.96, reward = 300, kind = "pistol"},
  {id = 19, key = "fiveseven", name = "Five-SeveN", slot = 2, team = 2, price = 500, clip = 20, reserve = 100, dmg = 32, pen = 0.911,
    cool = 0.15, spread = 0.008, move = 0.03, recoil = 1.4, reload = 2.2, range = 0.86, speed = 0.96, reward = 300, kind = "pistol"},
  {id = 20, key = "tec9", name = "Tec-9", slot = 2, team = 1, price = 500, clip = 18, reserve = 90, dmg = 33, pen = 0.903,
    cool = 0.12, spread = 0.011, move = 0.025, recoil = 1.4, reload = 2.5, range = 0.83, speed = 0.96, reward = 300, kind = "pistol"},
  {id = 21, key = "cz75", name = "CZ75-Auto", slot = 2, price = 500, clip = 12, reserve = 12, dmg = 31, pen = 0.776, auto = true,
    cool = 0.1, spread = 0.012, move = 0.03, recoil = 1.3, reload = 2.7, range = 0.82, speed = 0.96, reward = 100, kind = "pistol"},
  {id = 22, key = "dualies", name = "Dual Berettas", slot = 2, price = 300, clip = 30, reserve = 120, dmg = 38, pen = 0.575,
    cool = 0.12, spread = 0.012, move = 0.035, recoil = 1.5, reload = 3.8, range = 0.8, speed = 0.96, reward = 300, kind = "pistol",
    dual = true},
  {id = 23, key = "r8", name = "R8 Revolver", slot = 2, price = 600, clip = 8, reserve = 8, dmg = 86, pen = 0.932,
    cool = 0.5, spread = 0.006, move = 0.07, recoil = 5.0, reload = 2.3, range = 0.92, speed = 0.88, reward = 300, kind = "pistol"},
  -- Тяжёлое: дробовики и пулемёты
  {id = 24, key = "xm1014", name = "XM1014", slot = 1, price = 2000, clip = 7, reserve = 32, dmg = 20, pen = 0.8, pellets = 6,
    auto = true, cool = 0.35, spread = 0.05, move = 0.02, recoil = 2.4, reload = 3.2, range = 0.62, speed = 0.86, reward = 900, kind = "shotgun"},
  {id = 25, key = "sawedoff", name = "Sawed-Off", slot = 1, team = 1, price = 1100, clip = 7, reserve = 32, dmg = 32, pen = 0.75,
    pellets = 8, cool = 0.85, spread = 0.07, move = 0.02, recoil = 3.2, reload = 3.4, range = 0.5, speed = 0.84, reward = 900, kind = "shotgun"},
  {id = 26, key = "mag7", name = "MAG-7", slot = 1, team = 2, price = 1300, clip = 5, reserve = 32, dmg = 30, pen = 0.75,
    pellets = 8, cool = 0.85, spread = 0.045, move = 0.02, recoil = 3.2, reload = 2.4, range = 0.55, speed = 0.9, reward = 900, kind = "shotgun"},
  {id = 27, key = "m249", name = "M249", slot = 1, price = 5200, clip = 100, reserve = 200, dmg = 32, pen = 0.8, auto = true,
    cool = 0.08, spread = 0.012, move = 0.1, recoil = 0.9, reload = 5.7, range = 0.97, speed = 0.78, reward = 300, kind = "lmg"},
  {id = 28, key = "negev", name = "Negev", slot = 1, price = 1700, clip = 150, reserve = 300, dmg = 35, pen = 0.71, auto = true,
    cool = 0.075, spread = 0.018, move = 0.1, recoil = 0.8, reload = 5.7, range = 0.97, speed = 0.78, reward = 300, kind = "lmg"},
  -- Пистолеты-пулемёты
  {id = 29, key = "mac10", name = "MAC-10", slot = 1, team = 1, price = 1050, clip = 30, reserve = 100, dmg = 29, pen = 0.575,
    auto = true, cool = 0.075, spread = 0.016, move = 0.02, recoil = 0.75, reload = 2.6, range = 0.8, speed = 0.96, reward = 600, kind = "smg"},
  {id = 30, key = "mp7", name = "MP7", slot = 1, price = 1500, clip = 30, reserve = 120, dmg = 29, pen = 0.625, auto = true,
    cool = 0.08, spread = 0.011, move = 0.02, recoil = 0.65, reload = 3.1, range = 0.85, speed = 0.88, reward = 600, kind = "smg"},
  {id = 31, key = "mp5sd", name = "MP5-SD", slot = 1, price = 1500, clip = 30, reserve = 120, dmg = 27, pen = 0.625, auto = true,
    cool = 0.08, spread = 0.01, move = 0.02, recoil = 0.6, reload = 2.6, range = 0.85, speed = 0.94, reward = 600, kind = "smg",
    silenced = true},
  {id = 32, key = "ump45", name = "UMP-45", slot = 1, price = 1200, clip = 25, reserve = 100, dmg = 35, pen = 0.65, auto = true,
    cool = 0.09, spread = 0.013, move = 0.02, recoil = 0.8, reload = 3.5, range = 0.75, speed = 0.92, reward = 600, kind = "smg"},
  {id = 33, key = "bizon", name = "PP-Bizon", slot = 1, price = 1400, clip = 64, reserve = 120, dmg = 27, pen = 0.575, auto = true,
    cool = 0.08, spread = 0.014, move = 0.02, recoil = 0.55, reload = 2.4, range = 0.8, speed = 0.96, reward = 600, kind = "smg"},
  -- Винтовки
  {id = 34, key = "m4a1s", name = "M4A1-S", slot = 1, team = 2, price = 2900, clip = 20, reserve = 80, dmg = 38, pen = 0.7,
    auto = true, cool = 0.1, spread = 0.003, move = 0.08, recoil = 0.7, reload = 3.1, range = 0.97, speed = 0.9, reward = 300,
    silenced = true, kind = "rifle"},
  {id = 35, key = "sg553", name = "SG 553", slot = 1, team = 1, price = 3000, clip = 30, reserve = 90, dmg = 30, pen = 1.0,
    auto = true, cool = 0.09, spread = 0.005, scoped = 0.002, move = 0.09, recoil = 0.9, reload = 2.8, range = 0.98, speed = 0.84,
    reward = 300, scope = {45}, kind = "rifle"},
  {id = 36, key = "aug", name = "AUG", slot = 1, team = 2, price = 3300, clip = 30, reserve = 90, dmg = 28, pen = 0.9,
    auto = true, cool = 0.09, spread = 0.005, scoped = 0.002, move = 0.085, recoil = 0.8, reload = 3.8, range = 0.98, speed = 0.88,
    reward = 300, scope = {45}, kind = "rifle"},
  {id = 37, key = "ssg08", name = "SSG 08", slot = 1, price = 1700, clip = 10, reserve = 90, dmg = 88, pen = 0.85,
    cool = 1.25, spread = 0.05, scoped = 0.002, move = 0.12, recoil = 3.5, reload = 3.7, range = 0.99, speed = 0.92, reward = 300,
    scope = {40, 15}, kind = "sniper"},
  {id = 38, key = "g3sg1", name = "G3SG1", slot = 1, team = 1, price = 5000, clip = 20, reserve = 90, dmg = 80, pen = 0.825,
    auto = true, cool = 0.25, spread = 0.06, scoped = 0.0025, move = 0.2, recoil = 2.2, reload = 4.7, range = 0.99, speed = 0.86,
    reward = 300, scope = {40, 15}, kind = "sniper"},
  {id = 39, key = "scar20", name = "SCAR-20", slot = 1, team = 2, price = 5000, clip = 20, reserve = 90, dmg = 80, pen = 0.825,
    auto = true, cool = 0.25, spread = 0.06, scoped = 0.0025, move = 0.2, recoil = 2.2, reload = 3.1, range = 0.99, speed = 0.86,
    reward = 300, scope = {40, 15}, kind = "sniper"},
  -- Гранаты и Zeus
  {id = 40, key = "molotov", name = "Коктейль Молотова", slot = 4, team = 1, price = 400, max = 1, speed = 0.98, reward = 300, kind = "nade"},
  {id = 41, key = "incgrenade", name = "Зажигательная граната", slot = 4, team = 2, price = 500, max = 1, speed = 0.98, reward = 300,
    kind = "nade"},
  {id = 42, key = "decoy", name = "Ложная граната", slot = 4, price = 50, max = 1, speed = 0.98, reward = 300, kind = "nade"},
  {id = 43, key = "zeus", name = "Zeus x27", slot = 3, price = 200, dmg = 500, pen = 1, cool = 0.6, reach = 1.9, speed = 1.0,
    reward = 0, kind = "zeus"},
}
D.KNIFE, D.GLOCK, D.USP, D.AWP, D.HE, D.FLASH, D.SMOKE, D.C4 = 1, 2, 3, 13, 14, 15, 16, 17
D.MOLOTOV, D.INC, D.DECOY, D.ZEUS = 40, 41, 42, 43
-- Поле игрока с числом гранат каждого вида (молотов у Т и зажигательная у КТ — одно поле).
D.NADE_FIELD = {[14] = "he", [15] = "fl", [16] = "sm", [40] = "mo", [41] = "mo", [42] = "de"}
D.NADE_ORDER = {14, 15, 16, 40, 41, 42}
D.MAX_NADES = 4
for _, w in ipairs(D.WEAPONS) do D[w.key] = w.id end

-- Меню покупки (B): категории → предметы (как в CS2). Каждая команда видит только своё и общее.
D.BUY = {
  {name = "Пистолеты", items = {2, 3, 18, 4, 22, 20, 19, 21, 5, 23}},
  {name = "Тяжёлое", items = {6, 24, 25, 26, 27, 28}},
  {name = "Пистолеты-пулемёты", items = {29, 7, 30, 31, 32, 8, 33}},
  {name = "Винтовки", items = {9, 10, 11, 12, 34, 35, 36, 37, 13, 38, 39}},
  {name = "Снаряжение", items = {"kevlar", "helmet", 43, "kit"}},
  {name = "Гранаты", items = {14, 15, 16, 40, 41, 42}},
}
D.GEAR = {
  kevlar = {name = "Бронежилет", price = 650},
  helmet = {name = "Бронежилет + шлем", price = 1000},
  kit = {name = "Набор сапёра", price = 400, team = 2},
}

D.MONEY_START, D.MONEY_MAX = 800, 16000
D.WIN_REWARD = {elim = 3250, time = 3250, bomb = 3500, defuse = 3500}
D.LOSS_BONUS = {1400, 1900, 2400, 2900, 3400}
D.PLANT_REWARD, D.DEFUSE_REWARD, D.PLANTED_LOSS_BONUS = 300, 300, 800

D.FREEZE_TIME, D.BUY_TIME, D.ROUND_TIME, D.END_TIME = 6, 25, 115, 5
D.BOMB_TIME, D.PLANT_TIME, D.DEFUSE_TIME, D.DEFUSE_KIT_TIME = 40, 3.2, 7, 4
D.FIRE_TIME, D.FIRE_RADIUS, D.FIRE_DPS = 7, 1.35, 34 -- молотов: горит 7 с, круг 1,35 блока (~2,4 м), урон в секунду

D.HEAD, D.BODY, D.LEGS = 2, 1, 3
D.PART_MUL = {1, 4, 0.75}

D.BOT_NAMES = {"Вася", "Петя", "Гоша", "Сеня", "Миша", "Лёша", "Дима", "Костя", "Федя", "Женя", "Толя", "Боря",
  "Слава", "Рома", "Ваня", "Гриша", "Егор", "Стёпа", "Тёма", "Кеша"}
D.BOT_LEVELS = {"Лёгкие", "Обычные", "Сложные"}

D.ROUND_REASON = {
  elim = "Все противники уничтожены",
  time = "Время вышло",
  bomb = "Бомба взорвана",
  defuse = "Бомба обезврежена",
}

function D.weapon(id) return D.WEAPONS[id] end

function D.itemName(item)
  if type(item) == "number" then return D.WEAPONS[item].name end
  return D.GEAR[item].name
end

function D.itemPrice(item)
  if type(item) == "number" then return D.WEAPONS[item].price or 0 end
  return D.GEAR[item].price
end

function D.itemTeam(item)
  if type(item) == "number" then return D.WEAPONS[item].team end
  return D.GEAR[item].team
end

-- Предметы раздела покупки, которые доступны команде team.
function D.buyItems(cat, team)
  local out = {}
  for _, item in ipairs(D.BUY[cat].items) do
    local t = D.itemTeam(item)
    if not t or t == team then out[#out + 1] = item end
  end
  return out
end

-- Огненная граната своей команды.
function D.fireNade(team) return team == D.T and D.MOLOTOV or D.INC end

-- Всего гранат у игрока.
function D.nadeCount(p) return (p.he or 0) + (p.fl or 0) + (p.sm or 0) + (p.mo or 0) + (p.de or 0) end

return D
