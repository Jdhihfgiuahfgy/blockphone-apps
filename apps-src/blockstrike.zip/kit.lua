-- Сборка 3D-моделей из деталей (оружие, агенты, предметы карты): коробки с мягкими гранями, профили (боковой
-- силуэт, выдавленный в толщину — ствольные коробки, приклады, рукояти), цилиндры и конусы (стволы, глушители,
-- прицелы, бочки), эллипсоиды (головы, гранаты). У каждой вершины своя нормаль — g3d освещает модель плавно.
-- Материал — клетка атласа textures/kit_atlas.png (имена — kitmats.lua). Есть стек преобразований: деталь можно
-- сдвинуть и повернуть (K.push / K.move / K.turn / K.pop).
-- Оси модели: +X вправо, +Y вверх, +Z вперёд. Углы — как в g3d: R = Ry(yaw) · Rx(pitch) · Rz(roll).
local K = {}
K.MAT = require("kitmats")

local sin, cos, rad, deg, sqrt, abs, min, max = math.sin, math.cos, math.rad, math.deg, math.sqrt, math.abs, math.min, math.max
local asin = math.asin
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local ATLAS, CELLS = 512, 16

-- --- Матрицы 3×3 (по строкам) ---

function K.euler(yaw, pitch, roll)
  local y, p, r = rad(yaw or 0), rad(pitch or 0), rad(roll or 0)
  local cy, sy, cp, sp, cr, sr = cos(y), sin(y), cos(p), sin(p), cos(r), sin(r)
  -- Ry · (Rx · Rz), Rx = [1 0 0; 0 cp sp; 0 -sp cp], Rz = [cr -sr 0; sr cr 0; 0 0 1]
  return {cy * cr - sy * sp * sr, -cy * sr - sy * sp * cr, sy * cp,
    cp * sr, cp * cr, sp,
    -sy * cr - cy * sp * sr, sy * sr - cy * sp * cr, cy * cp}
end

function K.mul(a, b)
  local o = {}
  for i = 0, 2 do
    for j = 0, 2 do
      o[i * 3 + j + 1] = a[i * 3 + 1] * b[j + 1] + a[i * 3 + 2] * b[3 + j + 1] + a[i * 3 + 3] * b[6 + j + 1]
    end
  end
  return o
end

function K.apply(m, x, y, z)
  return m[1] * x + m[2] * y + m[3] * z, m[4] * x + m[5] * y + m[6] * z, m[7] * x + m[8] * y + m[9] * z
end

-- Матрица → углы g3d (yaw, pitch, roll).
function K.toEuler(m)
  local sp = max(-1, min(1, m[6]))
  local pitch = asin(sp)
  local cp = cos(pitch)
  local yaw, roll
  if abs(cp) > 1e-4 then
    yaw = atan2(m[3], m[9])
    roll = atan2(m[4], m[5])
  else
    yaw = atan2(-m[7], m[1])
    roll = 0
  end
  return deg(yaw), deg(pitch), deg(roll)
end

-- Базис с осью «вперёд» (+Z) по dir и «вверх» (+Y) поближе к up: столбцы — X, Y, Z.
function K.lookAt(dx, dy, dz, ux, uy, uz)
  local l = sqrt(dx * dx + dy * dy + dz * dz)
  dx, dy, dz = dx / l, dy / l, dz / l
  ux, uy, uz = ux or 0, uy or 1, uz or 0
  -- X = up × Z
  local xx, xy, xz = uy * dz - uz * dy, uz * dx - ux * dz, ux * dy - uy * dx
  local xl = sqrt(xx * xx + xy * xy + xz * xz)
  if xl < 1e-5 then
    ux, uy, uz = 1, 0, 0
    xx, xy, xz = uy * dz - uz * dy, uz * dx - ux * dz, ux * dy - uy * dx
    xl = sqrt(xx * xx + xy * xy + xz * xz)
  end
  xx, xy, xz = xx / xl, xy / xl, xz / xl
  local yx, yy, yz = dy * xz - dz * xy, dz * xx - dx * xz, dx * xy - dy * xx
  return {xx, yx, dx, xy, yy, dy, xz, yz, dz}
end

-- --- Построитель ---

function K.new()
  return {v = {}, n = {}, i = {}, count = 0, M = {1, 0, 0, 0, 1, 0, 0, 0, 1}, P = {0, 0, 0}, stack = {}}
end

function K.push(m) m.stack[#m.stack + 1] = {m.M, m.P} end

function K.pop(m)
  local s = table.remove(m.stack)
  m.M, m.P = s[1], s[2]
end

function K.move(m, x, y, z)
  local dx, dy, dz = K.apply(m.M, x, y, z)
  m.P = {m.P[1] + dx, m.P[2] + dy, m.P[3] + dz}
end

function K.turn(m, yaw, pitch, roll) m.M = K.mul(m.M, K.euler(yaw, pitch, roll)) end

function K.basis(m, R) m.M = K.mul(m.M, R) end

-- Клетка материала → u0, v0, u1, v1 (с отступом в полпикселя от краёв клетки).
function K.uv(mat)
  local idx = type(mat) == "number" and mat or K.MAT[mat]
  if not idx then error("kit: unknown material " .. tostring(mat)) end
  local cx, cy = idx % CELLS, math.floor(idx / CELLS)
  local s = ATLAS / CELLS
  return (cx * s + 1) / ATLAS, (cy * s + 1) / ATLAS, ((cx + 1) * s - 1) / ATLAS, ((cy + 1) * s - 1) / ATLAS
end

local function vert(m, x, y, z, nx, ny, nz, u, v)
  local M, P = m.M, m.P
  local wx, wy, wz = M[1] * x + M[2] * y + M[3] * z + P[1], M[4] * x + M[5] * y + M[6] * z + P[2], M[7] * x + M[8] * y + M[9] * z + P[3]
  local tx, ty, tz = M[1] * nx + M[2] * ny + M[3] * nz, M[4] * nx + M[5] * ny + M[6] * nz, M[7] * nx + M[8] * ny + M[9] * nz
  local vs, ns = m.v, m.n
  local k = #vs
  vs[k + 1], vs[k + 2], vs[k + 3], vs[k + 4], vs[k + 5] = wx, wy, wz, u, v
  local j = #ns
  ns[j + 1], ns[j + 2], ns[j + 3] = tx, ty, tz
  m.count = m.count + 1
  return m.count
end

local function tri(m, a, b, c)
  local is = m.i
  local k = #is
  is[k + 1], is[k + 2], is[k + 3] = a, b, c
end

-- Четырёхугольник p1..p4 (по часовой для зрителя снаружи — как в city.lua), нормали n1..n4 или одна на всех.
function K.quad(m, p1, p2, p3, p4, mat, n, uvr)
  local u0, v0, u1, v1
  if uvr then u0, v0, u1, v1 = uvr[1], uvr[2], uvr[3], uvr[4] else u0, v0, u1, v1 = K.uv(mat) end
  local nx, ny, nz
  if not n then
    -- нормаль грани: (p2 − p1) × (p4 − p1) направлена наружу при обходе как в box ниже
    local ax, ay, az = p2[1] - p1[1], p2[2] - p1[2], p2[3] - p1[3]
    local bx, by, bz = p4[1] - p1[1], p4[2] - p1[2], p4[3] - p1[3]
    nx, ny, nz = by * az - bz * ay, bz * ax - bx * az, bx * ay - by * ax
    local l = sqrt(nx * nx + ny * ny + nz * nz)
    if l > 0 then nx, ny, nz = nx / l, ny / l, nz / l end
  end
  local ns
  if n and type(n[1]) == "table" then
    ns = n
  else
    if n then nx, ny, nz = n[1], n[2], n[3] end
    local f = {nx, ny, nz}
    ns = {f, f, f, f}
  end
  local a = vert(m, p1[1], p1[2], p1[3], ns[1][1], ns[1][2], ns[1][3], u0, v0)
  local b = vert(m, p2[1], p2[2], p2[3], ns[2][1], ns[2][2], ns[2][3], u1, v0)
  local c = vert(m, p3[1], p3[2], p3[3], ns[3][1], ns[3][2], ns[3][3], u1, v1)
  local d = vert(m, p4[1], p4[2], p4[3], ns[4][1], ns[4][2], ns[4][3], u0, v1)
  tri(m, a, b, c)
  tri(m, a, c, d)
end

local function norm(x, y, z)
  local l = sqrt(x * x + y * y + z * z)
  if l < 1e-9 then return 0, 1, 0 end
  return x / l, y / l, z / l
end

-- Коробка x1..x2, y1..y2, z1..z2. o: tilt (поворот вокруг X через центр, градусы), soft (0..1 — скруглённый свет у
-- рёбер), mats {top, bottom, front, back, left, right} — свой материал грани, taper (сужение верха 0..1 по X и Z).
function K.box(m, x1, y1, z1, x2, y2, z2, mat, o)
  o = o or {}
  local cy, cz, cx = (y1 + y2) / 2, (z1 + z2) / 2, (x1 + x2) / 2
  local c, s = cos(rad(o.tilt or 0)), sin(rad(o.tilt or 0))
  local tp = o.taper or 0
  local function P(x, y, z)
    if tp ~= 0 and y > cy then
      x = cx + (x - cx) * (1 - tp)
      z = cz + (z - cz) * (1 - tp * (o.taperZ or 1))
    end
    local dy, dz = y - cy, z - cz
    return {x, cy + dy * c + dz * s, cz + dz * c - dy * s}
  end
  local p = {P(x1, y2, z2), P(x2, y2, z2), P(x2, y1, z2), P(x1, y1, z2), P(x1, y2, z1), P(x2, y2, z1), P(x2, y1, z1), P(x1, y1, z1)}
  local soft = o.soft or 0
  local ms = o.mats or {}
  local center = {cx, cy, cz}
  local function faceN(a, b, d)
    local ax, ay, az = b[1] - a[1], b[2] - a[2], b[3] - a[3]
    local bx, by, bz = d[1] - a[1], d[2] - a[2], d[3] - a[3]
    return norm(by * az - bz * ay, bz * ax - bx * az, bx * ay - by * ax)
  end
  local function face(a, b, cc, d, fm)
    local nx, ny, nz = faceN(a, b, d)
    local ns
    if soft > 0 then
      ns = {}
      for k, q in ipairs({a, b, cc, d}) do
        local ex, ey, ez = norm(q[1] - center[1], q[2] - center[2], q[3] - center[3])
        ns[k] = {norm(nx + ex * soft, ny + ey * soft, nz + ez * soft)}
      end
    else
      ns = {nx, ny, nz}
    end
    K.quad(m, a, b, cc, d, fm or mat, ns, o.uvr)
  end
  face(p[1], p[2], p[3], p[4], ms.front)
  face(p[6], p[5], p[8], p[7], ms.back)
  face(p[5], p[1], p[4], p[8], ms.left)
  face(p[2], p[6], p[7], p[3], ms.right)
  face(p[5], p[6], p[2], p[1], ms.top)
  face(p[4], p[3], p[7], p[8], ms.bottom)
end

-- Цилиндр/конус от точки a до b: радиусы r1 (у a) и r2 (у b), seg сторон. o: caps (true по умолчанию), capMat,
-- flat (без плавного света по кругу), uvAround (сколько раз материал по кругу), sx/sy — эллипс сечения.
function K.cyl(m, a, b, r1, r2, seg, mat, o)
  o = o or {}
  seg = seg or 10
  local R = K.lookAt(b[1] - a[1], b[2] - a[2], b[3] - a[3], o.ux or 0, o.uy or 1, o.uz or 0)
  local len = sqrt((b[1] - a[1]) ^ 2 + (b[2] - a[2]) ^ 2 + (b[3] - a[3]) ^ 2)
  local sx, sy = o.sx or 1, o.sy or 1
  local u0, v0, u1, v1 = K.uv(mat)
  local function P(ang, r, z)
    local lx, ly = cos(ang) * r * sx, sin(ang) * r * sy
    local x, y, zz = K.apply(R, lx, ly, z)
    return a[1] + x, a[2] + y, a[3] + zz
  end
  local slope = (r1 - r2) / max(len, 1e-6)
  local ring1, ring2 = {}, {}
  for k = 0, seg do
    local ang = k / seg * math.pi * 2
    local nx, ny, nz = K.apply(R, cos(ang) * sy, sin(ang) * sx, slope)
    nx, ny, nz = norm(nx, ny, nz)
    local u = u0 + (u1 - u0) * (k / seg)
    local x, y, z = P(ang, r1, 0)
    ring1[k] = vert(m, x, y, z, nx, ny, nz, u, v1)
    x, y, z = P(ang, r2, len)
    ring2[k] = vert(m, x, y, z, nx, ny, nz, u, v0)
  end
  for k = 0, seg - 1 do
    tri(m, ring1[k], ring2[k], ring2[k + 1])
    tri(m, ring1[k], ring2[k + 1], ring1[k + 1])
  end
  if o.caps ~= false then
    local cu0, cv0, cu1, cv1 = K.uv(o.capMat or mat)
    for side = 1, 2 do
      local r = side == 1 and r1 or r2
      if r > 0 then
        local z = side == 1 and 0 or len
        local nx, ny, nz = K.apply(R, 0, 0, side == 1 and -1 or 1)
        local x, y, zz = P(0, 0, z)
        local cv = vert(m, x, y, zz, nx, ny, nz, (cu0 + cu1) / 2, (cv0 + cv1) / 2)
        local ring = {}
        for k = 0, seg do
          local ang = k / seg * math.pi * 2
          x, y, zz = P(ang, r, z)
          ring[k] = vert(m, x, y, zz, nx, ny, nz, cu0 + (cu1 - cu0) * (0.5 + cos(ang) * 0.5), cv0 + (cv1 - cv0) * (0.5 + sin(ang) * 0.5))
        end
        for k = 0, seg - 1 do
          if side == 1 then tri(m, cv, ring[k + 1], ring[k]) else tri(m, cv, ring[k], ring[k + 1]) end
        end
      end
    end
  end
end

-- Эллипсоид с центром c и полуосями rx, ry, rz.
function K.ball(m, c, rx, ry, rz, seg, mat, o)
  seg = seg or 10
  o = o or {}
  local rows = math.max(4, math.floor(seg / 2))
  local u0, v0, u1, v1 = K.uv(mat)
  local grid = {}
  for i = 0, rows do
    local th = i / rows * math.pi
    grid[i] = {}
    for k = 0, seg do
      local ph = k / seg * math.pi * 2
      local nx, ny, nz = sin(th) * cos(ph), cos(th), sin(th) * sin(ph)
      local x, y, z = c[1] + nx * rx, c[2] + ny * ry, c[3] + nz * rz
      local gx, gy, gz = norm(nx / rx, ny / ry, nz / rz)
      grid[i][k] = vert(m, x, y, z, gx, gy, gz, u0 + (u1 - u0) * k / seg, v0 + (v1 - v0) * i / rows)
    end
  end
  for i = 0, rows - 1 do
    for k = 0, seg - 1 do
      tri(m, grid[i][k], grid[i][k + 1], grid[i + 1][k + 1])
      tri(m, grid[i][k], grid[i + 1][k + 1], grid[i + 1][k])
    end
  end
end

-- Треугольники многоугольника (ушная триангуляция; точки {a, b} против часовой).
local function triangulate(pts)
  local n = #pts
  local idx = {}
  for k = 1, n do idx[k] = k end
  -- ориентация: если по часовой — развернуть
  local area = 0
  for k = 1, n do
    local p, q = pts[k], pts[k % n + 1]
    area = area + p[1] * q[2] - q[1] * p[2]
  end
  if area < 0 then
    local r = {}
    for k = n, 1, -1 do r[#r + 1] = idx[k] end
    idx = r
  end
  local out = {}
  local function cross(o, a, b) return (a[1] - o[1]) * (b[2] - o[2]) - (a[2] - o[2]) * (b[1] - o[1]) end
  local guard = 0
  while #idx > 3 and guard < 500 do
    guard = guard + 1
    local found = false
    for k = 1, #idx do
      local ia, ib, ic = idx[(k - 2) % #idx + 1], idx[k], idx[k % #idx + 1]
      local a, b, c = pts[ia], pts[ib], pts[ic]
      if cross(a, b, c) > 1e-12 then
        local inside = false
        for _, j in ipairs(idx) do
          if j ~= ia and j ~= ib and j ~= ic then
            local p = pts[j]
            if cross(a, b, p) >= 0 and cross(b, c, p) >= 0 and cross(c, a, p) >= 0 then inside = true break end
          end
        end
        if not inside then
          out[#out + 1] = {ia, ib, ic}
          table.remove(idx, k)
          found = true
          break
        end
      end
    end
    if not found then break end
  end
  if #idx == 3 then out[#out + 1] = {idx[1], idx[2], idx[3]} end
  return out
end

-- Профиль: силуэт сбоку (точки {z, y}), выдавленный по X от x1 до x2. o: smooth (угол в градусах, до которого
-- соседние стороны освещаются плавно, по умолчанию 40), capMat — материал боковин, round (0..1 — свет на рёбрах
-- боковин скругляется), sideMat.
function K.prism(m, pts, x1, x2, mat, o)
  o = o or {}
  local n = #pts
  -- обход: против часовой на плоскости (z, y) при взгляде с +X
  local area = 0
  for k = 1, n do
    local p, q = pts[k], pts[k % n + 1]
    area = area + p[1] * q[2] - q[1] * p[2]
  end
  local P = pts
  if area < 0 then
    P = {}
    for k = n, 1, -1 do P[#P + 1] = pts[k] end
  end
  local limit = cos(rad(o.smooth or 40))
  -- нормали сторон (наружу) на плоскости (z, y)
  local en = {}
  for k = 1, n do
    local a, b = P[k], P[k % n + 1]
    local dz, dy = b[1] - a[1], b[2] - a[2]
    local nz, ny = dy, -dz
    local l = sqrt(nz * nz + ny * ny)
    en[k] = l > 0 and {nz / l, ny / l} or {0, 1}
  end
  local sideMat = o.sideMat or mat
  local u0, v0, u1, v1 = K.uv(sideMat)
  local round = o.round or 0.35
  for k = 1, n do
    local a, b = P[k], P[k % n + 1]
    local prev, nxt = en[(k - 2) % n + 1], en[k % n + 1]
    local e = en[k]
    local function vn(other)
      if e[1] * other[1] + e[2] * other[2] > limit then return norm(0, e[2] + other[2], e[1] + other[1]) end
      return 0, e[2], e[1]
    end
    local ax, ay, az = vn(prev)
    local bx, by, bz = vn(nxt)
    -- стороны: от x1 к x2, нормаль с лёгким уклоном к краю (мягкие рёбра)
    local ua = u0 + (u1 - u0) * ((k - 1) / n)
    local ub = u0 + (u1 - u0) * (k / n)
    local i1 = vert(m, x1, a[2], a[1], ax - round, ay, az, ua, v1)
    local i2 = vert(m, x2, a[2], a[1], ax + round, ay, az, ua, v0)
    local i3 = vert(m, x2, b[2], b[1], bx + round, by, bz, ub, v0)
    local i4 = vert(m, x1, b[2], b[1], bx - round, by, bz, ub, v1)
    -- нормали с «round» по X не единичные: движок их нормирует
    tri(m, i1, i2, i3)
    tri(m, i1, i3, i4)
  end
  -- боковины
  local cu0, cv0, cu1, cv1 = K.uv(o.capMat or mat)
  local zmin, zmax, ymin, ymax = 1e9, -1e9, 1e9, -1e9
  for _, p in ipairs(P) do
    zmin, zmax, ymin, ymax = min(zmin, p[1]), max(zmax, p[1]), min(ymin, p[2]), max(ymax, p[2])
  end
  local tris = triangulate(P)
  for side = 1, 2 do
    local x = side == 1 and x1 or x2
    local nx = side == 1 and -1 or 1
    local ids = {}
    for k, p in ipairs(P) do
      local u = cu0 + (cu1 - cu0) * (p[1] - zmin) / max(1e-6, zmax - zmin)
      local v = cv1 - (cv1 - cv0) * (p[2] - ymin) / max(1e-6, ymax - ymin)
      ids[k] = vert(m, x, p[2], p[1], nx, 0, 0, u, v)
    end
    for _, t in ipairs(tris) do
      if side == 2 then tri(m, ids[t[1]], ids[t[2]], ids[t[3]]) else tri(m, ids[t[1]], ids[t[3]], ids[t[2]]) end
    end
  end
end

-- Профиль, заданный строкой точек «z,y z,y …» — удобно писать модели.
function K.pts(s)
  local out = {}
  for z, y in s:gmatch("(-?[%d%.]+),(-?[%d%.]+)") do out[#out + 1] = {tonumber(z), tonumber(y)} end
  return out
end

-- Готовая сетка g3d (или таблица для выгрузки, если g3d нет).
function K.finish(m)
  if #m.i == 0 then return nil end
  if K.capture then return K.capture(m) end
  return g3d.mesh({vertices = m.v, indices = m.i, normals = m.n})
end

function K.vertices(m) return m.count end

return K
