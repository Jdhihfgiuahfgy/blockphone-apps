-- Данные клана: вход, чаты, сообщения, связь с сервером (clan-server/worker.js на Cloudflare).
-- Новое приходит «долгим запросом» /sync: сервер держит ответ до 10 с, пока не появятся события. Запросов у
-- приложения не больше 60 в минуту — здесь свой счётчик (не больше 50), чтобы телефон не остановил приложение.

local C = {}

C.DEFAULT_URL = "https://blockphone-clan.darkminecraft000.workers.dev"
C.ROLE_MEMBER, C.ROLE_ADMIN, C.ROLE_OWNER = 0, 1, 2

C.url = storage.get("url", "")
C.token = storage.get("token", "")
C.clan = storage.get("clan", "Astrum Mortis")
C.name = storage.get("name", "")
C.role = storage.get("role", 0)
C.muted = storage.get("muted", {})          -- [id чата] = true — без звука

C.status = "offline"       -- offline | connecting | online | error | removed
C.loaded = false           -- список чатов получен
C.chats = {}               -- id → чат (карточка с сервера)
C.msgs = {}                -- id чата → {list = {}, loaded, more, loading}
C.pending = {}             -- nonce → {chat, text, at, sticker}
C.online = {}              -- ник → true
C.typing = {}              -- id чата → {ник = до какого времени}
C.members = nil            -- участники клана (вкладка «Клан»)
C.openChat = nil           -- открытый на экране чат (его сообщения сразу прочитаны)
C.onEvent = nil            -- function(kind, data) — для экрана (новое сообщение, чат удалён, ...)

local since = 0
local syncing = false
local nextSync = 0
local failures = 0
local requests = {}
local nonce = 0
local readSent = {}

function C.server()
  return C.url ~= "" and C.url or C.DEFAULT_URL
end

function C.joined()
  return C.token ~= ""
end

-- ---------- Запросы ----------

local function budget()
  local now = time.now()
  local keep = {}
  for _, t in ipairs(requests) do
    if now - t < 60000 then keep[#keep + 1] = t end
  end
  requests = keep
  return #requests < 50
end

-- Запрос к серверу: cb(ok, data, status). Нет «бюджета» — сразу ошибка "busy".
function C.api(op, body, cb)
  if not budget() then
    if cb then cb(false, {error = "busy"}, 0) end
    return false
  end
  requests[#requests + 1] = time.now()
  local headers = {}
  if C.token ~= "" then headers.Authorization = "Bearer " .. C.token end
  http.post(C.server() .. "/" .. op, body or {}, function(ok, status, text)
    local data
    if type(text) == "string" and text:sub(1, 1) == "{" then
      local good, decoded = pcall(json.decode, text)
      if good and type(decoded) == "table" then data = decoded end
    end
    data = data or {error = status == 0 and "network" or "server"}
    if status == 401 and C.token ~= "" then
      C.status = (data.error == "removed") and "removed" or "error"
      C.lastError = data.error
    end
    if cb then cb(ok and data.error == nil, data, status) end
  end, headers)
  return true
end

-- ---------- Вход ----------

function C.join(code, url, cb)
  C.url = url or ""
  C.api("join", {code = code, name = app.player}, function(ok, data)
    if ok and data.token then
      C.token = data.token
      C.clan = data.clan or C.clan
      C.name = data.name or app.player
      C.role = data.role or 0
      storage.set("url", C.url)
      storage.set("token", C.token)
      storage.set("clan", C.clan)
      storage.set("name", C.name)
      storage.set("role", C.role)
      C.reset()
      C.start()
    end
    cb(ok, data.error)
  end)
end

function C.logout()
  C.token = ""
  storage.set("token", "")
  C.reset()
  C.status = "offline"
end

function C.reset()
  C.loaded = false
  C.chats, C.msgs, C.pending, C.online, C.typing = {}, {}, {}, {}, {}
  C.members = nil
  since = 0
  readSent = {}
end

-- ---------- Чаты ----------

local function setOnline(list)
  C.online = {}
  for _, n in ipairs(list or {}) do C.online[n] = true end
end

function C.start()
  if not C.joined() then return end
  C.status = "connecting"
  C.api("chats", {}, function(ok, data)
    if not ok then
      if C.status ~= "removed" then C.status = "error" end
      C.lastError = data.error
      failures = failures + 1
      nextSync = time.now() + math.min(60, 2 ^ failures) * 1000
      return
    end
    failures = 0
    C.clan, C.name, C.role = data.clan or C.clan, data.name or C.name, data.role or C.role
    storage.set("clan", C.clan)
    storage.set("role", C.role)
    since = data.since or 0
    setOnline(data.online)
    local old = C.msgs
    C.chats, C.msgs = {}, {}
    for _, chat in ipairs(data.chats or {}) do C.chats[chat.id] = chat end
    C.loaded = true
    C.status = "online"
    -- Открытый чат после переподключения — заново с сервера.
    if C.openChat and old[C.openChat] then C.history(C.openChat) end
    if C.onEvent then C.onEvent("reload") end
    nextSync = 0
  end)
end

-- Каждый тик (и с закрытым телефоном): держать «долгий запрос».
function C.tick()
  if not C.joined() or syncing or C.status == "removed" then return end
  local now = time.now()
  if now < nextSync then return end
  if not C.loaded then
    if C.status ~= "connecting" then C.start() end
    nextSync = now + 3000
    return
  end
  syncing = true
  local started = C.api("sync", {since = since}, function(ok, data)
    syncing = false
    if not ok then
      if C.status ~= "removed" then C.status = "error" end
      failures = failures + 1
      nextSync = time.now() + math.min(60, 2 ^ failures) * 1000
      return
    end
    failures = 0
    C.status = "online"
    if data.reset then
      C.loaded = false
      nextSync = 0
      return
    end
    since = data.since or since
    setOnline(data.online)
    for _, e in ipairs(data.events or {}) do C.apply(e) end
    -- Не чаще раза в 1,5 с: в шумном чате запросов не больше ~40 в минуту.
    nextSync = time.now() + 1500
  end)
  if not started then
    syncing = false
    nextSync = now + 2000
  end
end

function C.messages(chatId)
  local m = C.msgs[chatId]
  if not m then
    m = {list = {}, loaded = false, more = false, loading = false}
    C.msgs[chatId] = m
  end
  return m
end

local function sortedInsert(list, msg)
  for i = #list, 1, -1 do
    if list[i].id == msg.id then list[i] = msg return end
    if list[i].id < msg.id then table.insert(list, i + 1, msg) return end
  end
  table.insert(list, 1, msg)
end

function C.apply(e)
  if e.t == "msg" then
    local msg = e.msg
    if e.nonce and e.nonce ~= "" then C.pending[e.nonce] = nil end
    local m = C.msgs[msg.chat]
    if m and m.loaded then sortedInsert(m.list, msg) end
    if C.typing[msg.chat] then C.typing[msg.chat][msg.from] = nil end
    local chat = C.chats[msg.chat]
    if chat then
      chat.last = msg
      local mine = msg.from == C.name
      if C.openChat == msg.chat then
        chat.unread = 0
        C.markRead(msg.chat)
      elseif not mine then
        chat.unread = (chat.unread or 0) + 1
        if C.onEvent then C.onEvent("incoming", msg) end
      end
    end
  elseif e.t == "upd" then
    local msg = e.msg
    local m = C.msgs[msg.chat]
    if m and m.loaded then
      for i, x in ipairs(m.list) do
        if x.id == msg.id then m.list[i] = msg end
      end
    end
    local chat = C.chats[msg.chat]
    if chat and chat.last and chat.last.id == msg.id then chat.last = msg end
  elseif e.t == "chat" then
    local chat = e.chat
    if C.openChat == chat.id then chat.unread = 0 end
    C.chats[chat.id] = chat
  elseif e.t == "gone" then
    C.chats[e.chat] = nil
    C.msgs[e.chat] = nil
    if C.onEvent then C.onEvent("gone", e.chat) end
  elseif e.t == "typing" then
    C.typing[e.chat] = C.typing[e.chat] or {}
    C.typing[e.chat][e.name] = time.now() + 4500
  elseif e.t == "role" then
    C.role = e.role
    storage.set("role", C.role)
  end
end

-- Чаты по порядку: общий чат клана первым, дальше — по последнему сообщению.
function C.chatList()
  local list = {}
  for _, chat in pairs(C.chats) do list[#list + 1] = chat end
  local function activity(c)
    local t = c.last and c.last.at or c.created or 0
    for _, p in pairs(C.pending) do
      if p.chat == c.id and p.at > t then t = p.at end
    end
    return t
  end
  table.sort(list, function(a, b)
    if a.main ~= b.main then return a.main end
    local ta, tb = activity(a), activity(b)
    if ta ~= tb then return ta > tb end
    return a.id > b.id
  end)
  return list
end

function C.unreadTotal()
  local n = 0
  for _, chat in pairs(C.chats) do n = n + (chat.unread or 0) end
  return n
end

-- Собеседник в личном чате.
function C.partner(chat)
  if chat.type ~= "direct" then return nil end
  for _, n in ipairs(chat.members or {}) do
    if n ~= C.name then return n end
  end
  return chat.members and chat.members[1] or "?"
end

function C.title(chat)
  return C.partner(chat) or (chat.title ~= "" and chat.title or "?")
end

function C.typingNames(chatId)
  local t = C.typing[chatId]
  local names = {}
  if not t then return names end
  local now = time.now()
  for n, untilAt in pairs(t) do
    if untilAt > now then names[#names + 1] = n else t[n] = nil end
  end
  table.sort(names)
  return names
end

function C.history(chatId)
  local m = C.messages(chatId)
  m.loading = true
  C.api("history", {chat = chatId}, function(ok, data)
    m.loading = false
    if not ok then return end
    m.list = data.msgs or {}
    m.more = data.more
    m.loaded = true
    if C.openChat == chatId then C.markRead(chatId) end
  end)
end

function C.older(chatId)
  local m = C.messages(chatId)
  if not m.loaded or not m.more or m.loading or #m.list == 0 then return end
  m.loading = true
  C.api("history", {chat = chatId, before = m.list[1].id}, function(ok, data)
    m.loading = false
    if not ok then return end
    local merged = {}
    for _, x in ipairs(data.msgs or {}) do merged[#merged + 1] = x end
    for _, x in ipairs(m.list) do merged[#merged + 1] = x end
    m.list = merged
    m.more = data.more
  end)
end

function C.open(chatId)
  C.openChat = chatId
  if chatId then
    local chat = C.chats[chatId]
    if chat then chat.unread = 0 end
    local m = C.messages(chatId)
    if not m.loaded and not m.loading then C.history(chatId) else C.markRead(chatId) end
  end
end

function C.markRead(chatId)
  local m = C.msgs[chatId]
  local chat = C.chats[chatId]
  local last = (m and #m.list > 0 and m.list[#m.list].id) or (chat and chat.last and chat.last.id) or 0
  if last > (readSent[chatId] or 0) then
    readSent[chatId] = last
    C.api("read", {chat = chatId, id = last})
  end
end

-- Отправить: сразу видно полупрозрачным, пока сервер не подтвердит. onError(key) — не отправилось.
function C.send(chatId, text, reply, sticker, onError)
  nonce = nonce + 1
  local n = "n" .. nonce .. "_" .. time.now()
  C.pending[n] = {chat = chatId, text = text, at = time.now(), sticker = sticker, reply = reply}
  C.api("send", {chat = chatId, text = text, reply = reply, sticker = sticker, nonce = n}, function(ok, data)
    if ok then
      C.pending[n] = nil
      if data.msg then C.apply({t = "msg", msg = data.msg}) end
    else
      C.pending[n] = nil
      if onError then onError(data.error) end
    end
  end)
end

function C.pendingFor(chatId)
  local list = {}
  for _, p in pairs(C.pending) do
    if p.chat == chatId then list[#list + 1] = p end
  end
  table.sort(list, function(a, b) return a.at < b.at end)
  return list
end

local lastTyping = 0
function C.typingNow(chatId)
  local now = time.now()
  if now - lastTyping > 4000 then
    lastTyping = now
    C.api("typing", {chat = chatId})
  end
end

function C.loadMembers(cb)
  C.api("members", {}, function(ok, data)
    if ok then C.members = data.members end
    if cb then cb(ok, data) end
  end)
end

function C.isAdmin()
  return C.role >= C.ROLE_ADMIN
end

function C.toggleMute(chatId)
  local key = tostring(chatId)
  C.muted[key] = not C.muted[key] or nil
  storage.set("muted", C.muted)
end

function C.isMuted(chatId)
  return C.muted[tostring(chatId)] == true
end

return C
