-- Данные клана: вход, чаты, сообщения, связь с сервером (clan-server/worker.js на Cloudflare).
-- Новое приходит «долгим запросом» /sync: сервер держит ответ до 10 с, пока не появятся события. Запросов у
-- приложения не больше 60 в минуту — здесь свой счётчик (не больше 50), чтобы телефон не остановил приложение.

local C = {}

C.DEFAULT_URL = "https://blockphone-clan.darkminecraft000.workers.dev"
C.ROLE_MEMBER, C.ROLE_ADMIN, C.ROLE_OWNER = 0, 1, 2

C.url = storage.get("url", "")
C.token = storage.get("token", "")
C.clan = storage.get("clan", "Astrum Mortis")
C.name = storage.get("name", "")
C.role = storage.get("role", 0)
C.canInvite = storage.get("canInvite", false)  -- право приглашать (у главы и админов — всегда)
C.muted = storage.get("muted", {})          -- [id чата] = true — без звука
C.volume = storage.get("voiceVolume", 2)    -- громкость голосовых: 1 — как записано, до 5 (500 %)
pcall(audio.volume, C.volume)
C.REACTIONS = {"like", "heart", "fire", "laugh", "wow", "sad", "party", "dislike"}
C.packs = nil              -- мои наборы стикеров (свои и добавленные) с сервера
C.stickerLimits = nil
C.packCache = {}           -- id набора → набор (просмотр чужого набора)

C.status = "offline"       -- offline | connecting | online | error | removed
C.loaded = false           -- список чатов получен
C.chats = {}               -- id → чат (карточка с сервера)
C.msgs = {}                -- id чата → {list = {}, loaded, more, loading}
C.pending = {}             -- nonce → {chat, text, at, sticker}
C.online = {}              -- ник → true
C.typing = {}              -- id чата → {ник = до какого времени}
C.members = nil            -- участники клана (вкладка «Клан»)
C.openChat = nil           -- открытый на экране чат (его сообщения сразу прочитаны)
C.visible = false          -- приложение на экране (иначе о новых сообщениях — уведомления)
C.onEvent = nil            -- function(kind, data) — для экрана (новое сообщение, чат удалён, ...)

local since = 0
local syncing = false
local nextSync = 0
local failures = 0
local requests = {}
local nonce = 0
local readSent = {}
local stickersDirty = false
local stickersAt = 0

function C.server()
  return C.url ~= "" and C.url or C.DEFAULT_URL
end

function C.joined()
  return C.token ~= ""
end

-- ---------- Запросы ----------

local function budget()
  local now = time.now()
  local keep = {}
  for _, t in ipairs(requests) do
    if now - t < 60000 then keep[#keep + 1] = t end
  end
  requests = keep
  return #requests < 50
end

-- Запрос к серверу: cb(ok, data, status). Нет «бюджета» — сразу ошибка "busy".
function C.api(op, body, cb)
  if not budget() then
    if cb then cb(false, {error = "busy"}, 0) end
    return false
  end
  requests[#requests + 1] = time.now()
  local headers = {}
  if C.token ~= "" then headers.Authorization = "Bearer " .. C.token end
  http.post(C.server() .. "/" .. op, body or {}, function(ok, status, text)
    local data
    if type(text) == "string" and text:sub(1, 1) == "{" then
      local good, decoded = pcall(json.decode, text)
      if good and type(decoded) == "table" then data = decoded end
    end
    data = data or {error = status == 0 and "network" or "server"}
    if status == 401 and C.token ~= "" then
      C.status = (data.error == "removed") and "removed" or "error"
      C.lastError = data.error
    end
    if cb then cb(ok and data.error == nil, data, status) end
  end, headers)
  return true
end

-- ---------- Вход ----------

function C.join(code, url, cb)
  C.url = url or ""
  C.api("join", {code = code, name = app.player}, function(ok, data)
    if ok and data.token then
      C.token = data.token
      C.clan = data.clan or C.clan
      C.name = data.name or app.player
      C.role = data.role or 0
      storage.set("url", C.url)
      storage.set("token", C.token)
      storage.set("clan", C.clan)
      storage.set("name", C.name)
      storage.set("role", C.role)
      C.reset()
      C.start()
    end
    cb(ok, data.error)
  end)
end

function C.logout()
  C.token = ""
  storage.set("token", "")
  C.reset()
  C.status = "offline"
end

function C.reset()
  C.loaded = false
  C.chats, C.msgs, C.pending, C.online, C.typing = {}, {}, {}, {}, {}
  C.members = nil
  C.packs = nil
  C.packCache = {}
  since = 0
  readSent = {}
end

-- ---------- Чаты ----------

local function setOnline(list)
  C.online = {}
  for _, n in ipairs(list or {}) do C.online[n] = true end
end

function C.start()
  if not C.joined() then return end
  C.status = "connecting"
  C.api("chats", {}, function(ok, data)
    if not ok then
      if C.status ~= "removed" then C.status = "error" end
      C.lastError = data.error
      failures = failures + 1
      nextSync = time.now() + math.min(60, 2 ^ failures) * 1000
      return
    end
    failures = 0
    C.clan, C.name, C.role = data.clan or C.clan, data.name or C.name, data.role or C.role
    C.canInvite = data.canInvite == true
    storage.set("clan", C.clan)
    storage.set("role", C.role)
    storage.set("canInvite", C.canInvite)
    since = data.since or 0
    setOnline(data.online)
    local old = C.msgs
    C.chats, C.msgs = {}, {}
    for _, chat in ipairs(data.chats or {}) do C.chats[chat.id] = chat end
    C.loaded = true
    C.status = "online"
    -- Открытый чат после переподключения — заново с сервера.
    if C.openChat and old[C.openChat] then C.history(C.openChat) end
    if C.onEvent then C.onEvent("reload") end
    nextSync = 0
    stickersDirty = true
  end)
end

-- Каждый тик (и с закрытым телефоном): держать «долгий запрос».
function C.tick()
  if not C.joined() or syncing or C.status == "removed" then return end
  local now = time.now()
  -- Наборы стикеров изменились (свои или добавленные) — перечитать, но не чаще раза в 3 с.
  if stickersDirty and C.loaded and now - stickersAt > 3000 then
    stickersDirty = false
    stickersAt = now
    C.loadStickers()
  end
  if now < nextSync then return end
  if not C.loaded then
    if C.status ~= "connecting" then C.start() end
    nextSync = now + 3000
    return
  end
  syncing = true
  local started = C.api("sync", {since = since}, function(ok, data)
    syncing = false
    if not ok then
      if C.status ~= "removed" then C.status = "error" end
      failures = failures + 1
      nextSync = time.now() + math.min(60, 2 ^ failures) * 1000
      return
    end
    failures = 0
    C.status = "online"
    if data.reset then
      C.loaded = false
      nextSync = 0
      return
    end
    since = data.since or since
    setOnline(data.online)
    for _, e in ipairs(data.events or {}) do C.apply(e) end
    -- Не чаще раза в 1,5 с: в шумном чате запросов не больше ~40 в минуту.
    nextSync = time.now() + 1500
  end)
  if not started then
    syncing = false
    nextSync = now + 2000
  end
end

function C.messages(chatId)
  local m = C.msgs[chatId]
  if not m then
    m = {list = {}, loaded = false, more = false, loading = false}
    C.msgs[chatId] = m
  end
  return m
end

local function sortedInsert(list, msg)
  for i = #list, 1, -1 do
    if list[i].id == msg.id then list[i] = msg return end
    if list[i].id < msg.id then table.insert(list, i + 1, msg) return end
  end
  table.insert(list, 1, msg)
end

function C.apply(e)
  if e.t == "msg" then
    local msg = e.msg
    if e.nonce and e.nonce ~= "" then C.pending[e.nonce] = nil end
    local m = C.msgs[msg.chat]
    if m and m.loaded then sortedInsert(m.list, msg) end
    if C.typing[msg.chat] then C.typing[msg.chat][msg.from] = nil end
    local chat = C.chats[msg.chat]
    if chat then
      chat.last = msg
      local mine = msg.from == C.name
      if C.openChat == msg.chat then
        chat.unread = 0
        C.markRead(msg.chat)
      elseif not mine then
        chat.unread = (chat.unread or 0) + 1
        if C.onEvent then C.onEvent("incoming", msg) end
      end
      -- Уведомление телефона: приложение свёрнуто или открыт другой чат; чат «без звука» — молча.
      if not mine and not C.isMuted(msg.chat) and (not C.visible or C.openChat ~= msg.chat) then
        local title = chat.type == "group" and (msg.from .. " → " .. C.title(chat)) or msg.from
        pcall(notify, title, C.preview(msg), "chat:" .. msg.chat)
      end
    end
  elseif e.t == "upd" then
    local msg = e.msg
    local m = C.msgs[msg.chat]
    if m and m.loaded then
      for i, x in ipairs(m.list) do
        if x.id == msg.id then m.list[i] = msg end
      end
    end
    local chat = C.chats[msg.chat]
    if chat and chat.last and chat.last.id == msg.id then chat.last = msg end
  elseif e.t == "chat" then
    local chat = e.chat
    if C.openChat == chat.id then chat.unread = 0 end
    C.chats[chat.id] = chat
  elseif e.t == "gone" then
    C.chats[e.chat] = nil
    C.msgs[e.chat] = nil
    if C.onEvent then C.onEvent("gone", e.chat) end
  elseif e.t == "typing" then
    C.typing[e.chat] = C.typing[e.chat] or {}
    C.typing[e.chat][e.name] = time.now() + 4500
  elseif e.t == "role" then
    C.role = e.role
    storage.set("role", C.role)
  elseif e.t == "invite" then
    C.canInvite = e.canInvite == true
    storage.set("canInvite", C.canInvite)
  elseif e.t == "stickers" then
    stickersDirty = true
    C.packCache = {}
  end
end

-- Чаты по порядку: общий чат клана первым, дальше — по последнему сообщению.
function C.chatList()
  local list = {}
  for _, chat in pairs(C.chats) do list[#list + 1] = chat end
  local function activity(c)
    local t = c.last and c.last.at or c.created or 0
    for _, p in pairs(C.pending) do
      if p.chat == c.id and p.at > t then t = p.at end
    end
    return t
  end
  table.sort(list, function(a, b)
    if a.main ~= b.main then return a.main end
    local ta, tb = activity(a), activity(b)
    if ta ~= tb then return ta > tb end
    return a.id > b.id
  end)
  return list
end

local function voiceTime(ms)
  local sec = math.floor((ms or 0) / 1000 + 0.5)
  return string.format("%d:%02d", math.floor(sec / 60), sec % 60)
end
C.voiceTime = voiceTime

-- Короткий текст сообщения для списка чатов и уведомлений: «[Фото] подпись», «[Голосовое 0:07]», «[Стикер]».
function C.preview(m)
  local ru = app.lang == "ru_ru"
  if m.deleted then return ru and "Сообщение удалено" or "Message deleted" end
  if m.sticker and m.sticker ~= "" then return ru and "[Стикер]" or "[Sticker]" end
  if m.voice then return (ru and "[Голосовое " or "[Voice ") .. voiceTime(m.voice.duration) .. "]" end
  local text = (m.text or ""):gsub("\n", " ")
  if m.image then
    local photo = ru and "[Фото]" or "[Photo]"
    return text == "" and photo or (photo .. " " .. text)
  end
  return text
end

function C.unreadTotal()
  local n = 0
  for _, chat in pairs(C.chats) do n = n + (chat.unread or 0) end
  return n
end

-- Собеседник в личном чате.
function C.partner(chat)
  if chat.type ~= "direct" then return nil end
  for _, n in ipairs(chat.members or {}) do
    if n ~= C.name then return n end
  end
  return chat.members and chat.members[1] or "?"
end

function C.title(chat)
  return C.partner(chat) or (chat.title ~= "" and chat.title or "?")
end

function C.typingNames(chatId)
  local t = C.typing[chatId]
  local names = {}
  if not t then return names end
  local now = time.now()
  for n, untilAt in pairs(t) do
    if untilAt > now then names[#names + 1] = n else t[n] = nil end
  end
  table.sort(names)
  return names
end

function C.history(chatId)
  local m = C.messages(chatId)
  m.loading = true
  C.api("history", {chat = chatId}, function(ok, data)
    m.loading = false
    if not ok then return end
    m.list = data.msgs or {}
    m.more = data.more
    m.loaded = true
    if C.openChat == chatId then C.markRead(chatId) end
  end)
end

function C.older(chatId)
  local m = C.messages(chatId)
  if not m.loaded or not m.more or m.loading or #m.list == 0 then return end
  m.loading = true
  C.api("history", {chat = chatId, before = m.list[1].id}, function(ok, data)
    m.loading = false
    if not ok then return end
    local merged = {}
    for _, x in ipairs(data.msgs or {}) do merged[#merged + 1] = x end
    for _, x in ipairs(m.list) do merged[#merged + 1] = x end
    m.list = merged
    m.more = data.more
  end)
end

function C.open(chatId)
  C.openChat = chatId
  if chatId then
    pcall(unnotify, "chat:" .. chatId)
    local chat = C.chats[chatId]
    if chat then chat.unread = 0 end
    local m = C.messages(chatId)
    if not m.loaded and not m.loading then C.history(chatId) else C.markRead(chatId) end
  end
end

function C.markRead(chatId)
  local m = C.msgs[chatId]
  local chat = C.chats[chatId]
  local last = (m and #m.list > 0 and m.list[#m.list].id) or (chat and chat.last and chat.last.id) or 0
  if last > (readSent[chatId] or 0) then
    readSent[chatId] = last
    C.api("read", {chat = chatId, id = last})
  end
end

-- Отправить: сразу видно полупрозрачным, пока сервер не подтвердит. onError(key) — не отправилось.
function C.send(chatId, text, reply, sticker, onError, stickerUrl)
  nonce = nonce + 1
  local n = "n" .. nonce .. "_" .. time.now()
  C.pending[n] = {chat = chatId, text = text, at = time.now(), sticker = sticker, stickerUrl = stickerUrl, reply = reply}
  C.api("send", {chat = chatId, text = text, reply = reply, sticker = sticker, nonce = n}, function(ok, data)
    if ok then
      C.pending[n] = nil
      if data.msg then C.apply({t = "msg", msg = data.msg}) end
    else
      C.pending[n] = nil
      if onError then onError(data.error) end
    end
  end)
end

-- Загрузить фото ({photo = n}), стикер ({sticker = n}) или запись голоса ({clip = n}) на сервер клана: cb(ok, data) — data.file, data.url.
function C.upload(handle, cb)
  if not budget() then
    cb(false, {error = "busy"})
    return
  end
  requests[#requests + 1] = time.now()
  local ok, err = pcall(http.upload, C.server() .. "/upload", handle, {headers = {Authorization = "Bearer " .. C.token}},
    function(good, status, text)
      local data
      if type(text) == "string" and text:sub(1, 1) == "{" then
        local okj, decoded = pcall(json.decode, text)
        if okj and type(decoded) == "table" then data = decoded end
      end
      data = data or {error = status == 0 and "network" or "server"}
      cb(good and data.error == nil and data.file ~= nil, data)
    end)
  if not ok then cb(false, {error = tostring(err)}) end
end

-- Фото или голосовое: сразу видно полупрозрачным, потом загрузка и отправка. kind — "image" | "voice".
function C.sendMedia(chatId, text, reply, handle, kind, onError)
  nonce = nonce + 1
  local n = "m" .. nonce .. "_" .. time.now()
  local p = {chat = chatId, text = kind == "voice" and "" or text, at = time.now(), reply = reply}
  if kind == "image" then p.image = {handle = handle} else p.voice = {duration = handle.duration or 0} end
  C.pending[n] = p
  C.upload(handle, function(ok, data)
    if not ok then
      C.pending[n] = nil
      if onError then onError(data.error) end
      return
    end
    local body = {chat = chatId, text = p.text, reply = reply, nonce = n}
    body[kind] = data.file
    C.api("send", body, function(sent, result)
      C.pending[n] = nil
      if sent then
        if result.msg then C.apply({t = "msg", msg = result.msg}) end
      elseif onError then
        onError(result.error)
      end
    end)
  end)
end

function C.pendingFor(chatId)
  local list = {}
  for _, p in pairs(C.pending) do
    if p.chat == chatId then list[#list + 1] = p end
  end
  table.sort(list, function(a, b) return a.at < b.at end)
  return list
end

local lastTyping = 0
function C.typingNow(chatId)
  local now = time.now()
  if now - lastTyping > 4000 then
    lastTyping = now
    C.api("typing", {chat = chatId})
  end
end

function C.loadMembers(cb)
  C.api("members", {}, function(ok, data)
    if ok then C.members = data.members end
    if cb then cb(ok, data) end
  end)
end

-- ---------- Громкость голосовых ----------

function C.setVolume(v)
  C.volume = math.max(0.5, math.min(5, v))
  storage.set("voiceVolume", C.volume)
  pcall(audio.volume, C.volume)
end

-- ---------- Реакции ----------

-- Моя реакция на сообщение (или nil).
function C.myReaction(m)
  for r, names in pairs(m.reactions or {}) do
    for _, n in ipairs(names) do
      if n == C.name then return r end
    end
  end
  return nil
end

-- Поставить/снять реакцию: сразу на экране, потом подтверждение сервера (событие upd).
function C.react(m, r)
  local old = C.myReaction(m)
  local reactions = {}
  for k, names in pairs(m.reactions or {}) do
    local copy = {}
    for _, n in ipairs(names) do
      if n ~= C.name then copy[#copy + 1] = n end
    end
    if #copy > 0 then reactions[k] = copy end
  end
  if old ~= r then
    reactions[r] = reactions[r] or {}
    table.insert(reactions[r], C.name)
  end
  m.reactions = next(reactions) and reactions or nil
  C.api("react", {id = m.id, r = r}, function(ok, data)
    if not ok and C.onEvent then C.onEvent("error", data.error) end
  end)
end

-- ---------- Свои стикеры ----------

function C.loadStickers(cb)
  C.api("stickers", {}, function(ok, data)
    if ok then
      C.packs = data.packs or {}
      C.stickerLimits = data.limits
    end
    if cb then cb(ok, data) end
  end)
end

function C.loadPack(id, cb)
  C.api("pack", {id = id}, function(ok, data)
    if ok then C.packCache[id] = data.pack end
    if cb then cb(ok, data) end
  end)
end

-- Набор по id: из своих или из просмотренных.
function C.findPack(id)
  for _, p in ipairs(C.packs or {}) do
    if p.id == id then return p end
  end
  return C.packCache[id]
end

function C.packAction(action, id, title, cb)
  C.api("packAction", {action = action, id = id, title = title}, function(ok, data)
    if ok and data.pack then C.packCache[data.pack.id] = data.pack end
    if ok then C.loadStickers() end
    if cb then cb(ok, data) end
  end)
end

-- Стикер ({sticker = n} из photos.sticker) → загрузка PNG → в набор.
function C.addSticker(packId, handle, cb)
  C.upload(handle, function(ok, data)
    if not ok then
      cb(false, data)
      return
    end
    C.api("stickerAdd", {pack = packId, file = data.file}, function(added, result)
      if added and result.pack then C.packCache[packId] = result.pack end
      if added then C.loadStickers() end
      cb(added, result)
    end)
  end)
end

function C.removeSticker(stickerId, packId, cb)
  local n = tonumber(tostring(stickerId):match("^c(%d+)$"))
  C.api("stickerRemove", {id = n}, function(ok, data)
    if ok then
      local p = C.findPack(packId)
      if p then
        for i, s in ipairs(p.stickers) do
          if s.id == stickerId then table.remove(p.stickers, i) break end
        end
      end
      C.loadStickers()
    end
    if cb then cb(ok, data) end
  end)
end

function C.isAdmin()
  return C.role >= C.ROLE_ADMIN
end

function C.mayInvite()
  return C.isAdmin() or C.canInvite
end

function C.toggleMute(chatId)
  local key = tostring(chatId)
  C.muted[key] = not C.muted[key] or nil
  storage.set("muted", C.muted)
end

function C.isMuted(chatId)
  return C.muted[tostring(chatId)] == true
end

return C
