-- «Astrum Mortis» — мессенджер клана. Работает на любом сервере и в одиночной игре: сообщения идут через свой
-- сервер клана в облаке (clan-server в репозитории BlockPhone), а не через сервер Minecraft.
-- Экраны: вход по коду → вкладки «Чаты» / «Клан»; переписка, сведения о чате, новый чат, выбор чата для пересылки.

local C = require("clan")
local U = require("ui")
local tr = U.tr

local W, H = 160, 290
local TAB_H = 18
local INPUT_H = 16

local screen_ = "chats"      -- join | chats | clan | chat | info | new | pick
local stack = {}              -- предыдущие экраны (для «назад»)
local scroll = {}             -- прокрутка по экрану
local chatId = nil            -- открытый чат
local replyTo, editing = nil, nil
local lastInput = ""
local newGroup, picked = false, {}
local pickAction = nil        -- выбор чата: function(chatId)
local addTo = nil             -- добавить участников в группу (id чата)
local joinBusy, joinError, showUrl = false, nil, false
local renaming = false
local invite = nil            -- последний созданный код {code, uses, expires, name}
local shown = true             -- приложение на экране (в фоне чат не считается прочитанным)
local INPUTS = {"code", "url", "msg", "title", "rename"}

local ERRORS = {
  bad_code = {"Неверный или устаревший код", "Wrong or expired code"},
  already_member = {"Вы уже в клане. Попросите у админа код «вернуть вход»", "You are already a member. Ask an admin for a restore code"},
  bad_request = {"Неверные данные", "Bad request"},
  rate_limit = {"Слишком часто, подождите", "Too often, wait a bit"},
  network = {"Нет связи с сервером клана", "Can't reach the clan server"},
  server = {"Сервер клана не ответил", "The clan server didn't answer"},
  busy = {"Слишком много запросов, подождите", "Too many requests, wait a bit"},
  not_member = {"Вы не в этом чате", "You are not in this chat"},
  not_owner = {"Нет прав", "Not allowed"},
  not_admin = {"Только для админов", "Admins only"},
  main_chat = {"Из общего чата клана нельзя выйти", "You can't leave the clan chat"},
  too_long = {"Слишком длинно", "Too long"},
  bad_title = {"Введите название", "Enter a title"},
  group_full = {"В группе не больше 50 человек", "At most 50 people in a group"},
  user_not_found = {"Игрок не найден", "Player not found"},
  unauthorized = {"Вход больше не действует", "Your login is no longer valid"},
  removed = {"Вас исключили из клана", "You were removed from the clan"},
}

local function errorText(key)
  local e = ERRORS[key or ""]
  return e and tr(e[1], e[2]) or tr("Ошибка: ", "Error: ") .. tostring(key)
end

local function fail(key)
  toast(errorText(key))
end

-- ---------- Навигация ----------

local function go(name, keep)
  if keep ~= false then stack[#stack + 1] = screen_ end
  screen_ = name
  scroll[name] = 0
  U.menu, U.dialog = nil, nil
end

local function root()
  stack = {}
  screen_ = C.joined() and (screen_ == "clan" and "clan" or "chats") or "join"
end

local function back()
  if U.dialog or U.menu then
    U.dialog, U.menu = nil, nil
    return true
  end
  if replyTo or editing then
    replyTo, editing = nil, nil
    ui.setText("msg", "")
    return true
  end
  if #stack == 0 then return false end
  screen_ = table.remove(stack)
  if screen_ ~= "chat" and screen_ ~= "info" then C.open(nil) end
  return true
end

local function openChat(id)
  stack = {}
  screen_ = "chats"
  go("chat")
  chatId = id
  replyTo, editing = nil, nil
  ui.setText("msg", "")
  scroll.chat = 0
  C.open(id)
end

-- ---------- Обратные вызовы ----------

C.onEvent = function(kind, data)
  if kind == "incoming" then
    if not C.isMuted(data.chat) then
      sound.play("block.note_block.pling", 0.5, 1.5)
    end
  elseif kind == "gone" and chatId == data and (screen_ == "chat" or screen_ == "info") then
    C.open(nil)
    stack = {}
    screen_ = "chats"
    toast(tr("Вы больше не в этом чате", "You are no longer in this chat"))
  end
end

function onStart()
  screen.background(true)
  if C.joined() then
    screen_ = "chats"
    C.start()
  else
    screen_ = "join"
  end
end

function onShow()
  shown = true
  if screen_ == "chat" and chatId then C.open(chatId) end
end

function onHide()
  shown = false
  C.open(nil)
end

function onTick()
  C.tick()
  if shown and screen_ == "chat" and chatId and C.openChat ~= chatId then C.open(chatId) end
end

function onBack()
  return back()
end

function onClick(x, y, button)
  U.click(x, y, button)
end

function onScroll(amount, x, y)
  if U.blocked() then return end
  local step = amount * 24
  if screen_ == "chat" then
    scroll.chat = math.max(0, (scroll.chat or 0) + step)
  else
    scroll[screen_] = math.max(0, (scroll[screen_] or 0) - step)
  end
end

-- ---------- Отправка ----------

local function submitMessage(text)
  text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if text == "" or not chatId then return end
  if #text > 3000 then fail("too_long") return end
  if editing then
    local id = editing
    editing = nil
    C.api("edit", {id = id, text = text}, function(ok, data) if not ok then fail(data.error) end end)
  else
    C.send(chatId, text, replyTo and replyTo.id or nil, nil, fail)
    replyTo = nil
  end
  ui.setText("msg", "")
  lastInput = ""
  scroll.chat = 0
end

local function doJoin(typed)
  local code = (typed or ui.getText("code")):gsub("%s", "")
  if code == "" or joinBusy then return end
  joinBusy, joinError = true, nil
  local url = showUrl and ui.getText("url"):gsub("%s", ""):gsub("/+$", "") or C.url
  C.join(code, url, function(ok, err)
    joinBusy = false
    if ok then
      ui.setText("code", "")
      stack = {}
      screen_ = "chats"
    else
      joinError = errorText(err)
    end
  end)
end

function onSubmit(id, text)
  if id == "msg" then
    submitMessage(text)
  elseif id == "code" then
    doJoin(text)
  elseif id == "url" then
    doJoin()
  elseif id == "title" then
    -- Enter в названии группы — создать
  elseif id == "rename" and chatId then
    local title = text:gsub("^%s+", ""):gsub("%s+$", "")
    if title ~= "" then
      C.api("groupAction", {chat = chatId, action = "rename", title = title}, function(ok, data)
        if not ok then fail(data.error) end
      end)
    end
    renaming = false
  end
end

-- ---------- Экраны ----------

local function parkInputs(used)
  -- Поля, которых нет на этом экране, уводим за край: иначе они ловили бы нажатия по старому месту.
  for _, id in ipairs(INPUTS) do
    if not used[id] then ui.input(id, -500, -500, 1, 1) end
  end
end

local function statusLine(y)
  local text, color
  if C.status == "removed" then
    text, color = errorText("removed"), theme.danger()
  elseif C.status == "error" then
    text, color = C.lastError == "unauthorized" and errorText("unauthorized") or tr("Нет связи, переподключение…", "Offline, reconnecting…"), theme.danger()
  elseif C.status == "connecting" or not C.loaded then
    text, color = tr("Подключение…", "Connecting…"), theme.secondary()
  end
  if text then
    gfx.rect(0, y, W, 11, 0x30000000)
    gfx.textCenter(U.ellipsize(text, W - 6, 0.6), W / 2, y + 2, color, 0.6)
    return 11
  end
  return 0
end

-- Вход
local function drawJoin()
  screen.title(C.clan)
  local used = {code = true}
  local y = 14
  gfx.circle(W / 2, y + 16, 16, 0xFF7A3FD1)
  gfx.textCenter("✦", W / 2, y + 11, 0xFFFFFFFF, 1.4)
  y = y + 40
  gfx.textCenter(U.tr("Мессенджер клана", "Clan messenger"), W / 2, y, theme.text(), 0.9)
  y = y + 12
  for _, line in ipairs(gfx.wrap(tr("Работает на любом сервере и в одиночной игре. Введите код-приглашение от главы или админа клана.",
      "Works on any server and in singleplayer. Enter an invite code from the clan leader or an admin."), W - 20, 0.65)) do
    gfx.textCenter(line, W / 2, y, theme.secondary(), 0.65)
    y = y + 8
  end
  y = y + 6
  gfx.text(tr("Вы войдёте как ", "You will join as ") .. app.player, 10, y, theme.secondary(), 0.6)
  y = y + 9
  ui.input("code", 10, y, W - 20, 16, tr("Код приглашения", "Invite code"))
  y = y + 22
  U.button(10, y, W - 20, 18, joinBusy and tr("Вход…", "Joining…") or tr("Войти", "Join"), "primary", function() doJoin() end)
  y = y + 24
  if joinError then
    for _, line in ipairs(gfx.wrap(joinError, W - 20, 0.65)) do
      gfx.textCenter(line, W / 2, y, theme.danger(), 0.65)
      y = y + 8
    end
    y = y + 4
  end
  local label = showUrl and tr("Сервер клана:", "Clan server:") or tr("Другой сервер клана ›", "Other clan server ›")
  gfx.text(label, 10, y, theme.secondary(), 0.6)
  U.hit(10, y - 2, W - 20, 10, function()
    showUrl = not showUrl
    if showUrl then ui.setText("url", C.server()) end
  end)
  y = y + 10
  if showUrl then
    used.url = true
    ui.input("url", 10, y, W - 20, 14, C.DEFAULT_URL)
  end
  parkInputs(used)
end

local function tabs()
  local y = H - TAB_H
  gfx.rect(0, y, W, TAB_H, theme.card())
  gfx.rect(0, y, W, 1, 0x30FFFFFF)
  local items = {{"chats", tr("Чаты", "Chats"), C.unreadTotal()}, {"clan", tr("Клан", "Clan"), 0}}
  local tw = W / #items
  for i, it in ipairs(items) do
    local x = (i - 1) * tw
    local selected = screen_ == it[1]
    if selected then gfx.rect(x + 8, y + 1, tw - 16, 1, theme.accent()) end
    local color = selected and theme.accent() or (ui.hovered(x, y, tw, TAB_H) and theme.text() or theme.secondary())
    gfx.textCenter(it[2], x + tw / 2, y + 6, color, 0.7)
    if it[3] > 0 then U.badge(it[3], x + tw - 6, y + 2) end
    U.hit(x, y, tw, TAB_H, function()
      stack = {}
      screen_ = it[1]
      if it[1] == "clan" then C.loadMembers() end
    end)
  end
end

local function listArea(name, top, bottom, contentH)
  local maxScroll = math.max(0, contentH - (bottom - top))
  scroll[name] = math.min(scroll[name] or 0, maxScroll)
  return scroll[name]
end

-- Список чатов
local function drawChats()
  screen.title(C.clan)
  parkInputs({})
  local top = statusLine(0)
  local bottom = H - TAB_H
  -- «+» — новый чат
  local list = C.chatList()
  local ROW = 30
  local content = (#list + 1) * ROW
  local off = listArea("chats", top, bottom, content)
  gfx.clip(0, top, W, bottom - top)
  local y = top - off
  -- строка «Новый чат»
  if y + ROW > top then
    if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
    gfx.circle(6 + 11, y + 4 + 11, 11, theme.accent())
    gfx.textCenter("+", 17, y + 10, theme.onAccent(), 1.2)
    gfx.text(tr("Новый чат или группа", "New chat or group"), 34, y + 11, theme.accent(), 0.75)
    U.hit(0, math.max(y, top), W, ROW, function()
      newGroup, picked = false, {}
      addTo = nil
      go("new")
      C.loadMembers()
    end)
  end
  y = y + ROW
  if not C.loaded and #list == 0 then
    gfx.textCenter(tr("Загрузка…", "Loading…"), W / 2, y + 20, theme.secondary(), 0.7)
  end
  for _, chat in ipairs(list) do
    if y + ROW > top and y < bottom then
      if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
      local partner = C.partner(chat)
      local title = C.title(chat)
      U.avatar(title, 6, y + 4, 22, partner and C.online[partner], chat.type == "group")
      local tx = 34
      local time_ = chat.last and U.shortTime(chat.last.at) or ""
      local tw = gfx.textWidth(time_, 0.55)
      gfx.text(time_, W - 5 - tw, y + 6, theme.secondary(), 0.55)
      local name = (chat.main and "★ " or "") .. title
      gfx.text(U.ellipsize(name, W - tx - tw - 10, 0.75), tx, y + 5, theme.text(), 0.75)
      local preview
      local typing = C.typingNames(chat.id)
      if #typing > 0 then
        preview = (chat.type == "group" and (typing[1] .. " ") or "") .. tr("печатает…", "is typing…")
      elseif chat.last then
        local m = chat.last
        local body = m.deleted and tr("Сообщение удалено", "Message deleted")
            or (m.sticker ~= "" and tr("[Стикер]", "[Sticker]")) or m.text:gsub("\n", " ")
        if chat.type == "group" then
          body = (m.from == C.name and tr("Вы", "You") or m.from) .. ": " .. body
        elseif m.from == C.name then
          body = tr("Вы: ", "You: ") .. body
        end
        preview = body
      else
        preview = chat.type == "group" and (#chat.members .. tr(" участн.", " members")) or ""
      end
      local right = W - 6
      if (chat.unread or 0) > 0 then
        right = right - U.badge(chat.unread, right, y + 16) - 3
      elseif C.isMuted(chat.id) then
        gfx.text("×♪", right - 10, y + 16, theme.secondary(), 0.55)
        right = right - 12
      end
      gfx.text(U.ellipsize(preview, right - tx, 0.62), tx, y + 17, #typing > 0 and theme.accent() or theme.secondary(), 0.62)
      local id = chat.id
      U.hit(0, math.max(y, top), W, math.min(ROW, bottom - math.max(y, top)), function() openChat(id) end, function()
        local items = {{C.isMuted(id) and tr("Включить звук", "Unmute") or tr("Без звука", "Mute"), function() C.toggleMute(id) end}}
        if chat.type == "group" and not chat.main then
          items[#items + 1] = {tr("Выйти из группы", "Leave group"), function()
            U.confirm(tr("Выйти из группы?", "Leave group?"), title, tr("Выйти", "Leave"), true, function()
              C.api("groupAction", {chat = id, action = "leave"}, function(ok, data) if not ok then fail(data.error) end end)
            end)
          end, true}
        end
        local mx, my = input.mouse()
        U.openMenu(mx, my, items)
      end)
    end
    y = y + ROW
  end
  gfx.unclip()
  tabs()
end

-- Переписка

local BUBBLE_SCALE = 0.7
local LINE_H = 8

-- Высота и строки пузыря сообщения.
local function measure(m, maxW, group)
  local lay = {}
  local mine = m.from == C.name
  lay.mine = mine
  lay.showName = group and not mine
  local text = m.deleted and tr("Сообщение удалено", "Message deleted") or m.text
  lay.sticker = (not m.deleted) and m.sticker ~= "" and m.sticker or nil
  lay.lines = (lay.sticker and {}) or U.wrap(text, maxW - 10, BUBBLE_SCALE)
  local w = 0
  for _, l in ipairs(lay.lines) do w = math.max(w, gfx.textWidth(l, BUBBLE_SCALE)) end
  local timeStr = U.clock(m.at) .. ((m.edited or 0) > 0 and tr(" изм.", " ed.") or "")
  lay.time = timeStr
  local timeW = gfx.textWidth(timeStr, 0.5)
  local h = 4
  if lay.showName then h = h + 8; w = math.max(w, gfx.textWidth(m.from, 0.6)) end
  if m.fwd and m.fwd ~= "" then
    lay.fwd = tr("Переслано от ", "Forwarded from ") .. m.fwd
    w = math.max(w, math.min(maxW - 10, gfx.textWidth(lay.fwd, 0.55)))
    h = h + 8
  end
  if m.reply then
    lay.reply = m.reply
    w = math.max(w, math.min(maxW - 10, 70))
    h = h + 18
  end
  if lay.sticker then
    h = h + 40
    w = math.max(w, 40)
  else
    h = h + #lay.lines * LINE_H
  end
  -- время — в последней строке справа, если влезает, иначе отдельной строкой
  local lastW = #lay.lines > 0 and gfx.textWidth(lay.lines[#lay.lines], BUBBLE_SCALE) or 0
  if lay.sticker or lastW + timeW + 6 > maxW - 10 then
    h = h + 7
  end
  w = math.max(w, lastW + timeW + 6)
  lay.w = math.min(maxW, w + 10)
  lay.h = h + 3
  return lay
end

local layouts = {}

local function layoutOf(m, maxW, group)
  local key = m.id .. ":" .. (m.edited or 0) .. ":" .. (m.deleted and 1 or 0) .. ":" .. maxW
  local lay = layouts[key]
  if not lay then
    lay = measure(m, maxW, group)
    layouts[key] = lay
  end
  return lay
end

local function messageMenu(m)
  local items = {}
  if not m.deleted then
    items[#items + 1] = {tr("Ответить", "Reply"), function()
      replyTo, editing = m, nil
      ui.focus("msg")
    end}
    if m.text ~= "" then
      items[#items + 1] = {tr("Копировать", "Copy"), function() clipboard.set(m.text) toast(tr("Скопировано", "Copied")) end}
    end
    items[#items + 1] = {tr("Переслать", "Forward"), function()
      pickAction = function(to)
        C.api("forward", {id = m.id, chat = to}, function(ok, data)
          if ok then openChat(to) else fail(data.error) end
        end)
      end
      go("pick")
    end}
    if m.from == C.name and m.sticker == "" then
      items[#items + 1] = {tr("Изменить", "Edit"), function()
        editing, replyTo = m.id, nil
        ui.setText("msg", m.text)
        ui.focus("msg")
      end}
    end
    local chat = C.chats[m.chat]
    if m.from == C.name or (chat and chat.main and C.isAdmin()) then
      items[#items + 1] = {tr("Удалить", "Delete"), function()
        U.confirm(tr("Удалить сообщение?", "Delete message?"), tr("Его не увидит никто.", "Nobody will see it."), tr("Удалить", "Delete"), true,
            function()
              C.api("delete", {id = m.id}, function(ok, data) if not ok then fail(data.error) end end)
            end)
      end, true}
    end
  end
  if #items > 0 then
    local mx, my = input.mouse()
    U.openMenu(mx, my, items)
  end
end

local function drawBubble(m, lay, y, maxW, pending)
  local x = lay.mine and (W - 4 - lay.w) or 4
  local bg = lay.mine and theme.accent() or theme.card()
  local fg = lay.mine and theme.onAccent() or theme.text()
  local sub = lay.mine and 0xB0FFFFFF or theme.secondary()
  if lay.sticker then
    bg = 0
  end
  if pending and bg ~= 0 then bg = bit32.bor(bit32.band(bg, 0x00FFFFFF), 0x90000000) end
  if bg ~= 0 then
    gfx.roundRect(x, y, lay.w, lay.h, 4, bg)
    if not lay.mine then gfx.border(x, y, lay.w, lay.h, 0x20FFFFFF) end
  end
  local ty = y + 3
  if lay.showName then
    gfx.text(U.ellipsize(m.from, lay.w - 10, 0.6), x + 5, ty, theme.accent(), 0.6)
    ty = ty + 8
  end
  if lay.fwd then
    gfx.text(U.ellipsize(lay.fwd, lay.w - 10, 0.55), x + 5, ty, sub, 0.55)
    ty = ty + 8
  end
  if lay.reply then
    local r = lay.reply
    gfx.rect(x + 5, ty, 1, 15, lay.mine and 0xC0FFFFFF or theme.accent())
    gfx.text(U.ellipsize(r.from, lay.w - 14, 0.55), x + 9, ty + 1, lay.mine and fg or theme.accent(), 0.55)
    local rt = r.deleted and tr("Сообщение удалено", "Message deleted") or (r.sticker ~= "" and tr("[Стикер]", "[Sticker]")) or r.text:gsub("\n", " ")
    gfx.text(U.ellipsize(rt, lay.w - 14, 0.55), x + 9, ty + 8, sub, 0.55)
    ty = ty + 18
  end
  if lay.sticker then
    local path = "stickers/" .. lay.sticker .. ".png"
    local ok = pcall(gfx.image, path, x + 2, ty, 40, 40)
    if not ok then gfx.text("[" .. lay.sticker .. "]", x + 2, ty + 16, theme.secondary(), 0.6) end
    ty = ty + 40
  else
    for _, line in ipairs(lay.lines) do
      gfx.text(line, x + 5, ty, m.deleted and sub or fg, BUBBLE_SCALE)
      ty = ty + LINE_H
    end
  end
  local tw = gfx.textWidth(lay.time, 0.5)
  local timeText = pending and "◷" or lay.time
  gfx.text(timeText, x + lay.w - 5 - (pending and 4 or tw), y + lay.h - 7, lay.sticker and theme.secondary() or sub, 0.5)
end

local function drawChat()
  local chat = C.chats[chatId]
  if not chat then
    screen_ = "chats"
    stack = {}
    return
  end
  screen.title(C.title(chat))
  local used = {msg = true}
  -- Полоса статуса: в сети / печатает / участники; справа — «Инфо».
  local top = statusLine(0)
  local typing = C.typingNames(chatId)
  local sub
  if #typing > 0 then
    sub = (chat.type == "group" and (table.concat(typing, ", ") .. " ") or "") .. tr("печатает…", "typing…")
  elseif chat.type == "direct" then
    sub = C.online[C.partner(chat)] and tr("в сети", "online") or tr("не в сети", "offline")
  else
    local n = 0
    for _, name in ipairs(chat.members) do if C.online[name] then n = n + 1 end end
    sub = #chat.members .. tr(" участн., в сети: ", " members, online: ") .. n
  end
  gfx.rect(0, top, W, 12, theme.card())
  gfx.text(U.ellipsize(sub, W - 40, 0.6), 5, top + 3, #typing > 0 and theme.accent() or theme.secondary(), 0.6)
  local infoHover = not U.blocked() and ui.hovered(W - 34, top, 34, 12)
  gfx.text(tr("Инфо ›", "Info ›"), W - 31, top + 3, infoHover and theme.text() or theme.accent(), 0.6)
  U.hit(W - 34, top, 34, 12, function() renaming = false go("info") C.loadMembers() end)
  top = top + 12

  -- Поле ввода (с полосой «ответ / правка» над ним).
  local bottom = H - INPUT_H - 4
  local barH = 0
  if replyTo or editing then
    barH = 14
    local by = bottom - barH
    gfx.rect(0, by, W, barH, theme.card())
    gfx.rect(4, by + 2, 1, 10, theme.accent())
    local label = editing and tr("Изменение сообщения", "Editing message")
        or (tr("Ответ ", "Reply to ") .. replyTo.from .. ": " .. (replyTo.sticker ~= "" and tr("[Стикер]", "[Sticker]") or replyTo.text:gsub("\n", " ")))
    gfx.text(U.ellipsize(label, W - 26, 0.6), 8, by + 4, theme.secondary(), 0.6)
    gfx.text("×", W - 11, by + 2, theme.secondary(), 1)
    U.hit(W - 16, by, 16, barH, function()
      if editing then ui.setText("msg", "") end
      replyTo, editing = nil, nil
    end)
  end
  local text = ui.input("msg", 3, H - INPUT_H - 2, W - 24, INPUT_H, tr("Сообщение", "Message"))
  if text ~= lastInput then
    lastInput = text
    if text ~= "" and not editing then C.typingNow(chatId) end
  end
  local canSend = text:find("%S") ~= nil
  local sx = W - 19
  gfx.roundRect(sx, H - INPUT_H - 2, 16, INPUT_H, 3, canSend and theme.accent() or theme.card())
  gfx.textCenter(editing and "✔" or "➤", sx + 8, H - INPUT_H + 2, canSend and theme.onAccent() or theme.secondary(), 0.8)
  U.hit(sx, H - INPUT_H - 2, 16, INPUT_H, function() submitMessage(ui.getText("msg")) end)
  parkInputs(used)

  -- Сообщения снизу вверх.
  local areaTop, areaBottom = top, bottom - barH - 2
  local m = C.messages(chatId)
  local maxW = math.floor(W * 0.78)
  local group = chat.type == "group"
  local items = {}
  local prevDay
  for _, msg in ipairs(m.list) do
    local day = U.dayOf(msg.at)
    if day ~= prevDay then
      items[#items + 1] = {day = day, h = 14}
      prevDay = day
    end
    local lay = layoutOf(msg, maxW, group)
    items[#items + 1] = {msg = msg, lay = lay, h = lay.h + 3}
  end
  for _, p in ipairs(C.pendingFor(chatId)) do
    local fake = {id = 0, chat = chatId, from = C.name, text = p.text, at = p.at, edited = 0, deleted = false, fwd = "",
      sticker = p.sticker or "", reply = nil}
    local lay = measure(fake, maxW, group)
    items[#items + 1] = {msg = fake, lay = lay, h = lay.h + 3, pending = true}
  end
  local total = 4
  for _, it in ipairs(items) do total = total + it.h end
  local viewH = areaBottom - areaTop
  local maxScroll = math.max(0, total - viewH)
  scroll.chat = math.min(scroll.chat or 0, maxScroll)
  -- у верха — подгрузить старые
  if m.loaded and m.more and not m.loading and scroll.chat >= maxScroll - 10 then C.older(chatId) end
  gfx.clip(0, areaTop, W, viewH)
  local y = areaBottom - total + scroll.chat + 2
  if total < viewH then y = areaTop + 2 end
  if not m.loaded then
    gfx.textCenter(tr("Загрузка…", "Loading…"), W / 2, areaTop + viewH / 2 - 4, theme.secondary(), 0.7)
  elseif #items == 0 then
    gfx.textCenter(tr("Сообщений пока нет", "No messages yet"), W / 2, areaTop + viewH / 2 - 4, theme.secondary(), 0.7)
  end
  if m.loading and m.loaded then
    gfx.textCenter("…", W / 2, y - 8, theme.secondary(), 0.7)
  end
  for _, it in ipairs(items) do
    if y + it.h > areaTop and y < areaBottom then
      if it.day then
        local label = U.dayTitle(it.day)
        local lw = gfx.textWidth(label, 0.55) + 10
        gfx.roundRect(W / 2 - lw / 2, y + 2, lw, 10, 4, 0x40000000)
        gfx.textCenter(label, W / 2, y + 4, theme.secondary(), 0.55)
      else
        drawBubble(it.msg, it.lay, y, maxW, it.pending)
        if not it.pending then
          local msg = it.msg
          local bx = it.lay.mine and (W - 4 - it.lay.w) or 4
          local hy = math.max(y, areaTop)
          local hh = math.min(y + it.lay.h, areaBottom) - hy
          if hh > 0 then
            U.hit(bx, hy, it.lay.w, hh, function() end, function() messageMenu(msg) end)
          end
        end
      end
    end
    y = y + it.h
  end
  gfx.unclip()
  if scroll.chat > 40 then
    -- кнопка «вниз»
    local bx, by = W - 20, areaBottom - 20
    gfx.circle(bx + 8, by + 8, 8, theme.card())
    gfx.textCenter("↓", bx + 8, by + 4, theme.accent(), 0.8)
    if (chat.unread or 0) > 0 then U.badge(chat.unread, bx + 16, by - 5) end
    U.hit(bx, by, 16, 16, function() scroll.chat = 0 end)
  end
end

-- Сведения о чате
local function drawInfo()
  local chat = C.chats[chatId]
  if not chat then screen_ = "chats" stack = {} return end
  screen.title(tr("Сведения", "Info"))
  local used = {}
  local y = 8 - (scroll.info or 0)
  local title = C.title(chat)
  U.avatar(title, W / 2 - 16, y, 32, chat.type == "direct" and C.online[title], chat.type == "group")
  y = y + 36
  gfx.textCenter(U.ellipsize(title, W - 10, 0.9), W / 2, y, theme.text(), 0.9)
  y = y + 11
  local sub = chat.type == "direct" and (C.online[title] and tr("в сети", "online") or tr("не в сети", "offline"))
      or (chat.main and tr("Общий чат клана", "Clan chat") or (#chat.members .. tr(" участников", " members")))
  gfx.textCenter(sub, W / 2, y, theme.secondary(), 0.6)
  y = y + 12
  local canRename = chat.type == "group" and (chat.owner == C.name or (chat.main and C.isAdmin()))
  if renaming then
    used.rename = true
    ui.input("rename", 8, y, W - 16, 15, tr("Новое название", "New title"))
    y = y + 18
    U.button(8, y, (W - 20) / 2, 15, tr("Отмена", "Cancel"), "normal", function() renaming = false end)
    U.button(12 + (W - 20) / 2, y, (W - 20) / 2, 15, tr("Сохранить", "Save"), "primary", function() onSubmit("rename", ui.getText("rename")) end)
    y = y + 20
  else
    local bw = W - 16
    U.button(8, y, bw, 15, C.isMuted(chat.id) and tr("Включить звук", "Unmute") or tr("Без звука", "Mute"), "normal",
        function() C.toggleMute(chat.id) end)
    y = y + 18
    if canRename then
      U.button(8, y, bw, 15, tr("Переименовать", "Rename"), "normal", function()
        renaming = true
        ui.setText("rename", chat.title)
        ui.focus("rename")
      end)
      y = y + 18
    end
    if chat.type == "group" and not chat.main then
      U.button(8, y, bw, 15, tr("Добавить участников", "Add members"), "normal", function()
        newGroup, picked, addTo = true, {}, chat.id
        go("new")
        C.loadMembers()
      end)
      y = y + 18
    end
  end
  parkInputs(used)
  if chat.type == "group" then
    gfx.text(tr("Участники", "Members"), 8, y + 2, theme.secondary(), 0.6)
    y = y + 12
    for _, name in ipairs(chat.members) do
      local ROW = 20
      if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
      U.avatar(name, 8, y + 2, 16, C.online[name])
      gfx.text(U.ellipsize(name, W - 70, 0.7), 30, y + 4, theme.text(), 0.7)
      gfx.text(C.online[name] and tr("в сети", "online") or tr("не в сети", "offline"), 30, y + 12,
          C.online[name] and theme.accent() or theme.secondary(), 0.5)
      if name == chat.owner and not chat.main then
        local s = tr("владелец", "owner")
        gfx.text(s, W - 8 - gfx.textWidth(s, 0.55), y + 7, theme.secondary(), 0.55)
      end
      local target = name
      U.hit(0, y, W, ROW, function()
        if target == C.name then return end
        C.api("direct", {name = target}, function(ok, data)
          if ok then
            C.chats[data.chat.id] = C.chats[data.chat.id] or data.chat
            openChat(data.chat.id)
          else
            fail(data.error)
          end
        end)
      end, function()
        if chat.owner ~= C.name or target == C.name or chat.main then return end
        local mx, my = input.mouse()
        U.openMenu(mx, my, {{tr("Исключить из группы", "Remove from group"), function()
          C.api("groupAction", {chat = chat.id, action = "remove", users = {target}}, function(ok, data) if not ok then fail(data.error) end end)
        end, true}})
      end)
      y = y + ROW
    end
    if not chat.main then
      y = y + 6
      U.button(8, y, W - 16, 15, tr("Выйти из группы", "Leave group"), "danger", function()
        U.confirm(tr("Выйти из группы?", "Leave group?"), title, tr("Выйти", "Leave"), true, function()
          C.api("groupAction", {chat = chat.id, action = "leave"}, function(ok, data) if not ok then fail(data.error) end end)
        end)
      end)
      y = y + 20
    end
  end
  local content = y + (scroll.info or 0)
  scroll.info = math.min(scroll.info or 0, math.max(0, content - H))
end

-- Новый чат / новая группа / добавить участников
local function drawNew()
  screen.title(addTo and tr("Добавить", "Add") or (newGroup and tr("Новая группа", "New group") or tr("Новый чат", "New chat")))
  local used = {}
  local y = 4
  if not addTo then
    local bw = (W - 12) / 2
    U.button(4, y, bw, 14, tr("Личный чат", "Direct"), newGroup and "normal" or "primary", function() newGroup = false end)
    U.button(8 + bw, y, bw, 14, tr("Группа", "Group"), newGroup and "primary" or "normal", function() newGroup = true end)
    y = y + 18
  end
  if newGroup and not addTo then
    used.title = true
    ui.input("title", 4, y, W - 8, 15, tr("Название группы", "Group title"))
    y = y + 19
  end
  parkInputs(used)
  local count = 0
  for _ in pairs(picked) do count = count + 1 end
  local footer = newGroup and 22 or 0
  local top, bottom = y, H - footer
  local members = {}
  local existing = {}
  if addTo and C.chats[addTo] then
    for _, n in ipairs(C.chats[addTo].members) do existing[n] = true end
  end
  for _, mem in ipairs(C.members or {}) do
    if mem.name ~= C.name and not existing[mem.name] then members[#members + 1] = mem end
  end
  local ROW = 22
  local off = listArea("new", top, bottom, #members * ROW)
  gfx.clip(0, top, W, bottom - top)
  y = top - off
  if not C.members then
    gfx.textCenter(tr("Загрузка…", "Loading…"), W / 2, top + 20, theme.secondary(), 0.7)
  elseif #members == 0 then
    gfx.textCenter(tr("Больше никого нет", "Nobody else"), W / 2, top + 20, theme.secondary(), 0.7)
  end
  for _, mem in ipairs(members) do
    if y + ROW > top and y < bottom then
      if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
      U.avatar(mem.name, 6, y + 3, 16, C.online[mem.name])
      gfx.text(U.ellipsize(mem.name, W - 50, 0.72), 28, y + 4, theme.text(), 0.72)
      gfx.text(C.online[mem.name] and tr("в сети", "online") or tr("не в сети", "offline"), 28, y + 13,
          C.online[mem.name] and theme.accent() or theme.secondary(), 0.5)
      if newGroup then
        local on = picked[mem.name]
        gfx.circle(W - 13, y + 11, 6, on and theme.accent() or 0x40FFFFFF)
        if not on then gfx.circle(W - 13, y + 11, 5, theme.background()) else gfx.textCenter("✔", W - 13, y + 8, theme.onAccent(), 0.6) end
      end
      local name = mem.name
      U.hit(0, math.max(y, top), W, ROW, function()
        if newGroup then
          picked[name] = not picked[name] or nil
        else
          C.api("direct", {name = name}, function(ok, data)
            if ok then
              C.chats[data.chat.id] = C.chats[data.chat.id] or data.chat
              openChat(data.chat.id)
            else
              fail(data.error)
            end
          end)
        end
      end)
    end
    y = y + ROW
  end
  gfx.unclip()
  if newGroup then
    local label = addTo and (tr("Добавить", "Add") .. " (" .. count .. ")") or (tr("Создать группу", "Create group") .. " (" .. count + 1 .. ")")
    U.button(4, H - 19, W - 8, 16, label, count > 0 and "primary" or "normal", function()
      if count == 0 then return end
      local names = {}
      for n in pairs(picked) do names[#names + 1] = n end
      if addTo then
        local id = addTo
        C.api("groupAction", {chat = id, action = "add", users = names}, function(ok, data)
          if ok then back() else fail(data.error) end
        end)
        return
      end
      local title = ui.getText("title"):gsub("^%s+", ""):gsub("%s+$", "")
      if title == "" then fail("bad_title") ui.focus("title") return end
      C.api("group", {title = title, members = names}, function(ok, data)
        if ok then
          C.chats[data.chat.id] = data.chat
          ui.setText("title", "")
          openChat(data.chat.id)
        else
          fail(data.error)
        end
      end)
    end)
  end
end

-- Выбор чата (переслать)
local function drawPick()
  screen.title(tr("Переслать в…", "Forward to…"))
  parkInputs({})
  local list = C.chatList()
  local ROW = 24
  local off = listArea("pick", 0, H, #list * ROW)
  local y = -off
  for _, chat in ipairs(list) do
    if y + ROW > 0 and y < H then
      if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
      local title = C.title(chat)
      U.avatar(title, 6, y + 3, 18, false, chat.type == "group")
      gfx.text(U.ellipsize((chat.main and "★ " or "") .. title, W - 36, 0.75), 30, y + 8, theme.text(), 0.75)
      local id = chat.id
      U.hit(0, y, W, ROW, function()
        local fn = pickAction
        pickAction = nil
        back()
        if fn then fn(id) end
      end)
    end
    y = y + ROW
  end
end

-- Вкладка «Клан»: о клане, приглашения, участники
local ROLE_NAMES = {[0] = {"участник", "member"}, [1] = {"админ", "admin"}, [2] = {"глава", "leader"}}

local function roleName(r)
  local n = ROLE_NAMES[r] or ROLE_NAMES[0]
  return tr(n[1], n[2])
end

local function memberMenu(mem)
  local items = {}
  local name = mem.name
  if name ~= C.name then
    items[#items + 1] = {tr("Написать", "Message"), function()
      C.api("direct", {name = name}, function(ok, data)
        if ok then
          C.chats[data.chat.id] = C.chats[data.chat.id] or data.chat
          openChat(data.chat.id)
        else
          fail(data.error)
        end
      end)
    end}
  end
  if C.isAdmin() and (mem.role < C.role or name == C.name) then
    items[#items + 1] = {tr("Код «вернуть вход»", "Restore code"), function()
      C.api("invite", {name = name}, function(ok, data)
        if ok then
          data.name = name
          invite = data
          scroll.clan = 0
        else
          fail(data.error)
        end
      end)
    end}
  end
  if C.role == C.ROLE_OWNER and name ~= C.name then
    if mem.role == C.ROLE_ADMIN then
      items[#items + 1] = {tr("Снять админа", "Remove admin"), function()
        C.api("member", {name = name, action = "member"}, function(ok, data) if ok then C.loadMembers() else fail(data.error) end end)
      end}
    else
      items[#items + 1] = {tr("Сделать админом", "Make admin"), function()
        C.api("member", {name = name, action = "admin"}, function(ok, data) if ok then C.loadMembers() else fail(data.error) end end)
      end}
    end
    items[#items + 1] = {tr("Передать главенство", "Make leader"), function()
      U.confirm(tr("Передать главенство?", "Transfer leadership?"), name .. tr(" станет главой клана, вы — админом.", " becomes the leader, you become an admin."),
          tr("Передать", "Transfer"), true, function()
            C.api("member", {name = name, action = "owner"}, function(ok, data) if ok then C.loadMembers() else fail(data.error) end end)
          end)
    end, true}
  end
  if C.isAdmin() and mem.role < C.role and name ~= C.name then
    items[#items + 1] = {tr("Исключить из клана", "Remove from clan"), function()
      U.confirm(tr("Исключить из клана?", "Remove from clan?"), name, tr("Исключить", "Remove"), true, function()
        C.api("member", {name = name, action = "kick"}, function(ok, data) if ok then C.loadMembers() else fail(data.error) end end)
      end)
    end, true}
  end
  if #items > 0 then
    local mx, my = input.mouse()
    U.openMenu(mx, my, items)
  end
end

local function drawClan()
  screen.title(C.clan)
  parkInputs({})
  local top = statusLine(0)
  local bottom = H - TAB_H
  local off = scroll.clan or 0
  gfx.clip(0, top, W, bottom - top)
  local y = top + 6 - off
  gfx.circle(W / 2, y + 14, 14, 0xFF7A3FD1)
  gfx.textCenter("✦", W / 2, y + 9, 0xFFFFFFFF, 1.2)
  y = y + 32
  gfx.textCenter(C.clan, W / 2, y, theme.text(), 0.9)
  y = y + 11
  gfx.textCenter(C.name .. " · " .. roleName(C.role), W / 2, y, theme.secondary(), 0.6)
  y = y + 12
  if C.status ~= "online" then
    U.button(8, y, W - 16, 15, tr("Переподключиться", "Reconnect"), "normal", function()
      C.loaded = false
      C.status = "offline"
      C.start()
    end)
    y = y + 18
  end
  if C.status == "removed" or C.lastError == "unauthorized" then
    U.button(8, y, W - 16, 15, tr("Войти с новым кодом", "Join with a new code"), "primary", function()
      C.logout()
      root()
    end)
    y = y + 18
  end
  if C.isAdmin() then
    U.button(8, y, W - 16, 15, tr("Пригласить в клан", "Invite to clan"), "primary", function()
      C.api("invite", {uses = 1, hours = 24}, function(ok, data)
        if ok then invite = data else fail(data.error) end
      end)
    end)
    y = y + 18
  end
  if invite then
    local ch = 44
    gfx.roundRect(8, y, W - 16, ch, 4, theme.card())
    gfx.border(8, y, W - 16, ch, theme.accent())
    local head = invite.name and (tr("Вернуть вход: ", "Restore: ") .. invite.name) or tr("Код приглашения", "Invite code")
    gfx.text(U.ellipsize(head, W - 30, 0.55), 13, y + 3, theme.secondary(), 0.55)
    gfx.textCenter(invite.code, W / 2, y + 12, theme.accent(), 1.3)
    gfx.text(tr("1 вход, до ", "1 use, until ") .. U.shortTime(invite.expires) .. " " .. U.clock(invite.expires), 13, y + 26, theme.secondary(), 0.5)
    U.button(W - 58, y + 25, 46, 14, tr("Копировать", "Copy"), "normal", function()
      clipboard.set(invite.code)
      toast(tr("Код скопирован", "Code copied"))
    end)
    y = y + ch + 6
  end
  local members = C.members or {}
  local online = 0
  for _, mem in ipairs(members) do if mem.online or C.online[mem.name] then online = online + 1 end end
  gfx.text(tr("Участники: ", "Members: ") .. #members .. tr(", в сети: ", ", online: ") .. online, 8, y + 2, theme.secondary(), 0.6)
  y = y + 12
  if not C.members then
    gfx.textCenter(tr("Загрузка…", "Loading…"), W / 2, y + 6, theme.secondary(), 0.7)
    y = y + 20
  end
  local ROW = 22
  for _, mem in ipairs(members) do
    if y + ROW > top and y < bottom then
      local on = C.online[mem.name] or mem.online
      if not U.blocked() and ui.hovered(0, y, W, ROW) then gfx.rect(0, y, W, ROW, 0x18FFFFFF) end
      U.avatar(mem.name, 8, y + 3, 16, on)
      gfx.text(U.ellipsize(mem.name .. (mem.name == C.name and tr(" (вы)", " (you)") or ""), W - 80, 0.72), 30, y + 4, theme.text(), 0.72)
      gfx.text(on and tr("в сети", "online") or (tr("в клане с ", "since ") .. U.date(mem.joined)), 30, y + 13,
          on and theme.accent() or theme.secondary(), 0.5)
      if mem.role > 0 then
        local r = roleName(mem.role)
        gfx.text(r, W - 8 - gfx.textWidth(r, 0.55), y + 8, mem.role == 2 and 0xFFD4A72C or theme.accent(), 0.55)
      end
      local m = mem
      local hy = math.max(y, top)
      U.hit(0, hy, W, math.min(y + ROW, bottom) - hy, function() memberMenu(m) end, function() memberMenu(m) end)
    end
    y = y + ROW
  end
  y = y + 8
  U.button(8, y, W - 16, 15, tr("Выйти из аккаунта", "Log out"), "danger", function()
    U.confirm(tr("Выйти из аккаунта?", "Log out?"),
        tr("На этом компьютере. Войти снова — с кодом «вернуть вход» от админа.", "On this computer. To come back you'll need a restore code from an admin."),
        tr("Выйти", "Log out"), true, function()
          C.logout()
          root()
        end)
  end)
  y = y + 22
  gfx.unclip()
  local content = y + off - top
  scroll.clan = math.min(off, math.max(0, content - (bottom - top)))
  tabs()
end

local DRAW = {join = drawJoin, chats = drawChats, clan = drawClan, chat = drawChat, info = drawInfo, new = drawNew, pick = drawPick}

function onDraw(dt)
  W, H = screen.width(), screen.height()
  U.beginFrame()
  gfx.clear(theme.background())
  if not C.joined() and screen_ ~= "join" then
    stack = {}
    screen_ = "join"
  end
  DRAW[screen_]()
  U.drawOverlays(W, H)
end
