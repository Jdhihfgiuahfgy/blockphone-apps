-- Общие куски интерфейса: кнопки и строки с нажатием, меню, диалог, аватары, время, перенос текста.
-- Нажатия записываются при рисовании (U.hit) и разбираются в onClick — так кнопки и строки списков работают одинаково.

local U = {}

U.hits = {}
U.menu = nil      -- {x, y, items = {{label, fn, danger}}, strip = {icons = {имя}, fn = function(имя), chosen}}
U.dialog = nil    -- {title, text, label, danger, fn}

local L = app.lang == "ru_ru"

-- Перевод: строка RU или EN по языку телефона.
function U.tr(ru, en)
  return (L or not en) and ru or en
end

function U.beginFrame()
  U.hits = {}
end

-- Область нажатия: fn — левая кнопка, rfn — правая (необязательно).
function U.hit(x, y, w, h, fn, rfn)
  U.hits[#U.hits + 1] = {x, y, w, h, fn, rfn}
end

local function inside(px, py, x, y, w, h)
  return px >= x and py >= y and px < x + w and py < y + h
end

function U.click(x, y, button)
  if U.dialog then
    local d = U.dialog
    if d.cancel and inside(x, y, d.cancel[1], d.cancel[2], d.cancel[3], d.cancel[4]) then
      U.dialog = nil
    elseif d.ok and inside(x, y, d.ok[1], d.ok[2], d.ok[3], d.ok[4]) then
      U.dialog = nil
      d.fn()
    end
    return
  end
  if U.menu then
    local m = U.menu
    if m.stripBox and inside(x, y, m.stripBox[1], m.stripBox[2], m.stripBox[3], m.stripBox[4]) then
      local index = math.floor((x - m.stripBox[1] - 2) / 16) + 1
      local name = m.strip.icons[index]
      U.menu = nil
      if name then m.strip.fn(name) end
      return
    end
    if m.box and inside(x, y, m.box[1], m.box[2], m.box[3], m.box[4]) then
      local index = math.floor((y - m.box[2] - 2) / 14) + 1
      local item = m.items[index]
      U.menu = nil
      if item then item[2]() end
    else
      U.menu = nil
    end
    return
  end
  for i = #U.hits, 1, -1 do
    local h = U.hits[i]
    if inside(x, y, h[1], h[2], h[3], h[4]) then
      if button == 2 and h[6] then h[6]() return end
      if button == 1 and h[5] then h[5]() return end
      if h[5] or h[6] then return end
    end
  end
end

function U.blocked()
  return U.dialog ~= nil or U.menu ~= nil
end

-- ---------- Рисование ----------

function U.button(x, y, w, h, label, style, fn)
  local hover = not U.blocked() and ui.hovered(x, y, w, h)
  local bg, fg
  if style == "primary" then
    bg, fg = theme.accent(), theme.onAccent()
  elseif style == "danger" then
    bg, fg = hover and 0xFFC94A43 or 0xFFB8403A, 0xFFFFFFFF
  else
    bg, fg = theme.card(), theme.text()
  end
  gfx.roundRect(x, y, w, h, 3, bg)
  if hover and style ~= "danger" then gfx.roundRect(x, y, w, h, 3, 0x18FFFFFF) end
  if style ~= "primary" and style ~= "danger" then
    gfx.border(x, y, w, h, hover and theme.accent() or 0x30FFFFFF)
  elseif hover then
    gfx.border(x, y, w, h, 0x60FFFFFF)
  end
  gfx.textCenter(U.ellipsize(label, w - 4, 0.7), x + w / 2, y + h / 2 - 3, fg, 0.7)
  U.hit(x, y, w, h, fn)
end

function U.ellipsize(s, maxW, scale)
  if gfx.textWidth(s, scale) <= maxW then return s end
  local dots = "…"
  local n = #s
  while n > 0 do
    -- не резать букву UTF-8 посередине
    n = n - 1
    while n > 0 and s:byte(n + 1) and s:byte(n + 1) >= 0x80 and s:byte(n + 1) < 0xC0 do n = n - 1 end
    local cut = s:sub(1, n) .. dots
    if gfx.textWidth(cut, scale) <= maxW then return cut end
  end
  return dots
end

local AVATAR_COLORS = {0xFF5E81AC, 0xFFBF616A, 0xFFA3BE8C, 0xFFD08770, 0xFFB48EAD, 0xFF88C0D0, 0xFF7A3FD1, 0xFFD4A72C}

local function hash(s)
  local h = 7
  for i = 1, #s do h = (h * 31 + s:byte(i)) % 1000003 end
  return h
end

-- Первая буква (UTF-8) в верхнем регистре.
function U.initial(s)
  if s == nil or s == "" then return "?" end
  local b = s:byte(1)
  local len = b >= 0xF0 and 4 or b >= 0xE0 and 3 or b >= 0xC0 and 2 or 1
  local ch = s:sub(1, len)
  if len == 1 then return ch:upper() end
  -- кириллица: строчные а–я (D0 B0–D0 BF, D1 80–D1 8F) → прописные
  local b2 = ch:byte(2)
  if b == 0xD0 and b2 >= 0xB0 and b2 <= 0xBF then return string.char(0xD0, b2 - 0x20) end
  if b == 0xD1 and b2 >= 0x80 and b2 <= 0x8F then return string.char(0xD0, b2 + 0x20) end
  return ch
end

-- Аватар: круг цвета по имени с первой буквой; dot — точка «в сети».
function U.avatar(name, x, y, size, dot, square)
  local color = AVATAR_COLORS[hash(name or "?") % #AVATAR_COLORS + 1]
  if square then
    gfx.roundRect(x, y, size, size, size / 4, color)
  else
    gfx.circle(x + size / 2, y + size / 2, size / 2, color)
  end
  local scale = size >= 22 and 1 or 0.75
  gfx.textCenter(U.initial(name), x + size / 2, y + size / 2 - 3.5 * scale, 0xFFFFFFFF, scale, true)
  if dot then
    local d = math.max(4, math.floor(size / 4))
    gfx.circle(x + size - d / 2, y + size - d / 2, d / 2 + 1, theme.background())
    gfx.circle(x + size - d / 2, y + size - d / 2, d / 2, 0xFF3FB950)
  end
end

function U.badge(n, right, y)
  local s = n > 99 and "99+" or tostring(n)
  local w = math.max(9, gfx.textWidth(s, 0.55) + 5)
  gfx.roundRect(right - w, y, w, 9, 4, theme.accent())
  gfx.textCenter(s, right - w / 2, y + 2, theme.onAccent(), 0.55)
  return w
end

-- ---------- Меню и диалог ----------

-- strip (необязательно) — полоса картинок над меню (реакции): {icons = {"heart", ...}, fn = function(имя), chosen = имя}.
function U.openMenu(x, y, items, strip)
  U.menu = {x = x, y = y, items = items, strip = strip}
end

function U.confirm(title, text, label, danger, fn)
  U.dialog = {title = title, text = text, label = label, danger = danger, fn = fn}
end

function U.drawOverlays(w, h)
  if U.menu then
    local m = U.menu
    local mw = 10
    for _, it in ipairs(m.items) do mw = math.max(mw, gfx.textWidth(it[1], 0.7) + 14) end
    local mh = #m.items * 14 + 4
    local sw = m.strip and (#m.strip.icons * 16 + 4) or 0
    local top = m.strip and 21 or 0
    mw = math.max(mw, sw)
    local x = math.min(m.x, w - mw - 2)
    local y = math.min(m.y, h - mh - 2)
    x, y = math.max(2, x), math.max(2 + top, y)
    m.box = {x, y, mw, mh}
    if m.strip then
      local sx, sy = x, y - top
      m.stripBox = {sx, sy, sw, 18}
      gfx.roundRect(sx - 1, sy - 1, sw + 2, 20, 6, 0x60000000)
      gfx.roundRect(sx, sy, sw, 18, 6, theme.card())
      gfx.border(sx, sy, sw, 18, 0x30FFFFFF)
      for i, name in ipairs(m.strip.icons) do
        local ix = sx + 2 + (i - 1) * 16
        if name == m.strip.chosen then gfx.roundRect(ix, sy + 1, 16, 16, 4, theme.accent()) end
        if ui.hovered(ix, sy + 1, 16, 16) then gfx.roundRect(ix, sy + 1, 16, 16, 4, 0x30FFFFFF) end
        pcall(gfx.image, "reactions/" .. name .. ".png", ix + 2, sy + 3, 12, 12)
      end
    end
    gfx.roundRect(x - 1, y - 1, mw + 2, mh + 2, 4, 0x60000000)
    gfx.roundRect(x, y, mw, mh, 3, theme.card())
    gfx.border(x, y, mw, mh, 0x30FFFFFF)
    for i, it in ipairs(m.items) do
      local iy = y + 2 + (i - 1) * 14
      if ui.hovered(x, iy, mw, 14) then gfx.rect(x + 1, iy, mw - 2, 14, 0x20FFFFFF) end
      gfx.text(it[1], x + 7, iy + 3, it[3] and theme.danger() or theme.text(), 0.7)
    end
  end
  if U.dialog then
    local d = U.dialog
    gfx.rect(0, 0, w, h, 0x99000000)
    local dw = math.min(140, w - 16)
    local lines = gfx.wrap(d.text or "", dw - 16, 0.7)
    local dh = 8 + 12 + #lines * 8 + 8 + 16 + 8
    local x, y = math.floor((w - dw) / 2), math.floor((h - dh) / 2)
    gfx.roundRect(x, y, dw, dh, 4, theme.card())
    gfx.border(x, y, dw, dh, 0x40FFFFFF)
    gfx.rect(x + 2, y + 1, dw - 4, 1, theme.accent())
    gfx.textCenter(U.ellipsize(d.title, dw - 10, 0.85), x + dw / 2, y + 8, theme.text(), 0.85)
    for i, line in ipairs(lines) do
      gfx.textCenter(line, x + dw / 2, y + 20 + (i - 1) * 8, theme.secondary(), 0.7)
    end
    local by = y + dh - 24
    local bw = math.floor((dw - 20) / 2)
    d.cancel = {x + 8, by, bw, 16}
    d.ok = {x + 12 + bw, by, bw, 16}
    local saved = U.dialog
    U.dialog = nil -- кнопки диалога сами себя подсвечивают
    U.drawButtonOnly(x + 8, by, bw, 16, U.tr("Отмена", "Cancel"), "normal")
    U.drawButtonOnly(x + 12 + bw, by, bw, 16, d.label, d.danger and "danger" or "primary")
    U.dialog = saved
  end
end

function U.drawButtonOnly(x, y, w, h, label, style)
  local before = #U.hits
  U.button(x, y, w, h, label, style, nil)
  U.hits[before + 1] = nil
end

-- ---------- Время ----------

-- Сдвиг часового пояса (минуты): по местному времени телефона и UTC из time.now().
local function daysFromCivil(y, m, d)
  y = m <= 2 and y - 1 or y
  local era = math.floor(y / 400)
  local yoe = y - era * 400
  local mp = (m + 9) % 12
  local doy = math.floor((153 * mp + 2) / 5) + d - 1
  local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
  return era * 146097 + doe - 719468
end

local function civilFromDays(z)
  z = z + 719468
  local era = math.floor(z / 146097)
  local doe = z - era * 146097
  local yoe = math.floor((doe - math.floor(doe / 1460) + math.floor(doe / 36524) - math.floor(doe / 146096)) / 365)
  local y = yoe + era * 400
  local doy = doe - (365 * yoe + math.floor(yoe / 4) - math.floor(yoe / 100))
  local mp = math.floor((5 * doy + 2) / 153)
  local d = doy - math.floor((153 * mp + 2) / 5) + 1
  local m = mp < 10 and mp + 3 or mp - 9
  return m <= 2 and y + 1 or y, m, d
end

local offsetMin
local function offset()
  if offsetMin then return offsetMin end
  local s = time.date("yyyy-MM-dd HH:mm")
  local y, mo, d, hh, mm = s:match("(%d+)-(%d+)-(%d+) (%d+):(%d+)")
  local localMin = daysFromCivil(tonumber(y), tonumber(mo), tonumber(d)) * 1440 + tonumber(hh) * 60 + tonumber(mm)
  local utcMin = math.floor(time.now() / 60000)
  offsetMin = math.floor((localMin - utcMin) / 15 + 0.5) * 15
  return offsetMin
end

-- Местные день (число дней с 1970) и минуты дня.
local function localParts(ms)
  local total = math.floor(ms / 60000) + offset()
  return math.floor(total / 1440), total % 1440
end

function U.dayOf(ms)
  local day = localParts(ms)
  return day
end

function U.clock(ms)
  local _, minutes = localParts(ms)
  return string.format("%02d:%02d", math.floor(minutes / 60), minutes % 60)
end

-- Время в списке чатов: сегодня — часы, иначе — дата.
function U.shortTime(ms)
  if not ms or ms == 0 then return "" end
  local day = localParts(ms)
  local today = localParts(time.now())
  if day == today then return U.clock(ms) end
  local _, m, d = civilFromDays(day)
  return string.format("%02d.%02d", d, m)
end

local MONTHS_RU = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"}
local MONTHS_EN = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}

function U.dayTitle(day)
  local today = localParts(time.now())
  if day == today then return U.tr("Сегодня", "Today") end
  if day == today - 1 then return U.tr("Вчера", "Yesterday") end
  local y, m, d = civilFromDays(day)
  local ty = civilFromDays(today)
  local name = L and (d .. " " .. MONTHS_RU[m]) or (MONTHS_EN[m] .. " " .. d)
  return y == ty and name or (name .. " " .. y)
end

function U.date(ms)
  local day = localParts(ms)
  local y, m, d = civilFromDays(day)
  return string.format("%02d.%02d.%d", d, m, y)
end

-- ---------- Перенос текста с кэшем ----------

local wrapCache = {}
local wrapCount = 0

function U.wrap(text, width, scale)
  local key = width .. "|" .. scale .. "|" .. text
  local lines = wrapCache[key]
  if not lines then
    if wrapCount > 600 then wrapCache, wrapCount = {}, 0 end
    lines = {}
    for paragraph in (text .. "\n"):gmatch("([^\n]*)\n") do
      if paragraph == "" then
        lines[#lines + 1] = ""
      else
        for _, l in ipairs(gfx.wrap(paragraph, width, scale)) do lines[#lines + 1] = l end
      end
    end
    wrapCache[key] = lines
    wrapCount = wrapCount + 1
  end
  return lines
end

return U
