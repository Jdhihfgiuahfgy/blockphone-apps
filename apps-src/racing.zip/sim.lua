-- Логика гонки (без рисования): машинки, трасса, боты, круги, места. Считает ведущий 20 раз в секунду,
-- остальным уходит S.encode(game), они показывают то же самое (S.decode) с плавным движением между снимками.
-- Мир — метры: 320 × 180, дорога шириной 15 м, машинка 4,5 × 2,5 м.
local Tracks = require("tracks")

local S = {}
S.CARS = 4
S.MAX_LAPS = 9
S.COLORS = {"#E53935", "#1E88E5", "#FDD835", "#43A047"}
S.UP, S.DOWN, S.LEFT, S.RIGHT = 1, 2, 4, 8
S.W, S.H = 320, 180
S.HALF, S.CURB = 7.5, 1.5
S.PHASES = {"lobby", "countdown", "race", "results"}
local TPS = 20

function S.has(bits, flag)
  return math.floor(bits / flag) % 2 == 1
end

local function wrap(a)
  while a > math.pi do a = a - 2 * math.pi end
  while a < -math.pi do a = a + 2 * math.pi end
  return a
end
S.wrap = wrap

-- Трасса: точки средней линии, длина, предметы по клеткам 10 м (для столкновений).
local prepared = {}
function S.track(i)
  if prepared[i] then return prepared[i] end
  local src = Tracks[i]
  local t = {src = src, xs = {}, ys = {}, cum = {0}, n = 0, cells = {}}
  local L = src.line
  for k = 1, #L, 2 do
    t.n = t.n + 1
    t.xs[t.n], t.ys[t.n] = L[k], L[k + 1]
  end
  for k = 1, t.n do
    local j = k % t.n + 1
    local dx, dy = t.xs[j] - t.xs[k], t.ys[j] - t.ys[k]
    t.cum[k + 1] = t.cum[k] + math.sqrt(dx * dx + dy * dy)
  end
  t.length = t.cum[t.n + 1]
  for _, p in ipairs(src.props) do
    local r = (p[3] == 1 and 2.0 or (p[3] == 0 and 1.1 or 0.9)) * p[4]
    local key = math.floor(p[1] / 10) * 100 + math.floor(p[2] / 10)
    t.cells[key] = t.cells[key] or {}
    table.insert(t.cells[key], {p[1], p[2], r})
  end
  prepared[i] = t
  return t
end

local function segDist(t, i, x, y)
  local j = i % t.n + 1
  local ax, ay = t.xs[i], t.ys[i]
  local bx, by = t.xs[j] - ax, t.ys[j] - ay
  local l2 = bx * bx + by * by
  local u = l2 > 0 and ((x - ax) * bx + (y - ay) * by) / l2 or 0
  if u < 0 then u = 0 elseif u > 1 then u = 1 end
  local dx, dy = ax + bx * u - x, ay + by * u - y
  return dx * dx + dy * dy, u
end

-- Где точка относительно трассы: расстояние до средней линии, отрезок, путь от старта.
-- hint — отрезок прошлого такта (ищем рядом), без него — по всей трассе.
function S.locate(t, x, y, hint)
  local best, bi, bu = math.huge, 1, 0
  if hint then
    for k = -10, 10 do
      local i = (hint - 1 + k) % t.n + 1
      local d, u = segDist(t, i, x, y)
      if d < best then best, bi, bu = d, i, u end
    end
  end
  if not hint or best > 400 then
    for i = 1, t.n do
      local d, u = segDist(t, i, x, y)
      if d < best then best, bi, bu = d, i, u end
    end
  end
  return math.sqrt(best), bi, t.cum[bi] + (t.cum[bi + 1] - t.cum[bi]) * bu
end

-- Точка средней линии на пути s: x, y, направление.
function S.pointAt(t, s)
  s = s % t.length
  local lo, hi = 1, t.n + 1
  while hi - lo > 1 do
    local mid = math.floor((lo + hi) / 2)
    if t.cum[mid] <= s then lo = mid else hi = mid end
  end
  local j = lo % t.n + 1
  local seg = t.cum[lo + 1] - t.cum[lo]
  local u = seg > 0 and (s - t.cum[lo]) / seg or 0
  local x = t.xs[lo] + (t.xs[j] - t.xs[lo]) * u
  local y = t.ys[lo] + (t.ys[j] - t.ys[lo]) * u
  return x, y, math.atan2(t.ys[j] - t.ys[lo], t.xs[j] - t.xs[lo])
end

local function solid(t, x, y)
  if x < 1.5 or y < 1.5 or x > S.W - 1.5 or y > S.H - 1.5 then return true end
  local cx, cy = math.floor(x / 10), math.floor(y / 10)
  for ox = -1, 1 do
    for oy = -1, 1 do
      local list = t.cells[(cx + ox) * 100 + cy + oy]
      if list then
        for _, p in ipairs(list) do
          local dx, dy = p[1] - x, p[2] - y
          if dx * dx + dy * dy < p[3] * p[3] then return true end
        end
      end
    end
  end
  return false
end

-- --- Игра ---

local G = {}
G.__index = G

function S.new(trackIndex, laps, bots)
  local g = setmetatable({}, G)
  g.ti = math.max(1, math.min(#Tracks, trackIndex))
  g.t = S.track(g.ti)
  g.laps = math.max(1, math.min(S.MAX_LAPS, laps))
  g.bots = math.max(0, math.min(S.CARS, bots))
  g.phase, g.timer, g.tick, g.finished, g.firstFinish = "lobby", 0, 0, 0, 0
  g.prevAt, g.curAt = 0, 0
  g.cars = {}
  for i = 1, S.CARS do
    g.cars[i] = {present = false, driver = "", ready = false, lap = 0, rank = i, done = false, x = 0, y = 0, a = 0,
                 vx = 0, vy = 0, px = 0, py = 0, pa = 0, quarter = 3, s = 0, input = 0, seen = 0, skill = 1, lane = 0,
                 stuck = 0, reverse = 0, finishOrder = 0, speed = 0, seg = nil}
  end
  g:toLobby()
  return g
end

function G:carOf(name)
  for _, c in ipairs(self.cars) do
    if c.present and c.driver ~= "" and c.driver:lower() == name:lower() then return c end
  end
  return nil
end

function G:humans()
  local n = 0
  for _, c in ipairs(self.cars) do
    if c.present and c.driver ~= "" then n = n + 1 end
  end
  return n
end

-- Кнопки игрока (биты UP/DOWN/LEFT/RIGHT; −1 — вышел). Новый игрок садится в лобби или на отсчёте.
function G:input(name, bits, now)
  local c = self:carOf(name)
  if bits < 0 then
    if c then self:leave(c) end
    return
  end
  if not c then
    if self.phase ~= "lobby" and self.phase ~= "countdown" then return end
    c = self:join(name)
    if not c then return end
  end
  c.input, c.seen = bits, now
  if self.phase == "lobby" and S.has(bits, S.UP) then c.ready = true end
end

function G:join(name)
  local slot
  for _, c in ipairs(self.cars) do
    if not c.present then slot = c break end
  end
  if not slot then
    for _, c in ipairs(self.cars) do
      if c.driver == "" then slot = c break end
    end
  end
  if not slot then return nil end
  slot.present, slot.driver, slot.ready, slot.skill = true, name:sub(1, 16), false, 1
  self:fillBots()
  return slot
end

function G:leave(c)
  c.driver, c.ready, c.input = "", false, 0
  if self.phase == "lobby" or self.phase == "countdown" then
    c.present = false
    self:fillBots()
  else
    c.skill = 0.9 -- доедет ботом
  end
end

function G:fillBots()
  local want = math.min(self.bots, S.CARS - self:humans())
  for _, c in ipairs(self.cars) do
    if not (c.present and c.driver ~= "") then
      c.present = want > 0
      c.driver = ""
      want = want - 1
    end
  end
  self:grid()
end

function G:toLobby()
  self.phase, self.timer, self.finished, self.firstFinish = "lobby", 0, 0, 0
  for _, c in ipairs(self.cars) do
    c.ready, c.done, c.finishOrder = false, false, 0
  end
  self:fillBots()
end

-- Машинки на старте: за линией по две в ряд.
function G:grid()
  for i, c in ipairs(self.cars) do
    local x, y, a = S.pointAt(self.t, self.t.length - 7 - math.floor((i - 1) / 2) * 8)
    local side = (i % 2 == 1) and -3 or 3
    c.x, c.y, c.a = x - math.sin(a) * side, y + math.cos(a) * side, a
    c.px, c.py, c.pa = c.x, c.y, c.a
    c.vx, c.vy, c.speed, c.lap, c.quarter = 0, 0, 0, 0, 3
    c.s, c.stuck, c.reverse, c.rank, c.seg = self.t.length - 7, 0, 0, i, nil
  end
end

-- Такт ведущего.
function G:step(now)
  self.tick = self.tick + 1
  for _, c in ipairs(self.cars) do
    c.px, c.py, c.pa = c.x, c.y, c.a
  end
  self.prevAt = self.curAt == 0 and now - 50 or self.curAt
  self.curAt = now
  for _, c in ipairs(self.cars) do
    if c.present and c.driver ~= "" and now - c.seen > 8000 then self:leave(c) end
  end
  local humans, allReady = false, true
  for _, c in ipairs(self.cars) do
    if c.present and c.driver ~= "" then
      humans = true
      allReady = allReady and c.ready
    end
  end
  if self.phase == "lobby" then
    if humans and allReady then
      self.phase, self.timer = "countdown", 3 * TPS
      for _, c in ipairs(self.cars) do
        c.skill = c.driver == "" and (0.84 + math.random() * 0.1) or 1
        c.lane = (math.random() - 0.5) * 5
      end
    end
  elseif self.phase == "countdown" then
    if not humans then
      self:toLobby()
    else
      self.timer = self.timer - 1
      if self.timer <= 0 then self.phase, self.timer = "race", 0 end
    end
  elseif self.phase == "race" then
    self.timer = self.timer + 1
    self:race()
    local anyHuman, humansDone = false, true
    for _, c in ipairs(self.cars) do
      if c.present and c.driver ~= "" then
        anyHuman = true
        humansDone = humansDone and c.done
      end
    end
    local late = self.firstFinish > 0 and self.tick - self.firstFinish > 20 * TPS
    if not anyHuman or humansDone or late or self.timer > 6 * 60 * TPS then
      self.phase, self.timer = "results", 8 * TPS
    end
  elseif self.phase == "results" then
    self.timer = self.timer - 1
    if self.timer <= 0 then self:toLobby() end
  end
end

function G:race()
  for _, c in ipairs(self.cars) do
    if c.present then
      local bits = (c.driver == "" or c.done) and self:bot(c) or c.input
      self:drive(c, bits)
    end
  end
  self:collide()
  for _, c in ipairs(self.cars) do
    if c.present then self:progress(c) end
  end
  self:rank()
end

function G:drive(c, bits)
  local ca, sa = math.cos(c.a), math.sin(c.a)
  local fv = c.vx * ca + c.vy * sa
  local lv = -c.vx * sa + c.vy * ca
  local d
  d, c.seg = S.locate(self.t, c.x, c.y, (self.tick % 20 ~= 0) and c.seg or nil)
  local road = d <= S.HALF + S.CURB
  local max = (road and 1.85 or 0.8) * c.skill
  if S.has(bits, S.UP) and fv < max then fv = math.min(max, fv + (road and 0.1 or 0.06)) end
  if S.has(bits, S.DOWN) then
    fv = fv - (fv > 0 and 0.15 or 0.06)
    if fv < -0.6 then fv = -0.6 end
  end
  if not S.has(bits, S.UP) and not S.has(bits, S.DOWN) then fv = fv * 0.97 end
  if fv > max then fv = max + (fv - max) * (road and 0.9 or 0.75) end
  local turn = (S.has(bits, S.RIGHT) and 1 or 0) - (S.has(bits, S.LEFT) and 1 or 0)
  local grip = math.min(1, math.abs(fv) / 0.6) * (fv >= 0 and 1 or -1)
  c.a = wrap(c.a + turn * 0.085 * grip)
  lv = lv * (road and 0.6 or 0.75) -- занос: боковая скорость гаснет не сразу
  ca, sa = math.cos(c.a), math.sin(c.a)
  c.vx, c.vy = fv * ca - lv * sa, fv * sa + lv * ca
  local nx, ny = c.x + c.vx, c.y + c.vy
  if solid(self.t, nx, ny) then
    c.vx, c.vy = c.vx * -0.4, c.vy * -0.4
  else
    c.x, c.y = nx, ny
  end
  c.speed = math.sqrt(c.vx * c.vx + c.vy * c.vy)
end

function G:bot(c)
  if c.reverse > 0 then
    c.reverse = c.reverse - 1
    return S.DOWN + (c.lane > 0 and S.LEFT or S.RIGHT)
  end
  if c.done then c.skill = 0.6 end
  local tx, ty, ta = S.pointAt(self.t, c.s + 8 + c.speed * 7)
  tx, ty = tx - math.sin(ta) * c.lane, ty + math.cos(ta) * c.lane
  local d = wrap(math.atan2(ty - c.y, tx - c.x) - c.a)
  local bits = S.UP
  if d < -0.06 then bits = bits + S.LEFT elseif d > 0.06 then bits = bits + S.RIGHT end
  if math.abs(d) > 0.7 and c.speed > 1.0 then bits = bits - S.UP end
  if c.speed < 0.15 then
    c.stuck = c.stuck + 1
    if c.stuck > 30 then c.stuck, c.reverse = 0, 15 end
  else
    c.stuck = 0
  end
  return bits
end

function G:collide()
  local cars = self.cars
  for i = 1, S.CARS do
    for j = i + 1, S.CARS do
      local a, b = cars[i], cars[j]
      if a.present and b.present then
        local dx, dy = b.x - a.x, b.y - a.y
        local d2 = dx * dx + dy * dy
        if d2 < 12.25 and d2 > 1e-4 then
          local d = math.sqrt(d2)
          local nx, ny, push = dx / d, dy / d, (3.5 - d) / 2
          if not solid(self.t, a.x - nx * push, a.y - ny * push) then a.x, a.y = a.x - nx * push, a.y - ny * push end
          if not solid(self.t, b.x + nx * push, b.y + ny * push) then b.x, b.y = b.x + nx * push, b.y + ny * push end
          local va, vb = a.vx * nx + a.vy * ny, b.vx * nx + b.vy * ny
          if va - vb > 0 then
            local e = (va - vb) * 0.85
            a.vx, a.vy = a.vx - nx * e, a.vy - ny * e
            b.vx, b.vy = b.vx + nx * e, b.vy + ny * e
          end
        end
      end
    end
  end
end

-- Круги: трасса поделена на четверти, засчитывается только проезд по порядку (срезать нельзя, назад — минус круг).
function G:progress(c)
  local _, seg, s = S.locate(self.t, c.x, c.y, c.seg)
  c.seg, c.s = seg, s
  local q = math.min(3, math.floor(s / self.t.length * 4))
  if q == (c.quarter + 1) % 4 then
    if q == 0 then
      c.lap = c.lap + 1
      if c.lap > self.laps and not c.done then
        self.finished = self.finished + 1
        c.done, c.finishOrder = true, self.finished
        if self.firstFinish == 0 then self.firstFinish = self.tick end
      end
    end
    c.quarter = q
  elseif q == (c.quarter + 3) % 4 then
    if c.quarter == 0 then c.lap = c.lap - 1 end
    c.quarter = q
  end
end

function G:rank()
  local list = {}
  for _, c in ipairs(self.cars) do
    if c.present then table.insert(list, c) end
  end
  local L = self.t.length
  table.sort(list, function(a, b)
    local ka = a.done and (1e6 - a.finishOrder) or (a.lap * L + a.s)
    local kb = b.done and (1e6 - b.finishOrder) or (b.lap * L + b.s)
    return ka > kb
  end)
  for i, c in ipairs(list) do c.rank = i end
end

-- --- Передача состояния ---

function G:encode()
  local cars = {}
  for i, c in ipairs(self.cars) do
    if c.present then
      cars[i] = {c.driver, math.floor(c.x * 20 + 0.5), math.floor(c.y * 20 + 0.5), math.floor(c.a * 1000 + 0.5), c.lap, c.rank,
                 (c.done and 1 or 0) + (c.ready and 2 or 0)}
    else
      cars[i] = 0
    end
  end
  return {ti = self.ti, laps = self.laps, bots = self.bots, ph = self.phase, tm = self.timer, c = cars}
end

function G:decode(o, now)
  if type(o) ~= "table" or type(o.c) ~= "table" then return false end
  for i = 1, S.CARS do
    local c, d = self.cars[i], o.c[i]
    local was = c.present
    c.present = type(d) == "table"
    if c.present then
      local x, y, a = (tonumber(d[2]) or 0) / 20, (tonumber(d[3]) or 0) / 20, (tonumber(d[4]) or 0) / 1000
      local jump = not was or math.abs(x - c.x) + math.abs(y - c.y) > 25
      c.px, c.py, c.pa = jump and x or c.x, jump and y or c.y, jump and a or c.a
      c.x, c.y, c.a = x, y, a
      c.driver = tostring(d[1] or ""):sub(1, 16)
      c.lap, c.rank = tonumber(d[5]) or 0, tonumber(d[6]) or i
      local f = tonumber(d[7]) or 0
      c.done, c.ready = f % 2 == 1, math.floor(f / 2) % 2 == 1
    end
  end
  self.phase = (o.ph == "countdown" or o.ph == "race" or o.ph == "results") and o.ph or "lobby"
  self.timer = tonumber(o.tm) or 0
  self.prevAt = self.curAt == 0 and now - 100 or self.curAt
  self.curAt = now
  return true
end

-- Положение машинки i в момент now (плавно между тактами/снимками): x, y, угол.
function G:pose(i, now)
  local c = self.cars[i]
  local span = math.max(40, self.curAt - self.prevAt)
  local t = math.max(0, math.min(1, (now - self.curAt) / span))
  return c.px + (c.x - c.px) * t, c.py + (c.y - c.py) * t, c.pa + wrap(c.a - c.pa) * t
end

-- Скорость по снимкам (работает и у гостя), км/ч.
function G:kmh(i)
  local c = self.cars[i]
  local ticks = math.max(1, (self.curAt - self.prevAt) / 50)
  local dx, dy = c.x - c.px, c.y - c.py
  return math.floor(math.sqrt(dx * dx + dy * dy) / ticks * 72 + 0.5)
end

function G:countdown()
  return self.phase == "countdown" and math.ceil(self.timer / TPS) or 0
end

return S
