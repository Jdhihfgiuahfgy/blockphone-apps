-- Браузер: настоящий Chromium (разрешение "browser"). Адресная строка, назад/вперёд/обновить, домашняя страница с
-- закладками, режим «на весь экран набок» для видео. Клики, колесо и клавиши по странице телефон передаёт сам.

local tab = nil
local full = false
local home = "https://www.google.com"
local BAR = 20

local QUICK = {
  {"Google", "https://www.google.com"},
  {"YouTube", "https://www.youtube.com"},
  {"Википедия", "https://ru.wikipedia.org"},
  {"Minecraft Wiki", "https://minecraft.wiki"},
  {"GitHub", "https://github.com"},
  {"Яндекс", "https://ya.ru"},
}

local function ru()
  return (app.lang or ""):sub(1, 2) == "ru"
end

local function T(r, e)
  return ru() and r or e
end

local function open(url)
  storage.set("last", url)
  if tab == nil then
    tab = web.open(url)
  else
    web.go(tab, url)
  end
end

function onStart()
  web.start()
  local last = storage.get("last", "")
  if last ~= "" then
    open(last)
  end
end

local function setFull(on)
  full = on
  screen.landscape(on)
  screen.fullscreen(on)
end

-- Состояние загрузки Chromium (первый запуск): полоса и подсказка.
local function drawStatus(w, h)
  local state, progress, err = web.status()
  if state == "ready" then
    return false
  end
  gfx.clear(theme.background())
  local text
  if state == "failed" then
    text = T("Не удалось запустить браузер:", "The browser failed to start:") .. "\n" .. err
  elseif state == "downloading" then
    text = T("Скачивание Chromium (~140 МБ, один раз)…", "Downloading Chromium (~140 MB, once)…")
  elseif state == "extracting" then
    text = T("Распаковка…", "Unpacking…")
  else
    text = T("Запуск браузера…", "Starting the browser…")
  end
  local lines = gfx.wrap(text, w - 24, 0.75)
  for i, line in ipairs(lines) do
    gfx.textCenter(line, w / 2, h / 2 - 20 + (i - 1) * 10, state == "failed" and theme.danger() or theme.text(), 0.75)
  end
  if progress and progress >= 0 and state ~= "failed" then
    gfx.roundRect(16, h / 2 + 10, w - 32, 6, 3, theme.card())
    gfx.roundRect(16, h / 2 + 10, math.max(6, (w - 32) * progress), 6, 3, theme.accent())
    gfx.textCenter(math.floor(progress * 100) .. "%", w / 2, h / 2 + 20, theme.secondary(), 0.6)
  end
  if state == "failed" and ui.button(w / 2 - 40, h / 2 + 30, 80, 18, T("Ещё раз", "Retry"), "primary") then
    web.start()
  end
  return true
end

-- Домашняя страница: закладки плитками.
local function drawHome(w, top, h)
  gfx.textCenter(T("Быстрый доступ", "Quick access"), w / 2, top + 10, theme.secondary(), 0.7)
  local cols = w > 260 and 3 or 2
  local cw = (w - 16 - (cols - 1) * 6) / cols
  for i, q in ipairs(QUICK) do
    local c = (i - 1) % cols
    local r = math.floor((i - 1) / cols)
    if ui.button(8 + c * (cw + 6), top + 24 + r * 24, cw, 20, q[1]) then
      open(q[2])
    end
  end
end

function onDraw()
  local w, h = screen.width(), screen.height()
  if drawStatus(w, h) then
    return
  end
  gfx.clear(theme.background())
  local top = full and 0 or BAR
  if not full then
    -- Панель: ‹ › ⟳ [адрес] ⤢
    local info = tab and web.info(tab) or {}
    if ui.button(2, 2, 16, 16, "‹", info.canBack and "normal" or "normal") and tab then
      web.back(tab)
    end
    if ui.button(19, 2, 16, 16, "›") and tab then
      web.forward(tab)
    end
    if ui.button(36, 2, 16, 16, info.loading and "×" or "⟳") and tab then
      if info.loading then web.stop(tab) else web.reload(tab) end
    end
    local text = ui.input("url", 54, 2, w - 54 - 38, 16, T("Адрес или поиск", "Address or search"))
    if not ui.focused("url") and tab and info.url and text ~= info.url then
      ui.setText("url", info.url)
    end
    if ui.button(w - 36, 2, 16, 16, "⌂") then
      if tab then web.close(tab) tab = nil end
      storage.set("last", "")
    end
    if ui.button(w - 19, 2, 16, 16, "⤢", "primary") then
      setFull(true)
    end
    if info.loading then
      gfx.rect(0, BAR - 1, w * 0.6, 1, theme.accent())
    end
  end
  if tab == nil then
    drawHome(w, top, h)
    return
  end
  web.draw(tab, 0, top, w, h - top)
  if full then
    -- Выход из полного экрана: маленькая кнопка в углу.
    if ui.button(w - 18, 2, 16, 16, "⤡") then
      setFull(false)
    end
  end
end

function onSubmit(id, text)
  if id == "url" and text ~= "" then
    open(text)
  end
end

function onBack()
  if full then
    setFull(false)
    return true
  end
  if tab then
    local info = web.info(tab)
    if info.canBack then
      web.back(tab)
      return true
    end
  end
  return false
end
