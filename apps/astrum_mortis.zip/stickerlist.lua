-- Создано tools/gen_clan_stickers.py — не править руками.
return {
  {pack = "basic", names = {"like", "heart", "fire", "star", "laugh", "sad", "angry", "cool", "wow", "gg", "ok", "lol"}},
  {pack = "clan", names = {"astrum", "skull", "crown", "sword", "raid", "go"}},
}
