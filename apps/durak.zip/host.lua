-- Хост: комната + вся логика партии. Один игрок (создатель комнаты) ведёт игру:
-- тасует колоду, проверяет ходы и рассылает каждому его «вид» состояния.
local rules = require("rules")

local H = {}
H.room = nil          -- {max, members = {имена}, started}
H.G = nil             -- текущая партия
H.localDeliver = nil  -- function(from, data): доставка сообщения самому хосту

---------------------------------------------------------------- утилиты

local seed = 12345
local function rnd(n)
  seed = (seed * 16807) % 2147483647
  return math.floor(seed / 2147483647 * n) + 1
end

local function shuffle(t)
  for i = #t, 2, -1 do
    local j = rnd(i)
    t[i], t[j] = t[j], t[i]
  end
end

local function me() return app.player end

local function send(name, data)
  if name == me() then
    if H.localDeliver then H.localDeliver(name, data) end
  else
    net.send(name, data)
  end
end

local function copy(list)
  local r = {}
  for i, v in ipairs(list) do r[i] = v end
  return r
end

local function indexOf(list, x)
  for i, v in ipairs(list) do
    if v == x then return i end
  end
  return nil
end

---------------------------------------------------------------- комната

local function infoMsg()
  return {t = "room", host = me(), n = #H.room.members, max = H.room.max}
end

function H.broadcastLobby(note)
  if not H.room then return end
  for _, name in ipairs(copy(H.room.members)) do
    send(name, {t = "lobby", host = me(), names = copy(H.room.members), max = H.room.max, note = note})
  end
end

function H.create(max)
  seed = (math.floor(time.now()) % 2147483646) + 1
  H.room = {max = max, members = {me()}, started = false}
  H.G = nil
  H.broadcastLobby()
  if net.online() then net.broadcast(infoMsg()) end
end

function H.close()
  if H.room then
    for _, name in ipairs(H.room.members) do
      if name ~= me() then send(name, {t = "closed"}) end
    end
  end
  H.room = nil
  H.G = nil
end

function H.toLobby()
  if not H.room then return end
  H.G = nil
  H.room.started = false
  H.broadcastLobby()
end

---------------------------------------------------------------- партия

local function nextActive(G, i)
  local n = #G.seats
  for k = 1, n do
    local j = (i - 1 + k) % n + 1
    if not G.out[j] then return j end
  end
  return i
end

local function startRound(G, att)
  G.att = att
  G.def = nextActive(G, att)
  G.table = {}
  G.taking = false
  G.passed = {}
  G.limit = math.min(6, #G.hands[G.def])
end

local function view(G, i)
  local seats = {}
  for k, name in ipairs(G.seats) do
    seats[k] = {n = name, c = #G.hands[k], o = G.out[k] and 1 or 0, p = G.passed[k] and 1 or 0}
  end
  local tbl = {}
  for k, p in ipairs(G.table) do tbl[k] = {a = p.a, d = p.d} end
  return {
    t = "state", gid = G.gid, seq = G.seq, you = i, hand = copy(G.hands[i]), seats = seats,
    deck = #G.deck, trump = G.trump, tc = (#G.deck > 0) and G.trumpCard or nil,
    table = tbl, att = G.att, def = G.def, taking = G.taking and 1 or 0, lim = G.limit,
    disc = G.discard, over = G.over and 1 or 0, durak = G.durak, log = G.log,
  }
end

local function pushAll(G)
  G.seq = G.seq + 1
  for i, name in ipairs(G.seats) do send(name, view(G, i)) end
end

local function startGame()
  seed = ((seed + math.floor(time.now())) % 2147483646) + 1
  local room = H.room
  room.started = true
  local G = {gid = math.floor(time.now()) % 1000000000, seq = 0, seats = copy(room.members)}
  shuffle(G.seats)
  G.hands, G.out = {}, {}
  local deck = {}
  for i = 0, 35 do deck[#deck + 1] = i end
  shuffle(deck)
  G.deck = deck
  G.trumpCard = deck[1]
  G.trump = rules.suit(deck[1])
  for i = 1, #G.seats do
    G.hands[i] = {}
    G.out[i] = false
    for _ = 1, 6 do G.hands[i][#G.hands[i] + 1] = table.remove(deck) end
  end
  local att, best = 1, 99
  for i = 1, #G.seats do
    for _, c in ipairs(G.hands[i]) do
      if rules.suit(c) == G.trump and rules.rank(c) < best then
        best = rules.rank(c)
        att = i
      end
    end
  end
  G.discard, G.over, G.durak = 0, false, ""
  H.G = G
  startRound(G, att)
  G.log = G.seats[att] .. " ходит первым"
  pushAll(G)
end

function H.start()
  local room = H.room
  if not room or #room.members < 2 then return end
  if room.started and not (H.G and H.G.over) then return end
  startGame()
end

-- Конец раунда: «бито» или защитник забирает карты
local function resolve(G)
  local def = G.def
  local taken = G.taking
  if taken then
    for _, p in ipairs(G.table) do
      G.hands[def][#G.hands[def] + 1] = p.a
      if p.d then G.hands[def][#G.hands[def] + 1] = p.d end
    end
    G.log = G.seats[def] .. " забрал карты"
  else
    G.discard = G.discard + 2 * #G.table
    G.log = "Бито"
  end

  -- добор: сначала атакующий и подкидывавшие по кругу, защитник последним
  local order, i = {}, G.att
  for _ = 1, #G.seats do
    if not G.out[i] and i ~= def then order[#order + 1] = i end
    i = i % #G.seats + 1
  end
  if not G.out[def] then order[#order + 1] = def end
  for _, k in ipairs(order) do
    local h = G.hands[k]
    while #h < 6 and #G.deck > 0 do h[#h + 1] = table.remove(G.deck) end
  end

  local alive, last = 0, nil
  for k = 1, #G.seats do
    if not G.out[k] and #G.hands[k] == 0 and #G.deck == 0 then G.out[k] = true end
    if not G.out[k] then
      alive = alive + 1
      last = k
    end
  end
  G.table = {}
  G.taking = false
  G.passed = {}
  if alive <= 1 then
    G.over = true
    G.durak = last and G.seats[last] or ""
    G.log = last and (G.seats[last] .. " — дурак") or "Ничья"
    return
  end

  local newAtt
  if taken then
    newAtt = nextActive(G, def)
  elseif not G.out[def] then
    newAtt = def
  else
    newAtt = nextActive(G, def)
  end
  startRound(G, newAtt)
end

local function allPassed(G)
  for i = 1, #G.seats do
    if i ~= G.def and not G.out[i] and not G.passed[i] and #G.hands[i] > 0 then
      return false
    end
  end
  return true
end

local function checkAuto(G)
  local n = #G.table
  if n == 0 then return end
  if G.taking then
    if n >= G.limit or allPassed(G) then resolve(G) end
  elseif rules.uncovered(G.table) == 0 then
    if n >= G.limit or #G.hands[G.def] == 0 or allPassed(G) then resolve(G) end
  end
end

local function doAct(G, i, d)
  local a = d.a
  if a == "atk" then
    local c = d.c
    if type(c) ~= "number" then return false, "Ошибка хода" end
    local pos = indexOf(G.hands[i], c)
    if not pos then return false, "Нет такой карты" end
    if i == G.def then return false, "Вы защищаетесь" end
    if #G.table == 0 and i ~= G.att then return false, "Первым ходит " .. G.seats[G.att] end
    if not rules.canThrow(G.table, c, G.limit, G.taking, #G.hands[G.def]) then
      return false, "Так ходить нельзя"
    end
    table.remove(G.hands[i], pos)
    G.table[#G.table + 1] = {a = c}
    G.passed = {}
    G.log = G.seats[i] .. (G.taking and " подкидывает" or " ходит")
  elseif a == "def" then
    if i ~= G.def or G.taking then return false, "Сейчас нельзя защищаться" end
    if type(d.c) ~= "number" or type(d.i) ~= "number" then return false, "Ошибка хода" end
    local p = G.table[d.i]
    if not p or p.d then return false, "Некуда бить" end
    local pos = indexOf(G.hands[i], d.c)
    if not pos then return false, "Нет такой карты" end
    if not rules.beats(p.a, d.c, G.trump) then return false, "Эта карта не бьёт" end
    table.remove(G.hands[i], pos)
    p.d = d.c
    G.passed = {}
    G.log = G.seats[i] .. " отбивается"
  elseif a == "take" then
    if i ~= G.def or G.taking then return false, "Сейчас нельзя" end
    if rules.uncovered(G.table) == 0 then return false, "Нечего брать" end
    G.taking = true
    G.passed = {}
    G.log = G.seats[i] .. " берёт"
  elseif a == "pass" then
    if i == G.def then return false, "Вы защищаетесь" end
    if #G.table == 0 then return false, "Сначала нужно сходить" end
    if not G.taking and rules.uncovered(G.table) > 0 then return false, "Ждите защиту" end
    G.passed[i] = true
  else
    return false, "Неизвестное действие"
  end
  checkAuto(G)
  return true
end

---------------------------------------------------------------- сообщения

local function seatOf(G, name)
  for i, n in ipairs(G.seats) do
    if n == name then return i end
  end
  return nil
end

function H.onMessage(from, d)
  local room = H.room
  if not room or type(d) ~= "table" then return end
  local t = d.t

  if t == "who" then
    if not room.started and #room.members < room.max then net.send(from, infoMsg()) end

  elseif t == "join" then
    if indexOf(room.members, from) then
      send(from, {t = "lobby", host = me(), names = copy(room.members), max = room.max})
    elseif room.started then
      send(from, {t = "deny", why = "Игра уже идёт"})
    elseif #room.members >= room.max then
      send(from, {t = "deny", why = "Комната заполнена"})
    else
      room.members[#room.members + 1] = from
      H.broadcastLobby()
    end

  elseif t == "leave" then
    local pos = indexOf(room.members, from)
    if not pos or from == me() then return end
    table.remove(room.members, pos)
    if room.started then
      H.G = nil
      room.started = false
      H.broadcastLobby(from .. " вышел — игра прервана")
    else
      H.broadcastLobby()
    end

  elseif t == "act" then
    local G = H.G
    if not G or G.over or d.gid ~= G.gid then return end
    local i = seatOf(G, from)
    if not i or G.out[i] then return end
    local ok, err = doAct(G, i, d)
    if ok then
      pushAll(G)
    else
      send(from, {t = "err", msg = err})
    end
  end
end

return H
