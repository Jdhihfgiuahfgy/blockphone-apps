-- Общие правила подкидного дурака (используются и хостом, и клиентом).
-- Карта — число 0..35: масть = floor(c / 9), достоинство = c % 9 (0 = шестёрка ... 8 = туз).
-- Масти: 0 пики, 1 червы, 2 бубны, 3 трефы.
local R = {}

R.RANKS = {"6", "7", "8", "9", "10", "В", "Д", "К", "Т"}

function R.suit(c) return math.floor(c / 9) end
function R.rank(c) return c % 9 end

-- Бьёт ли карта def карту att при козыре trump
function R.beats(att, def, trump)
  local sa, sd = R.suit(att), R.suit(def)
  if sa == sd then return R.rank(def) > R.rank(att) end
  return sd == trump
end

-- Сколько карт на столе ещё не побито
function R.uncovered(tbl)
  local n = 0
  for _, p in ipairs(tbl) do
    if not p.d then n = n + 1 end
  end
  return n
end

-- Можно ли сейчас выложить карту c в атаку/подкидывание.
-- lim — предельное число атакующих карт в раунде, taking — защитник уже берёт,
-- defCount — сколько карт сейчас у защитника.
function R.canThrow(tbl, c, lim, taking, defCount)
  if #tbl >= lim then return false end
  if #tbl == 0 then return true end
  local r = R.rank(c)
  local ok = false
  for _, p in ipairs(tbl) do
    if R.rank(p.a) == r or (p.d and R.rank(p.d) == r) then
      ok = true
    end
  end
  if not ok then return false end
  if not taking and R.uncovered(tbl) + 1 > defCount then return false end
  return true
end

return R
