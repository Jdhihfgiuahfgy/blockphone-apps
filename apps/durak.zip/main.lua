-- Дурак онлайн для BlockPhone. Подкидной дурак, 36 карт, 2-5 игроков.
local rules = require("rules")
local cards = require("cards")
local Host = require("host")

local BOT = 14          -- отступ снизу под кнопки «назад/домой» телефона (во весь экран)
local CW, CH = 22, 31   -- размер карты

local scr = "menu"      -- menu | find | room | game | help
local maxPlayers = 2
local rooms = {}        -- [ник хоста] = данные комнаты
local roomInfo = nil    -- текущая комната {host, names, max}
local joining = nil
local view = nil        -- последнее состояние партии от хоста
local joinSince, lastWho, lastPresence = 0, -100, 0
local isHost, confirmExit = false, false
local sel = nil         -- выбранная карта (для защиты, когда целей несколько)
local busyUntil = 0
local hits = {}
local miss = {}
local helpLines = nil
local listScroll = 0

local HELP = "Подкидной дурак, 36 карт (от шестёрки до туза), по 6 карт на руки. Козырь — масть нижней карты колоды.\n" ..
  "Атакующий ходит картой, защитник бьёт её старшей картой той же масти или любым козырем.\n" ..
  "Подкидывать можно карты тех достоинств, что уже лежат на столе (не больше 6 и не больше, чем карт у защитника).\n" ..
  "«Бито» — отбились, защитник ходит следующим. «Беру» — защитник забирает карты, ход переходит дальше.\n" ..
  "Кто первым избавился от карт — выиграл. Последний с картами — дурак."

---------------------------------------------------------------- помощники

local function int(n) return math.floor(tonumber(n) or 0) end

local function fit(s, maxw, scale)
  s = tostring(s)
  while #s > 1 and gfx.textWidth(s, scale) > maxw do s = s:sub(1, #s - 1) end
  return s
end

local function btn(x, y, w, h, label, style, enabled)
  if enabled == false then
    gfx.roundRect(x, y, w, h, 3, theme.card())
    gfx.textCenter(label, x + w / 2, y + (h - 7) / 2, theme.secondary(), 0.9)
    return false
  end
  return ui.button(x, y, w, h, label, style)
end

local function resetRoom()
  roomInfo, view, sel, joining = nil, nil, nil, nil
  isHost, confirmExit = false, false
  miss = {}
end

local function toMenu(msg)
  resetRoom()
  scr = "menu"
  if msg then toast(msg) end
end

local function leaveRoom()
  if isHost then
    Host.close()
  elseif roomInfo then
    net.send(roomInfo.host, {t = "leave"})
  end
  toMenu()
end

local function sendHost(d)
  if isHost then
    Host.onMessage(app.player, d)
  elseif roomInfo then
    net.send(roomInfo.host, d)
  end
end

local function sendAct(d)
  if time.clock() < busyUntil then return end
  busyUntil = time.clock() + 0.2
  d.t = "act"
  d.gid = view.gid
  sendHost(d)
end

local function createRoom()
  if not net.online() then
    toast("Нужен сервер с BlockPhone")
    return
  end
  isHost = true
  Host.create(maxPlayers)
end

local function joinRoom(host)
  joining = host
  joinSince = time.clock()
  net.send(host, {t = "join"})
end

---------------------------------------------------------------- сообщения

local function fromMyHost(from)
  return (roomInfo and roomInfo.host == from) or joining == from or (isHost and from == app.player)
end

function onMessage(from, d)
  if type(d) ~= "table" then return end
  local t = d.t
  if t == "who" or t == "join" or t == "leave" or t == "act" then
    if Host.room then Host.onMessage(from, d) end
  elseif t == "room" then
    if scr == "find" and d.host == from then
      d.seen = time.clock()
      rooms[from] = d
    end
  elseif t == "lobby" then
    if fromMyHost(from) then
      roomInfo = d
      joining = nil
      view, sel, confirmExit = nil, nil, false
      scr = "room"
      if d.note then toast(d.note) end
    end
  elseif t == "deny" then
    if joining == from then
      joining = nil
      toast(d.why or "Отказано")
    end
  elseif t == "closed" then
    if roomInfo and roomInfo.host == from and not isHost then toMenu("Комната закрыта") end
  elseif t == "err" then
    if roomInfo and roomInfo.host == from then toast(d.msg or "Так нельзя") end
  elseif t == "state" then
    if roomInfo and roomInfo.host == from then
      if view == nil or view.gid ~= d.gid then
        scr = "game"
        sel, confirmExit = nil, false
      elseif d.seq <= view.seq then
        return
      end
      view = d
      if sel then
        local has = false
        for _, c in ipairs(d.hand) do
          if c == sel then has = true end
        end
        if not has then sel = nil end
      end
    end
  end
end

Host.localDeliver = function(from, d) onMessage(from, d) end

local function checkPresence()
  if not net.online() or not roomInfo then return end
  net.players(function(names)
    if type(names) ~= "table" then return end
    local set = {}
    for _, n in pairs(names) do
      if type(n) == "table" then n = n.name end
      if n then set[n] = true end
    end
    local watch = {}
    if isHost and Host.room then
      for _, n in ipairs(Host.room.members) do
        if n ~= app.player then watch[#watch + 1] = n end
      end
    elseif roomInfo then
      watch[1] = roomInfo.host
    end
    for _, n in ipairs(watch) do
      if set[n] then
        miss[n] = 0
      else
        miss[n] = (miss[n] or 0) + 1
        if miss[n] >= 2 then
          miss[n] = nil
          if isHost then
            Host.onMessage(n, {t = "leave"})
          else
            toMenu("Хост отключился")
            return
          end
        end
      end
    end
  end)
end

---------------------------------------------------------------- экраны

local function drawMenu(W, Ht)
  gfx.clear(theme.background())
  local cx = W / 2
  local bw = 150
  local x = cx - bw / 2
  gfx.textCenter("Дурак онлайн", cx, 6, theme.text(), 1.6)
  gfx.textCenter("Вы: " .. app.player, cx, 24, theme.secondary(), 0.8)
  if btn(x, 38, bw, 18, "Создать комнату", "primary") then createRoom() end
  gfx.text("Мест в комнате:", x, 65, theme.text(), 0.8)
  local mx = x + bw - 54
  if btn(mx, 61, 16, 16, "-") then maxPlayers = math.max(2, maxPlayers - 1) end
  gfx.textCenter(tostring(maxPlayers), mx + 25, 65, theme.text(), 1)
  if btn(mx + 34, 61, 16, 16, "+") then maxPlayers = math.min(5, maxPlayers + 1) end
  if btn(x, 84, bw, 18, "Найти игру") then
    scr = "find"
    rooms = {}
    lastWho = -100
    listScroll = 0
  end
  if btn(x, 106, bw, 18, "Правила") then scr = "help" end
  if not net.online() then
    gfx.textCenter("Для игры нужен сервер с BlockPhone", cx, 128, theme.danger(), 0.7)
  end
end

local function drawFind(W, Ht)
  gfx.clear(theme.background())
  if btn(4, 4, 40, 14, "Назад") then scr = "menu" end
  gfx.textCenter("Комнаты", W / 2, 6, theme.text(), 1.2)
  if not net.online() then
    gfx.textCenter("Для игры нужен сервер с BlockPhone", W / 2, 40, theme.danger(), 0.9)
    return
  end
  local list = {}
  for _, r in pairs(rooms) do list[#list + 1] = r end
  table.sort(list, function(a, b) return a.host < b.host end)
  if #list == 0 then
    gfx.textCenter("Ищем комнаты…", W / 2, 50, theme.secondary(), 0.9)
    gfx.textCenter("Создайте свою или подождите", W / 2, 62, theme.secondary(), 0.7)
    return
  end
  local rowH, y0 = 26, 24
  local vis = math.max(1, math.floor((Ht - BOT - y0) / rowH))
  listScroll = math.max(0, math.min(listScroll, #list - vis))
  for i = 1, vis do
    local r = list[i + listScroll]
    if not r then break end
    local y = y0 + (i - 1) * rowH
    gfx.panel(8, y, W - 16, rowH - 3)
    gfx.text(fit("Комната: " .. r.host, W - 100, 0.9), 14, y + 4, theme.text(), 0.9)
    gfx.text(int(r.n) .. " / " .. int(r.max) .. " игроков", 14, y + 14, theme.secondary(), 0.7)
    if btn(W - 62, y + 2, 50, rowH - 7, "Войти", "primary", joining == nil) then joinRoom(r.host) end
  end
end

local function drawRoom(W, Ht)
  gfx.clear(theme.background())
  local cx = W / 2
  local bw = 150
  local x = cx - bw / 2
  gfx.textCenter(fit("Комната: " .. roomInfo.host, W - 20, 1.2), cx, 6, theme.text(), 1.2)
  local names = roomInfo.names or {}
  gfx.textCenter("Игроки: " .. #names .. " / " .. int(roomInfo.max), cx, 22, theme.secondary(), 0.8)
  for i, name in ipairs(names) do
    local label = name
    if name == roomInfo.host then label = label .. "  (хост)" end
    if name == app.player then label = label .. "  — вы" end
    gfx.text(label, x, 32 + (i - 1) * 11, theme.text(), 0.9)
  end
  local by = Ht - BOT - 18
  if isHost then
    if btn(x, by - 22, bw, 18, "Начать игру", "primary", #names >= 2) then Host.start() end
    if btn(x, by, bw, 18, "Закрыть комнату", "danger") then leaveRoom() end
  else
    gfx.textCenter("Ждём, пока хост начнёт игру…", cx, by - 14, theme.secondary(), 0.8)
    if btn(x, by, bw, 18, "Выйти") then leaveRoom() end
  end
end

local function drawHelp(W, Ht)
  gfx.clear(theme.background())
  if btn(4, 4, 40, 14, "Назад") then scr = "menu" end
  gfx.textCenter("Правила", W / 2, 6, theme.text(), 1.2)
  if not helpLines then helpLines = gfx.wrap(HELP, W - 20, 0.8) end
  for i, line in ipairs(helpLines) do
    gfx.text(line, 10, 22 + (i - 1) * 8, theme.text(), 0.8)
  end
end

local function roleOf(v, si)
  local s = v.seats[si]
  if int(s.o) == 1 then return "вышел", "#90A4AE" end
  if si == int(v.def) then
    if int(v.taking) == 1 then return "берёт", "#FF8A80" end
    return "защита", "#80D8FF"
  end
  if si == int(v.att) then return "атака", "#FFD54F" end
  if int(s.p) == 1 then return "пас", "#B0BEC5" end
  return "", "#FFFFFF"
end

local function handClick(c)
  local v = view
  local you = int(v.you)
  if int(v.seats[you].o) == 1 or int(v.over) == 1 then return end
  if you == int(v.def) then
    if int(v.taking) == 1 then
      toast("Вы берёте карты")
      return
    end
    if sel == c then
      sel = nil
      return
    end
    if rules.uncovered(v.table) == 0 then
      toast("Нечего бить")
      return
    end
    local targets = {}
    for i, p in ipairs(v.table) do
      if not p.d and rules.beats(p.a, c, int(v.trump)) then targets[#targets + 1] = i end
    end
    if #targets == 0 then
      toast("Эта карта не бьёт")
      sel = nil
    elseif #targets == 1 then
      sel = nil
      sendAct({a = "def", c = c, i = targets[1]})
    else
      sel = c
    end
  else
    if #v.table == 0 and you ~= int(v.att) then
      toast("Первым ходит " .. v.seats[int(v.att)].n)
      return
    end
    if not rules.canThrow(v.table, c, int(v.lim), int(v.taking) == 1, int(v.seats[int(v.def)].c)) then
      toast("Так ходить нельзя")
      return
    end
    sendAct({a = "atk", c = c})
  end
end

local function tableClick(ti)
  local v = view
  if not sel then return end
  local p = v.table[ti]
  if p and not p.d and rules.beats(p.a, sel, int(v.trump)) then
    local c = sel
    sel = nil
    sendAct({a = "def", c = c, i = ti})
  else
    toast("Не бьёт")
  end
end

local function drawGame(W, Ht)
  local v = view
  hits = {}
  gfx.clear("#1B5E3A")
  local n = #v.seats
  local you, def, att = int(v.you), int(v.def), int(v.att)
  local trump = int(v.trump)
  local taking = int(v.taking) == 1
  local over = int(v.over) == 1
  local meOut = int(v.seats[you].o) == 1
  local tbl = v.table
  local unc = rules.uncovered(tbl)
  local live = not confirmExit and not over

  -- соперники
  local others = {}
  for k = 1, n - 1 do others[k] = (you - 1 + k) % n + 1 end
  local slotW = math.floor((W - 8) / #others)
  for k, si in ipairs(others) do
    local s = v.seats[si]
    local x, w = 4 + (k - 1) * slotW, slotW - 4
    local role, rcol = roleOf(v, si)
    gfx.roundRect(x, 2, w, 31, 3, role ~= "" and rcol or "#2F7A52")
    gfx.roundRect(x + 1, 3, w - 2, 29, 3, "#14452C")
    gfx.text(fit(s.n, w - 26, 0.8), x + 3, 5, "#FFFFFF", 0.8)
    if role ~= "" then gfx.text(role, x + 3, 17, rcol, 0.7) end
    if int(s.o) == 0 then
      cards.back(x + w - 18, 8, 14, 20)
      gfx.textCenter(tostring(int(s.c)), x + w - 11, 15, "#FFFFFF", 0.8)
    end
  end

  -- статус
  local status
  if over then
    status = ""
  elseif meOut then
    status = "Вы вышли из игры — смотрите партию"
  elseif you == def then
    if taking then status = "Вы берёте карты"
    elseif unc > 0 then status = sel and "Выберите карту на столе" or "Побейте карты или нажмите «Беру»"
    elseif #tbl > 0 then status = "Ждём подкидывания"
    else status = "Ходит " .. v.seats[att].n end
  else
    if #tbl == 0 then
      status = (you == att) and "Ваш ход — выложите карту" or ("Ходит " .. v.seats[att].n)
    elseif taking then status = v.seats[def].n .. " берёт — можно подкинуть"
    elseif unc > 0 then status = "Ждём защиту"
    else status = "Подкидывайте или нажмите «Бито»" end
  end
  gfx.textCenter(fit(status, W - 10, 0.8), W / 2, 36, "#FFFFFF", 0.8)

  -- колода и козырь
  local tableY = 48
  local dx = 6
  if int(v.deck) > 0 then
    if v.tc then cards.face(int(v.tc), dx + 10, tableY + 6, CW, CH) end
    cards.back(dx, tableY, CW, CH)
    gfx.textCenter(tostring(int(v.deck)), dx + CW / 2, tableY + CH / 2 - 3, "#FFFFFF", 0.9)
  end
  gfx.roundRect(dx, tableY + CH + 8, 26, 14, 3, "#F4F1E8")
  cards.suit(trump, dx + 13, tableY + CH + 14, 3, cards.color(trump))

  -- стол
  local tx0 = dx + CW + 16
  local right = W - 68
  local spacing = math.min(CW + 8, math.floor((right - tx0 - CW - 6) / 5))
  for k, p in ipairs(tbl) do
    local ax = tx0 + (k - 1) * spacing
    if sel and not p.d and rules.beats(p.a, sel, trump) then
      gfx.roundRect(ax - 2, tableY - 2, CW + 4, CH + 4, 4, "#FFE066")
      hits[#hits + 1] = {x = ax, y = tableY, w = CW, h = CH, ti = k}
    end
    cards.face(int(p.a), ax, tableY, CW, CH)
    if p.d then cards.face(int(p.d), ax + 6, tableY + 8, CW, CH) end
  end

  -- кнопки
  local bx, bw = W - 64, 60
  if not over and not meOut then
    if you == def then
      if btn(bx, tableY, bw, 18, "Беру", "danger", live and not taking and unc > 0) then
        sendAct({a = "take"})
      end
    else
      local label = taking and "Пас" or "Бито"
      local passed = int(v.seats[you].p) == 1
      local can = live and #tbl > 0 and (taking or unc == 0) and not passed
      if btn(bx, tableY, bw, 18, passed and "Ждём…" or label, "primary", can) then
        sendAct({a = "pass"})
      end
    end
  end

  -- рука
  local hand = {}
  for i, c in ipairs(v.hand) do hand[i] = int(c) end
  table.sort(hand, function(a, b)
    local ka = (rules.suit(a) == trump and 1000 or 0) + rules.suit(a) * 10 + rules.rank(a)
    local kb = (rules.suit(b) == trump and 1000 or 0) + rules.suit(b) * 10 + rules.rank(b)
    return ka < kb
  end)
  local m = #hand
  local availW = W - 12
  local step = m > 1 and math.min(CW + 3, (availW - CW) / (m - 1)) or 0
  local x0 = (W - (step * (m - 1) + CW)) / 2
  local y = Ht - BOT - CH - 3
  for i, c in ipairs(hand) do
    local x = x0 + (i - 1) * step
    local w = (i < m) and step or CW
    local lift = 0
    if sel == c then lift = 8
    elseif live and ui.hovered(x, y - 8, w, CH + 8) then lift = 4 end
    cards.face(c, x, y - lift, CW, CH)
    hits[#hits + 1] = {x = x, y = y - 8, w = w, h = CH + 8, card = c}
  end

  -- конец партии
  if over then
    local cx, cy = W / 2, Ht / 2 - 6
    gfx.panel(cx - 90, cy - 34, 180, 68)
    local title
    if v.durak == "" then title = "Ничья!"
    elseif v.durak == app.player then title = "Вы остались в дураках"
    else title = "Дурак — " .. v.durak end
    gfx.textCenter(fit(title, 170, 1.1), cx, cy - 28, theme.text(), 1.1)
    if v.durak ~= app.player and v.durak ~= "" and not meOut then
      gfx.textCenter("Вы выиграли!", cx, cy - 14, "#2E9E5B", 0.9)
    end
    if isHost then
      if btn(cx - 85, cy + 2, 82, 18, "Ещё раз", "primary", not confirmExit) then Host.start() end
      if btn(cx + 3, cy + 2, 82, 18, "В комнату", "normal", not confirmExit) then Host.toLobby() end
    else
      gfx.textCenter("Ждём хоста…", cx, cy - 2, theme.secondary(), 0.7)
      if btn(cx - 41, cy + 10, 82, 18, "В комнату", "normal", not confirmExit) then scr = "room" end
    end
  end

  -- подтверждение выхода
  if confirmExit then
    local cx, cy = W / 2, Ht / 2 - 6
    gfx.panel(cx - 80, cy - 28, 160, 56)
    gfx.textCenter("Выйти из игры?", cx, cy - 20, theme.text(), 1)
    if btn(cx - 72, cy, 68, 18, "Выйти", "danger") then leaveRoom() end
    if btn(cx + 4, cy, 68, 18, "Остаться") then confirmExit = false end
  end
end

---------------------------------------------------------------- вызовы телефона

function onStart()
  screen.landscape(true)
  screen.fullscreen(true)
end

function onDraw(dt)
  local W, Ht = screen.width(), screen.height()
  if scr == "menu" then drawMenu(W, Ht)
  elseif scr == "find" then drawFind(W, Ht)
  elseif scr == "room" and roomInfo then drawRoom(W, Ht)
  elseif scr == "game" and view then drawGame(W, Ht)
  elseif scr == "help" then drawHelp(W, Ht)
  else scr = "menu" end
end

function onTick()
  local now = time.clock()
  if scr == "find" then
    if now - lastWho > 2.5 then
      lastWho = now
      if net.online() then net.broadcast({t = "who"}) end
    end
    for k, r in pairs(rooms) do
      if now - r.seen > 7 then rooms[k] = nil end
    end
  end
  if joining and joining ~= app.player and now - joinSince > 6 then
    joining = nil
    toast("Нет ответа от хоста")
  end
  if roomInfo and now - lastPresence > 5 then
    lastPresence = now
    checkPresence()
  end
end

function onClick(x, y, button)
  if scr ~= "game" or not view or confirmExit or int(view.over) == 1 then return end
  for i = #hits, 1, -1 do
    local h = hits[i]
    if x >= h.x and x < h.x + h.w and y >= h.y and y < h.y + h.h then
      if h.card then handClick(h.card) elseif h.ti then tableClick(h.ti) end
      return
    end
  end
  sel = nil
end

function onScroll(amount)
  if scr == "find" then
    listScroll = listScroll + (amount < 0 and 1 or -1)
  end
end

function onBack()
  if scr == "menu" then return false end
  if scr == "game" then
    if view and int(view.over) == 1 then
      scr = "room"
    else
      confirmExit = not confirmExit
    end
    return true
  end
  if scr == "room" then
    leaveRoom()
    return true
  end
  scr = "menu"
  return true
end
