-- Рисование карт и мастей из примитивов gfx (шрифт Minecraft может не знать ♠♥♦♣).
local rules = require("rules")

local C = {}

C.RED = "#C62828"
C.BLACK = "#202020"

function C.color(s)
  if s == 1 or s == 2 then return C.RED end
  return C.BLACK
end

local function diamond(cx, cy, half, col)
  gfx.push()
  gfx.translate(cx, cy)
  gfx.rotate(45)
  gfx.rect(-half, -half, half * 2, half * 2, col)
  gfx.pop()
end

-- Масть s в точке (cx, cy), u — «единица» размера (ширина значка ≈ 2u)
function C.suit(s, cx, cy, u, col)
  col = col or C.color(s)
  if s == 1 then          -- червы
    local y0 = cy - 0.25 * u
    gfx.circle(cx - 0.5 * u, y0 - 0.3 * u, 0.5 * u, col)
    gfx.circle(cx + 0.5 * u, y0 - 0.3 * u, 0.5 * u, col)
    diamond(cx, y0 + 0.5 * u, 0.57 * u, col)
  elseif s == 2 then      -- бубны
    diamond(cx, cy, 0.62 * u, col)
  elseif s == 0 then      -- пики
    local y0 = cy + 0.1 * u
    gfx.circle(cx - 0.5 * u, y0 + 0.3 * u, 0.5 * u, col)
    gfx.circle(cx + 0.5 * u, y0 + 0.3 * u, 0.5 * u, col)
    diamond(cx, y0 - 0.5 * u, 0.57 * u, col)
    gfx.rect(cx - 0.14 * u, y0 + 0.4 * u, 0.28 * u, 0.8 * u, col)
  else                    -- трефы
    gfx.circle(cx, cy - 0.5 * u, 0.48 * u, col)
    gfx.circle(cx - 0.5 * u, cy + 0.3 * u, 0.48 * u, col)
    gfx.circle(cx + 0.5 * u, cy + 0.3 * u, 0.48 * u, col)
    gfx.rect(cx - 0.14 * u, cy + 0.3 * u, 0.28 * u, 0.85 * u, col)
  end
end

function C.face(card, x, y, w, h)
  local s, r = rules.suit(card), rules.rank(card)
  local col = C.color(s)
  gfx.roundRect(x, y, w, h, 3, "#555555")
  gfx.roundRect(x + 1, y + 1, w - 2, h - 2, 3, "#F4F1E8")
  gfx.text(rules.RANKS[r + 1], x + 2, y + 2, col, 0.75)
  C.suit(s, x + 5, y + 14, 2.2, col)
  C.suit(s, x + w / 2 + 2, y + h * 0.64, 4.5, col)
end

function C.back(x, y, w, h)
  gfx.roundRect(x, y, w, h, 3, "#10264A")
  gfx.roundRect(x + 2, y + 2, w - 4, h - 4, 2, "#2B5BA8")
  gfx.circle(x + w / 2, y + h / 2, math.max(2, w / 5), "#8FB4F0")
end

return C
