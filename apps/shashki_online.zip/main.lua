-- Шашки онлайн для BlockPhone
-- Прототип русских шашек 8x8 с сетевым обменом через multiplayer API.
-- Один игрок создаёт комнату и является ведущим: хранит состояние партии
-- и проверяет ходы. Оба участника должны держать приложение открытым.

local W, H = 160, 290
local page = "menu"
local status = "Создай комнату или подключись к ведущему."
local roomCode = ""
local hostName = ""
local localPlayer = app.player or "Игрок"
local isHost = false
local hostSide = "white"
local mySide = nil
local board = {}
local turn = "white"
local selected = nil
local legalTargets = {}
local lobbyNames = {}
local roomPlayers = {}
local gameStarted = false
local gameOver = false
local winner = nil
local lastSync = 0
local tapCell = nil
local boardX, boardY, cell = 8, 48, 18
local pendingRoom = ""

local LIGHT = "#E8D7B5"
local DARK = "#815B3C"
local WHITE = "#F6F0E6"
local BLACK = "#24252B"
local GOLD = "#F2D37B"
local GREEN = "#176B45"
local RED = "#D74B4B"

local function notify(s)
  status = s or ""
  toast(status)
end

local function newBoard()
  local b = {}
  for y=1,8 do
    b[y]={}
    for x=1,8 do
      if (x+y)%2==0 and y<=3 then
        b[y][x]={side="black",king=false}
      elseif (x+y)%2==0 and y>=6 then
        b[y][x]={side="white",king=false}
      else
        b[y][x]=nil
      end
    end
  end
  return b
end

local function copyBoard(src)
  local dst={}
  for y=1,8 do
    dst[y]={}
    for x=1,8 do
      local p=src[y] and src[y][x]
      if p then dst[y][x]={side=p.side,king=p.king} else dst[y][x]=false end
    end
  end
  return dst
end

local function inBounds(x,y)
  return x>=1 and x<=8 and y>=1 and y<=8
end

local function pieceAt(x,y)
  if not inBounds(x,y) then return nil end
  return board[y] and board[y][x] or nil
end

local function isEnemy(a,b)
  return a and b and a.side~=b.side
end

local function dirsFor(p)
  if p.king then
    return {{1,1},{-1,1},{1,-1},{-1,-1}}
  elseif p.side=="white" then
    return {{1,-1},{-1,-1}}
  else
    return {{1,1},{-1,1}}
  end
end

local function capturesFrom(x,y)
  local p=pieceAt(x,y)
  local out={}
  if not p then return out end
  local dirs=dirsFor(p)
  if p.king then
    -- В русских шашках дамка бьёт по диагонали через одну фигуру,
    -- приземляясь на любую свободную клетку за ней.
    for _,d in ipairs(dirs) do
      local xx,yy=x+d[1],y+d[2]
      local found=false
      while inBounds(xx,yy) do
        local q=pieceAt(xx,yy)
        if q then
          if q.side==p.side or found then break end
          found=true
        elseif found then
          out[#out+1]={x=xx,y=yy,captureX=xx-d[1],captureY=yy-d[2]}
        end
        xx,yy=xx+d[1],yy+d[2]
      end
    end
  else
    for _,d in ipairs(dirs) do
      local mx,my=x+d[1],y+d[2]
      local tx,ty=x+2*d[1],y+2*d[2]
      if inBounds(tx,ty) and isEnemy(p,pieceAt(mx,my)) and not pieceAt(tx,ty) then
        out[#out+1]={x=tx,y=ty,captureX=mx,captureY=my}
      end
    end
  end
  return out
end

local function simpleFrom(x,y)
  local p=pieceAt(x,y)
  local out={}
  if not p then return out end
  for _,d in ipairs(dirsFor(p)) do
    if p.king then
      local xx,yy=x+d[1],y+d[2]
      while inBounds(xx,yy) and not pieceAt(xx,yy) do
        out[#out+1]={x=xx,y=yy}
        xx,yy=xx+d[1],yy+d[2]
      end
    else
      local xx,yy=x+d[1],y+d[2]
      if inBounds(xx,yy) and not pieceAt(xx,yy) then
        out[#out+1]={x=xx,y=yy}
      end
    end
  end
  return out
end

local function anyCapture(side)
  for y=1,8 do
    for x=1,8 do
      local p=pieceAt(x,y)
      if p and p.side==side and #capturesFrom(x,y)>0 then return true end
    end
  end
  return false
end

local function targetsFrom(x,y)
  if anyCapture(turn) then return capturesFrom(x,y) end
  return simpleFrom(x,y)
end

local function sideName(side)
  return side=="white" and "белые" or "чёрные"
end

local function countPieces(side)
  local n=0
  for y=1,8 do for x=1,8 do
    local p=pieceAt(x,y)
    if p and p.side==side then n=n+1 end
  end end
  return n
end

local function hasAnyMove(side)
  local old=turn
  turn=side
  for y=1,8 do for x=1,8 do
    local p=pieceAt(x,y)
    if p and p.side==side then
      if #targetsFrom(x,y)>0 then turn=old; return true end
    end
  end end
  turn=old
  return false
end

local function publicState()
  return {
    kind="state", room=roomCode, host=hostName, board=copyBoard(board),
    turn=turn, status=status, gameStarted=gameStarted, gameOver=gameOver,
    winner=winner, whiteName=roomPlayers.white, blackName=roomPlayers.black
  }
end

local function sendState()
  if not isHost then return end
  local s=publicState()
  local other = (mySide=="white" and roomPlayers.black) or roomPlayers.white
  if other and other~=localPlayer then net.send(other,s) end
end

local function beginGame()
  if not isHost then return end
  if not roomPlayers.white or not roomPlayers.black then
    notify("Нужны два игрока в комнате.")
    return
  end
  board=newBoard()
  turn="white"
  gameStarted=true
  gameOver=false
  winner=nil
  selected=nil
  page="game"
  mySide=(localPlayer==roomPlayers.white) and "white" or "black"
  status="Ход белых."
  sendState()
  if roomPlayers.white~=localPlayer then net.send(roomPlayers.white,{kind="private",side="white"}) end
  if roomPlayers.black~=localPlayer then net.send(roomPlayers.black,{kind="private",side="black"}) end
end

local function createRoom()
  isHost=true
  hostName=localPlayer
  roomCode=tostring(math.random(1000,9999))
  mySide="white"
  roomPlayers={white=localPlayer,black=nil}
  lobbyNames={localPlayer}
  page="lobby"
  notify("Комната "..roomCode.." создана. Сообщи код и свой ник.")
  net.broadcast({kind="hello",room=roomCode,host=hostName})
end

local function joinRoom()
  local code=ui.getText("room") or ""
  local host=ui.getText("host") or ""
  if code=="" or host=="" then notify("Введи код комнаты и ник ведущего."); return end
  isHost=false
  roomCode=code
  hostName=host
  page="lobby"
  net.send(hostName,{kind="join",room=roomCode,name=localPlayer})
  notify("Запрос отправлен ведущему.")
end

local function validMove(sx,sy,tx,ty)
  local p=pieceAt(sx,sy)
  if not p or p.side~=turn then return false end
  local ts=targetsFrom(sx,sy)
  for _,t in ipairs(ts) do
    if t.x==tx and t.y==ty then return true,t end
  end
  return false
end

local function applyMove(sx,sy,tx,ty,capX,capY)
  local ok,target=validMove(sx,sy,tx,ty)
  if not ok then return false,"Недопустимый ход." end
  local p=board[sy][sx]
  board[sy][sx]=nil
  board[ty][tx]=p
  if target.captureX then
    board[target.captureY][target.captureX]=nil
  end
  if p.side=="white" and ty==1 then p.king=true end
  if p.side=="black" and ty==8 then p.king=true end
  if target.captureX and #capturesFrom(tx,ty)>0 then
    status="Есть продолжение боя — ходи этой же шашкой."
    selected={x=tx,y=ty}
    legalTargets=capturesFrom(tx,ty)
    return true,"continue"
  end
  selected=nil
  legalTargets={}
  turn=(turn=="white") and "black" or "white"
  local opponent=(turn=="white") and "black" or "white"
  if countPieces(turn)==0 or not hasAnyMove(turn) then
    gameOver=true
    winner=opponent
    status="Победа: "..sideName(winner).."!"
  else
    status="Ход "..sideName(turn).."."
  end
  return true
end

local function handleMove(from,data)
  if not isHost or not gameStarted or gameOver then return end
  if from~=turn and from~=localPlayer then
    net.send(from,{kind="error",text="Сейчас ход другого игрока."})
    return
  end
  local side=(from==roomPlayers.white) and "white" or "black"
  if side~=turn then net.send(from,{kind="error",text="Сейчас не ваш ход."}); return end
  local ok,msg=applyMove(data.sx,data.sy,data.tx,data.ty)
  if not ok then net.send(from,{kind="error",text=msg}); return end
  if msg=="continue" then
    -- Не передаём ход, если взятие можно продолжить.
  end
  sendState()
end

local function cellFromTap(x,y)
  local bx=math.floor((x-boardX)/cell)+1
  local by=math.floor((y-boardY)/cell)+1
  if bx>=1 and bx<=8 and by>=1 and by<=8 then return bx,by end
  return nil,nil
end

local function handleBoardTap(x,y)
  local bx,by=cellFromTap(x,y)
  if not bx or page~="game" or gameOver then return end
  if not mySide or turn~=mySide then notify("Сейчас ход соперника."); return end
  local p=pieceAt(bx,by)
  if selected then
    local ok,t=validMove(selected.x,selected.y,bx,by)
    if ok then
      if isHost then
        local moved,msg=applyMove(selected.x,selected.y,bx,by)
        if moved then sendState() end
      else
        net.send(hostName,{kind="move",room=roomCode,sx=selected.x,sy=selected.y,tx=bx,ty=by})
      end
      return
    elseif p and p.side==mySide then
      selected={x=bx,y=by}
      legalTargets=targetsFrom(bx,by)
      return
    else
      selected=nil
      legalTargets={}
      return
    end
  elseif p and p.side==mySide then
    if anyCapture(turn) and #capturesFrom(bx,by)==0 then
      notify("Обязательное взятие: выбери шашку, которая бьёт.")
      return
    end
    selected={x=bx,y=by}
    legalTargets=targetsFrom(bx,by)
  end
end

local function drawPiece(cx,cy,p)
  local col=p.side=="white" and WHITE or BLACK
  gfx.circle(cx,cy,7,col)
  gfx.circle(cx,cy,5,p.side=="white" and "#D9D0C2" or "#45464D")
  gfx.border(cx-7,cy-7,14,14,7,p.side=="white" and "#FFFFFF" or "#8A8B90")
  if p.king then
    gfx.textCenter("♛",cx,cy-5,GOLD,0.8)
  end
end

local function drawMenu()
  gfx.gradient(0,0,W,H,"#174D38","#0B2B21")
  gfx.textCenter("ШАШКИ",W/2,24,GOLD,2.0)
  gfx.textCenter("ОНЛАЙН",W/2,47,"#FFFFFF",1.2)
  gfx.roundRect(10,70,140,65,8,"#1E6548")
  gfx.textCenter("Русские шашки",W/2,83,"#FFFFFF",1.0)
  gfx.textCenter("8 × 8 • 2 игрока",W/2,103,"#CBE7D6",0.8)
  if ui.button(15,146,130,27,"Создать комнату","primary") then createRoom() end
  gfx.text("Подключиться",15,185,"#FFFFFF",0.9)
  ui.input("room",15,198,130,22,"Код комнаты")
  ui.input("host",15,225,130,22,"Ник ведущего")
  if ui.button(15,253,130,22,"Войти","normal") then joinRoom() end
end

local function drawLobby()
  gfx.gradient(0,0,W,H,"#174D38","#0B2B21")
  gfx.textCenter("КОМНАТА",W/2,18,GOLD,1.4)
  gfx.textCenter("Код: "..(roomCode or "—"),W/2,41,"#FFFFFF",1.2)
  gfx.text("Ведущий: "..(hostName or "—"),10,61,"#D4E9DD",0.75)
  gfx.text("Белые: "..(roomPlayers.white or "ожидание"),10,87,"#FFFFFF",0.8)
  gfx.text("Чёрные: "..(roomPlayers.black or "ожидание соперника"),10,105,"#FFFFFF",0.8)
  if isHost then
    if ui.button(10,150,140,28,"Начать партию","primary") then beginGame() end
    if ui.button(10,184,140,25,"Обновить лобби","normal") then
      net.broadcast({kind="hello",room=roomCode,host=hostName})
    end
  else
    gfx.text("Ожидаем начала партии…",10,156,"#FFFFFF",0.8)
  end
  if ui.button(10,246,140,24,"В меню","normal") then page="menu" end
  gfx.text(status,8,277,"#EADFAF",0.55)
end

local function drawGame()
  gfx.gradient(0,0,W,H,"#174D38","#0B2B21")
  gfx.textCenter("ШАШКИ ОНЛАЙН",W/2,5,GOLD,1.0)
  gfx.text("Ход: "..sideName(turn),7,22,"#FFFFFF",0.8)
  gfx.text(mySide=="white" and "Вы: белые" or "Вы: чёрные",86,22,"#EADFAF",0.65)
  boardX=8
  boardY=42
  cell=18
  for y=1,8 do
    for x=1,8 do
      local px=boardX+(x-1)*cell
      local py=boardY+(y-1)*cell
      local dark=(x+y)%2==0
      gfx.rect(px,py,cell,cell,dark and DARK or LIGHT)
      if selected and selected.x==x and selected.y==y then
        gfx.border(px,py,cell,cell,0,GOLD)
      end
      for _,t in ipairs(legalTargets) do
        if t.x==x and t.y==y then gfx.circle(px+cell/2,py+cell/2,3,"#7EE081") end
      end
      local p=pieceAt(x,y)
      if p then drawPiece(px+cell/2,py+cell/2,p) end
    end
  end
  gfx.text(status,5,193,"#FFF0B8",0.58)
  gfx.text("Белые: "..countPieces("white").."  Чёрные: "..countPieces("black"),5,207,"#FFFFFF",0.65)
  if gameOver then
    gfx.roundRect(15,226,130,28,5,"#0B2B21")
    gfx.textCenter("Победа: "..sideName(winner),W/2,235,GOLD,0.85)
  end
  if ui.button(5,263,70,21,"Синхр.","normal") then
    if isHost then sendState() else net.send(hostName,{kind="sync",room=roomCode}) end
  end
  if ui.button(82,263,73,21,"В меню","normal") then page="menu" end
  gfx.text("Нажми свою шашку, затем клетку.",5,286,"#D4E9DD",0.52)
end

function onStart()
  math.randomseed(time.now())
  screen.title("Шашки онлайн")
  screen.captureKeys(true)
  page="menu"
end

function onShow() end
function onHide() end

function onBack()
  if page~="menu" then page="menu"; return true end
  return false
end

function onClick(x,y,button)
  if page=="game" and y>=boardY and y<boardY+cell*8 then
    handleBoardTap(x,y)
  end
end

function onMessage(from,data)
  if type(data)~="table" then return end
  if data.kind=="join" and isHost and data.room==roomCode then
    if not roomPlayers.black and from~=localPlayer then
      roomPlayers.black=from
      lobbyNames={roomPlayers.white,roomPlayers.black}
      net.send(from,{kind="lobby",room=roomCode,host=hostName,whiteName=roomPlayers.white,blackName=roomPlayers.black})
      notify(from.." подключился как чёрные.")
      net.send(roomPlayers.white,{kind="lobby",room=roomCode,host=hostName,whiteName=roomPlayers.white,blackName=roomPlayers.black})
    else
      net.send(from,{kind="error",text="Комната уже заполнена."})
    end
  elseif data.kind=="hello" and not isHost and data.room==roomCode then
    hostName=data.host or from
    net.send(hostName,{kind="join",room=roomCode,name=localPlayer})
  elseif data.kind=="lobby" and not isHost and data.room==roomCode then
    hostName=data.host or from
    roomPlayers.white=data.whiteName
    roomPlayers.black=data.blackName
    status="Комната найдена. Ожидаем начала партии."
  elseif data.kind=="private" and not isHost then
    mySide=data.side
    page="game"
  elseif data.kind=="state" and not isHost and data.room==roomCode then
    board=copyBoard(data.board or {})
    turn=data.turn or turn
    status=data.status or status
    gameStarted=data.gameStarted or false
    gameOver=data.gameOver or false
    winner=data.winner
    roomPlayers.white=data.whiteName
    roomPlayers.black=data.blackName
    if gameStarted then page="game" end
    selected=nil
    legalTargets={}
  elseif data.kind=="move" and isHost and data.room==roomCode then
    handleMove(from,data)
  elseif data.kind=="sync" and isHost then
    sendState()
  elseif data.kind=="error" then
    notify(data.text or "Ошибка.")
  end
end

function onTick()
  if isHost and gameStarted and time.now()-lastSync>1200 then
    lastSync=time.now()
    sendState()
  end
end

function onDraw(dt)
  W,H=screen.width(),screen.height()
  if page=="menu" then drawMenu()
  elseif page=="lobby" then drawLobby()
  else drawGame() end
end
