-- «Блочные гонки»: 3D-гонки с камерой за машинкой. Играть можно на телефоне (с ботами) или на экране в мире
-- («Режим на экране», разрешение display): владелец экрана — ведущий, друзья подключаются к его лобби через это же
-- приложение («Подключиться»), каждый управляет своей машинкой джойстиком (телефон набок, клавиши и мышь), а экран
-- делится на окна игроков. Пример режима экрана для авторов — docs/CUSTOM_APPS.md, «Режим экрана».
local S = require("sim")
local V = require("view")
local Audio = require("audio")
local audioOn = false

local RU = app.lang == "ru_ru"
local function T(ru, en) return RU and ru or en end
local me = app.player

local cfg = {track = storage.get("track", 1), laps = storage.get("laps", 3), bots = storage.get("bots", 3)}
local mode = "menu"     -- menu | solo | screens | join | lobby
local game              -- игра: своя (solo, ведущий) или копия ведущего (гость)
local hosting = false   -- я ведущий игры на экране
local lobby             -- экран лобби: {owner, id}
local lastSend, lastInput, sentBits, lastState = 0, 0, -2, 0
local note = ""
-- Только для проверки разработчиком: dev.lua (если есть) двигает подставного второго игрока.
local okDev, DEV = pcall(require, "dev")
if not okDev or type(DEV) ~= "function" then DEV = nil end
local HINT = T("Руль A/D · газ W или ЛКМ · тормоз S или ПКМ", "Steer A/D · gas W or LMB · brake S or RMB")

local function save()
  storage.set("track", cfg.track)
  storage.set("laps", cfg.laps)
  storage.set("bots", cfg.bots)
end

local function keys()
  local b = 0
  if input.down("w") or input.down("up") or input.down("mouse1") then b = b + S.UP end
  if input.down("s") or input.down("down") or input.down("space") or input.down("mouse2") then b = b + S.DOWN end
  if input.down("a") or input.down("left") then b = b + S.LEFT end
  if input.down("d") or input.down("right") then b = b + S.RIGHT end
  return b
end

-- «Кисти» для надписей: на телефоне — gfx, на экране в мире — display.
local D2phone = {
  rect = function(x, y, w, h, c) gfx.rect(x, y, w, h, c) end,
  text = function(s, x, y, size, c, align)
    local sc = size / 9
    local tw = gfx.textWidth(s, sc)
    if align == "center" then x = x - tw / 2 elseif align == "right" then x = x - tw end
    gfx.text(s, x, y, c, sc, true)
  end,
  image = function(p, x, y, w, h) gfx.image(p, x, y, w, h) end,
}
local D2screen = {
  rect = function(x, y, w, h, c) display.rect(x, y, w, h, c) end,
  text = function(s, x, y, size, c, align) display.text(s, x, y, {size = size, color = c, align = align}) end,
  image = function(p, x, y, w, h) display.image(p, x, y, w, h) end,
}

-- --- Режим на экране ---

local function startOnScreen(id)
  local ok, err = display.start(id)
  if not ok then
    note = tostring(err)
    return
  end
  local cur = display.current()
  hosting, lobby = true, {owner = cur.owner, id = cur.id}
  game = S.new(cfg.track, cfg.laps, cfg.bots)
  mode, note = "lobby", ""
end

local function joinScreen(owner, id)
  local ok, err = display.join(owner, id)
  if not ok then
    note = tostring(err)
    return
  end
  hosting, lobby, game, lastState = false, {owner = owner, id = id}, nil, 0
  mode, note = "lobby", ""
  if net.online() then net.send(owner, {t = "join", s = id}) end
end

local function leaveLobby()
  if lobby and not hosting and net.online() then net.send(lobby.owner, {t = "in", s = lobby.id, k = -1}) end
  display.control(false)
  display.stop()
  hosting, lobby, game, mode = false, nil, nil, "menu"
  Audio.reset()
  audioOn = false
end

-- Кто-то выбрал это приложение в меню экрана или нажал G у экрана с ним.
function onDisplayInvite(owner, id, mine)
  if mine then startOnScreen(id) else joinScreen(owner, id) end
end

function onTick()
  local now = time.now()
  if mode == "solo" and game then
    game:input(me, keys(), now)
    game:step(now)
  elseif mode == "lobby" then
    local cur = display.current()
    if not cur then
      leaveLobby()
      note = T("Экран больше не показывает игру.", "The screen no longer shows the game.")
      return
    end
    local bits = display.controlling() and keys() or 0
    if hosting then
      game:input(me, bits, now)
      if DEV then DEV(game, now) end
      game:step(now)
      local busy = game.phase == "countdown" or game.phase == "race"
      local every = busy and (net.mode() == "cloud" and 100 or 250) or 1000
      if net.online() and now - lastSend >= every then
        lastSend = now
        net.broadcast({t = "st", s = lobby.id, g = game:encode()})
      end
    elseif net.online() and ((bits ~= sentBits and now - lastInput >= 150) or now - lastInput >= 1500) then
      net.send(lobby.owner, {t = "in", s = lobby.id, k = bits})
      sentBits, lastInput = bits, now
    end
  end
  -- Звук: на телефоне — как есть, на экране в мире — тише с расстоянием до экрана.
  if game and (mode == "solo" or mode == "lobby") then
    local vol = 1
    if mode == "lobby" then
      local cur = display.current()
      vol = cur and math.max(0, 1 - (cur.distance or 0) / 40) or 0
    end
    Audio.update(game, me, vol)
    audioOn = true
  elseif audioOn then
    Audio.reset()
    audioOn = false
  end
end

-- Свернули телефон: в игре на телефоне звуки замолкают (на экране в мире — продолжают).
function onHide()
  if mode ~= "lobby" then
    Audio.reset()
    audioOn = false
  end
end

function onMessage(from, d)
  if type(d) ~= "table" or not lobby then return end
  local now = time.now()
  if d.t == "st" and not hosting and from:lower() == lobby.owner:lower() and d.s == lobby.id and type(d.g) == "table" then
    local o = d.g
    if not game or game.ti ~= o.ti or game.laps ~= o.laps or game.bots ~= o.bots then
      game = S.new(tonumber(o.ti) or 1, tonumber(o.laps) or 3, tonumber(o.bots) or 0)
    end
    if game:decode(o, now) then lastState = now end
  elseif hosting and d.s == lobby.id and (d.t == "in" or d.t == "join") then
    game:input(from, d.t == "join" and 0 or (tonumber(d.k) or 0), now)
    lastSend = 0
  end
end

-- Картинка на экране в мире: игра (у каждого игрока своё окно) или «ждём ведущего».
function onDisplay(dt, w, h)
  if not game then
    display.clear("#101828")
    display.text(T("Подключаемся к игре…", "Joining the game…"), w / 2, h / 2 - 6, {size = 12, align = "center"})
    return
  end
  local hint = T("У экрана: G — джойстик, газ — готов", "At the screen: G — gamepad, gas — ready")
  V.render(game, time.now(), dt, 0, 0, w, h, D2screen, me, {lobbyHint = hint})
  if not hosting and time.now() - lastState > 3000 then
    display.rect(0, h - 14, w, 14, "#AA000000")
    display.text(T("Нет связи с ведущим…", "No connection to the host…"), w / 2, h - 12, {size = 9, color = "#FFEB3B", align = "center"})
  end
end

-- --- Телефон ---

local function settingsRow(x, y, w, editable)
  local n = #require("tracks")
  local bw = (w - (n - 1) * 4) / n
  for i = 1, n do
    local tn = require("tracks")[i].name
    if ui.button(x + (i - 1) * (bw + 4), y, bw, 16, tn[app.lang] or tn.en_us, cfg.track == i and "selected" or "normal") and editable then
      cfg.track = i
      save()
    end
  end
  y = y + 20
  local half = (w - 4) / 2
  local function stepper(sx, label, value, min, max, set)
    gfx.text(label .. ": " .. value, sx, y + 4, "#FFFFFF", 0.8)
    if ui.button(sx + half - 38, y, 18, 16, "-") and editable and value > min then set(value - 1) end
    if ui.button(sx + half - 18, y, 18, 16, "+") and editable and value < max then set(value + 1) end
  end
  stepper(x, T("Круги", "Laps"), cfg.laps, 1, S.MAX_LAPS, function(v) cfg.laps = v save() end)
  stepper(x + half + 4, T("Боты", "Bots"), cfg.bots, 0, S.CARS, function(v) cfg.bots = v save() end)
  return y + 20
end

local function drawMenu(w, h)
  gfx.gradient(0, 0, w, h, "#16233A", "#0B1220")
  gfx.image("textures/logo.png", 10, 8, 26, 26)
  gfx.text(T("Блочные гонки", "Block Racing"), 42, 10, "#FFEB3B", 1.3, true)
  gfx.text(T("3D-гонки с ботами и друзьями", "3D racing with bots and friends"), 42, 24, theme.secondary(), 0.7)
  local x, cw = 10, w - 20
  local y = settingsRow(x, 40, cw, true)
  local half = (cw - 4) / 2
  if ui.button(x, y, half, 20, T("Играть на телефоне", "Play on the phone"), "primary") then
    game = S.new(cfg.track, cfg.laps, cfg.bots)
    mode = "solo"
  end
  if ui.button(x + half + 4, y, half, 20, T("Режим на экране", "Screen mode"), "primary") then
    mode, note = "screens", ""
  end
  y = y + 24
  if ui.button(x, y, cw, 18, T("Подключиться к игре на экране", "Join a game on a screen")) then
    mode, note = "join", ""
  end
  y = y + 22
  if note ~= "" then gfx.text(note, x, y, theme.danger(), 0.7) end
end

local function drawScreens(w, h)
  gfx.clear("#0B1220")
  gfx.text(T("Режим на экране: выбери свой экран", "Screen mode: pick your screen"), 10, 8, "#FFFFFF", 1)
  gfx.text(T("Игра будет на экране в мире, друзья подключатся к твоему лобби.",
    "The game goes to the screen in the world; friends join your lobby."), 10, 20, theme.secondary(), 0.65)
  local y = 34
  local list = display.screens()
  if #list == 0 then
    gfx.text(T("Своих экранов нет — создай экран в приложении «Экраны».", "No screens yet — create one in the Screens app."),
      10, y, theme.secondary(), 0.75)
    y = y + 14
  end
  for _, s in ipairs(list) do
    local label = (s.name ~= "" and s.name or s.id) .. "  " .. s.width .. "×" .. s.height .. "  · " .. math.floor(s.distance) .. " m"
    if ui.button(10, y, w - 20, 18, label) then startOnScreen(s.id) end
    y = y + 21
    if y > h - 30 then break end
  end
  if note ~= "" then gfx.text(note, 10, h - 40, theme.danger(), 0.7) end
  if ui.button(10, h - 24, 70, 18, T("Назад", "Back")) then mode = "menu" end
end

local function drawJoin(w, h)
  gfx.clear("#0B1220")
  gfx.text(T("Игры на экранах рядом", "Games on screens nearby"), 10, 8, "#FFFFFF", 1)
  local y = 24
  local any = false
  for _, s in ipairs(display.nearby()) do
    any = true
    local label = s.owner .. " · " .. (s.name ~= "" and s.name or s.id) .. " · " .. math.floor(s.distance) .. " m"
    if ui.button(10, y, w - 20, 18, label, s.mine and "normal" or "primary") then
      if s.mine then startOnScreen(s.id) else joinScreen(s.owner, s.id) end
    end
    y = y + 21
    if y > h - 30 then break end
  end
  if not any then
    gfx.text(T("Рядом нет экранов с «Блочными гонками».", "No screens with Block Racing nearby."), 10, y, theme.secondary(), 0.75)
  end
  if note ~= "" then gfx.text(note, 10, h - 40, theme.danger(), 0.7) end
  if ui.button(10, h - 24, 70, 18, T("Назад", "Back")) then mode = "menu" end
end

local function drawLobby(w, h)
  gfx.gradient(0, 0, w, h, "#16233A", "#0B1220")
  local cur = display.current()
  local where = cur and ((cur.name ~= "" and cur.name or cur.id) .. (hosting and "" or (" · " .. cur.owner))) or "?"
  gfx.text(T("Игра на экране: ", "Game on screen: ") .. where, 10, 8, "#FFFFFF", 0.95)
  gfx.text(hosting and T("Ты ведущий: друзья подключаются через «Блочные гонки» → «Подключиться».",
    "You host: friends join via Block Racing → Join.")
    or T("Ты в лобби ведущего.", "You are in the host's lobby."), 10, 20, theme.secondary(), 0.65)
  local y = 32
  if game then
    for i, c in ipairs(game.cars) do
      if c.present then
        gfx.rect(10, y + 2, 7, 7, S.COLORS[i])
        local who = c.driver == "" and "CPU" or c.driver
        local st = c.driver == "" and "" or (game.phase == "lobby" and (c.ready and T("готов", "ready") or "…") or V.place(c.rank))
        gfx.text(who .. "  " .. st, 22, y + 1, "#FFFFFF", 0.75)
        y = y + 11
      end
    end
  else
    gfx.text(T("Ждём ведущего…", "Waiting for the host…"), 10, y, theme.secondary(), 0.75)
    y = y + 11
  end
  y = math.max(y + 4, 80)
  if hosting and game and game.phase == "lobby" then
    y = settingsRow(10, y, w - 20, true)
    if game.ti ~= cfg.track or game.laps ~= cfg.laps or game.bots ~= cfg.bots then
      local old = game
      game = S.new(cfg.track, cfg.laps, cfg.bots)
      for _, c in ipairs(old.cars) do
        if c.present and c.driver ~= "" then game:input(c.driver, 0, c.seen) end
      end
    end
  end
  local half = (w - 24) / 2
  if ui.button(10, h - 26, half, 20, T("Джойстик (играть)", "Gamepad (play)"), "primary") then
    display.control(true, HINT)
  end
  if ui.button(14 + half, h - 26, half, 20, hosting and T("Закончить", "End") or T("Выйти из лобби", "Leave lobby"), "danger") then
    leaveLobby()
  end
end

function onDraw(dt)
  local w, h = screen.width(), screen.height()
  if mode == "solo" and game then
    V.render(game, time.now(), dt, 0, 0, w, h, D2phone, me, {quality = 0.6, lobbyHint = T("Газ — старт · Esc — меню", "Gas — start · Esc — menu")})
  elseif mode == "screens" then
    drawScreens(w, h)
  elseif mode == "join" then
    drawJoin(w, h)
  elseif mode == "lobby" then
    drawLobby(w, h)
  else
    drawMenu(w, h)
  end
end

function onBack()
  if mode == "solo" or mode == "screens" or mode == "join" then
    mode, game = "menu", (mode == "solo") and nil or game
    return true
  end
  if mode == "lobby" then
    return false -- лобби остаётся (игра на экране идёт и с закрытым телефоном); выйти — кнопкой
  end
  return false
end

function onStart()
  screen.captureKeys(true)
  screen.minimizeKey(true)
end
