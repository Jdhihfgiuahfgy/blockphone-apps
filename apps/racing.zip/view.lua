-- Мир 3D: X = x, Z = H − y (у движка «правая» система, у карты y вниз — иначе вид зеркальный и руль наоборот).
-- 3D-вид гонки: камера за машинкой, у каждого игрока своё окно (1 — весь экран, 2 — пополам слева/справа,
-- 3–4 — четверти), в лобби — облёт старта. Рисует одинаково на телефоне (onDraw, gfx) и на экране в мире
-- (onDisplay, display.*) — разница только в «кисти» для надписей (d2).
local S = require("sim")

local V = {}
local loaded
local tex = {}
local BOX, PLANE, FAR, WALL_X, WALL_Z, BANNER
local camYaw = {}

-- Уровень трассы: земля, ограждение, арка, деревья — статическая сцена (рисуется кусками, только видимое).
function V.setup(game)
  if loaded == game.ti then return end
  local src = game.t.src
  g3d.clearStatic()
  tex.ground = g3d.texture(src.ground, {filter = "linear"})
  tex.stripes = g3d.texture("textures/stripes.png")
  tex.checker = g3d.texture("textures/checker.png")
  BOX = BOX or g3d.box(1, 1, 1)
  PLANE = PLANE or g3d.plane(S.W, S.H)
  FAR = FAR or g3d.plane(S.W * 4, S.H * 6)
  WALL_X = WALL_X or g3d.box(S.W, 1.1, 1, 0.5)
  WALL_Z = WALL_Z or g3d.box(1, 1.1, S.H, 0.5)
  BANNER = BANNER or g3d.box(2 * (S.HALF + 2), 1.3, 0.5)
  g3d.static(PLANE, S.W / 2, 0, S.H / 2, {texture = tex.ground, lit = false, sz = -1}) -- карта вверх ногами: мир Z = H − y
  g3d.static(WALL_X, S.W / 2, 0.55, 0.5, {texture = tex.stripes})
  g3d.static(WALL_X, S.W / 2, 0.55, S.H - 0.5, {texture = tex.stripes})
  g3d.static(WALL_Z, 0.5, 0.55, S.H / 2, {texture = tex.stripes})
  g3d.static(WALL_Z, S.W - 0.5, 0.55, S.H / 2, {texture = tex.stripes})
  -- Стартовая арка.
  local x, y, a = S.pointAt(game.t, 0)
  local nx, ny, off = -math.sin(a), math.cos(a), S.HALF + 2
  for side = -1, 1, 2 do
    g3d.static(BOX, x + nx * off * side, 2.75, S.H - (y + ny * off * side), {sx = 0.8, sy = 5.5, sz = 0.8, tint = "#9E9E9E"})
  end
  g3d.static(BANNER, x, 5.75, S.H - y, {yaw = math.deg(math.atan2(math.cos(a), -math.sin(a))), texture = tex.checker})
  -- Деревья, камни, кактусы.
  for _, p in ipairs(src.props) do
    local px, py, kind, k, yaw = p[1], p[2], p[3], p[4], p[5]
    local function part(lx, ly, lz, sx, sy, sz, tint)
      local r = math.rad(yaw)
      local c, s = math.cos(r), math.sin(r)
      g3d.static(BOX, px + lx * c + lz * s, ly, S.H - py - lx * s + lz * c, {yaw = yaw, sx = sx, sy = sy, sz = sz, tint = tint})
    end
    if kind == 0 then
      part(0, 1 * k, 0, 0.6 * k, 2 * k, 0.6 * k, "#6D4C41")
      part(0, 3 * k, 0, 3 * k, 2.25 * k, 3 * k, src.theme == 1 and "#1B5E20" or "#2E7D32")
      part(0, 4.7 * k, 0, 1.9 * k, 1.3 * k, 1.9 * k, src.theme == 1 and "#388E3C" or "#43A047")
    elseif kind == 1 then
      part(0, 0.6 * k, 0, 2.5 * k, 1.3 * k, 2.1 * k, "#8D8478")
    else
      part(0, 1.5 * k, 0, 0.7 * k, 3 * k, 0.7 * k, "#2E7D32")
      part(0.75 * k, 1.8 * k, 0, 0.8 * k, 0.45 * k, 0.45 * k, "#2E7D32")
      part(1.0 * k, 2.3 * k, 0, 0.45 * k, 1 * k, 0.45 * k, "#388E3C")
      part(-0.75 * k, 2.2 * k, 0, 0.8 * k, 0.45 * k, 0.45 * k, "#2E7D32")
      part(-1.0 * k, 2.6 * k, 0, 0.45 * k, 0.8 * k, 0.45 * k, "#388E3C")
    end
  end
  loaded = game.ti
  camYaw = {}
end

local function part(px, py, yawDeg, lx, ly, lz, sx, sy, sz, tint, lit)
  local r = math.rad(yawDeg)
  local c, s = math.cos(r), math.sin(r)
  g3d.draw(BOX, px + lx * c + lz * s, ly, py - lx * s + lz * c, {yaw = yawDeg, sx = sx, sy = sy, sz = sz, tint = tint, lit = lit})
end

-- Машинка из брусков: кузов, кабина, спойлер, колёса, фары.
local function car(x, y, a, color)
  local yaw = 90 + math.deg(a) -- y здесь уже мировой Z
  g3d.draw(BOX, x + 0.3, 0.02, y + 0.3, {yaw = yaw, sx = 3, sy = 0.02, sz = 5.2, tint = "#66000000", lit = false, blend = "alpha"})
  part(x, y, yaw, 0, 0.58, 0, 2.5, 0.65, 4.5, color, true)
  part(x, y, yaw, 0, 1.2, -0.35, 2.05, 0.65, 2.3, "#1C262B", true)
  part(x, y, yaw, 0, 1.55, -0.35, 1.8, 0.08, 2.0, color, true)
  part(x, y, yaw, 0, 1.15, -2.05, 2.5, 0.15, 0.5, "#424242", true)
  for sx = -1, 1, 2 do
    for sz = -1, 1, 2 do
      part(x, y, yaw, sx * 1.28, 0.4, sz * 1.45, 0.5, 0.8, 0.95, "#151515", true)
    end
    part(x, y, yaw, sx * 0.8, 0.65, 2.27, 0.6, 0.25, 0.1, "#FFF59D", false)
    part(x, y, yaw, sx * 0.8, 0.65, -2.27, 0.6, 0.25, 0.1, "#E53935", false)
  end
end

local function place(r)
  if r == 1 then return "1st" elseif r == 2 then return "2nd" elseif r == 3 then return "3rd" end
  return r .. "th"
end
V.place = place

local function short(name)
  return #name > 10 and name:sub(1, 10) or name
end

-- Одно окно: камера за машинкой car (nil — облёт старта).
local function view(game, now, dt, x0, y0, vw, vh, carIndex, d2, quality)
  local t = game.t
  local sky = t.src.sky
  g3d.sky{top = sky.top, horizon = sky.horizon, bottom = sky.horizon, sun = true}
  g3d.fog(sky.horizon, 75, 230)
  g3d.light(-0.5, -1, -0.35, 0.55)
  local fov = vw < vh and 80 or 70
  if carIndex then
    local x, y, a = game:pose(carIndex, now)
    camYaw[carIndex] = camYaw[carIndex] or a
    camYaw[carIndex] = S.wrap(camYaw[carIndex] + S.wrap(a - camYaw[carIndex]) * (1 - math.exp(-dt * 5)))
    local ca = camYaw[carIndex]
    g3d.camera(x - math.cos(ca) * 8.5, 3.3, S.H - (y - math.sin(ca) * 8.5), 90 + math.deg(ca), -13, fov)
  else
    local sx, sy = S.pointAt(t, 0)
    sy = S.H - sy
    local ang = now / 9000
    local cx, cz = sx + math.cos(ang) * 28, sy + math.sin(ang) * 28
    g3d.camera(cx, 10, cz, math.deg(math.atan2(sx - cx, sy - cz)), -18, fov)
  end
  g3d.begin(x0, y0, vw, vh, sky.horizon, quality)
  g3d.draw(FAR, S.W / 2, -0.05, S.H / 2, {tint = t.src.far, lit = false})
  g3d.drawStatic()
  for i, c in ipairs(game.cars) do
    if c.present then
      local x, y, a = game:pose(i, now)
      car(x, S.H - y, a, S.COLORS[i])
    end
  end
  g3d.finish()
  if carIndex and game.phase ~= "lobby" then
    -- Надписи окна: круг, место, имя, скорость, мини-карта.
    local c = game.cars[carIndex]
    local k = math.max(0.6, vh / 216)
    local fs = 10 * k
    d2.rect(x0, y0, 64 * k, 14 * k, "#99000000")
    d2.text("LAP " .. math.max(1, math.min(game.laps, c.lap)) .. "/" .. game.laps, x0 + 4 * k, y0 + 3 * k, fs, "#FFFFFF", "left")
    d2.text(place(c.rank), x0 + vw - 5 * k, y0 + 3 * k, fs * 1.8, S.COLORS[carIndex], "right")
    d2.text(c.driver == "" and "CPU" or short(c.driver), x0 + vw / 2, y0 + 3 * k, fs, S.COLORS[carIndex], "center")
    local sp = game:kmh(carIndex) .. " km/h"
    d2.rect(x0 + vw - 62 * k, y0 + vh - 15 * k, 62 * k, 15 * k, "#99000000")
    d2.text(sp, x0 + vw - 5 * k, y0 + vh - 12 * k, fs, "#FFFFFF", "right")
    if c.done then
      d2.text("FINISH! " .. place(c.rank), x0 + vw / 2, y0 + vh / 2 - 24 * k, fs * 2, "#FFFFFF", "center")
    end
    local mw, mh = 80 * k * (vw < 200 and 0.6 or 1), 45 * k * (vw < 200 and 0.6 or 1)
    local mx, my = x0 + 4 * k, y0 + vh - mh - 4 * k
    d2.image(t.src.map, mx, my, mw, mh)
    for i, o in ipairs(game.cars) do
      if o.present then
        local px, py = game:pose(i, now)
        local dx, dy = mx + px / S.W * mw, my + py / S.H * mh
        if i == carIndex then d2.rect(dx - 2.5 * k, dy - 2.5 * k, 5 * k, 5 * k, "#FFFFFF") end
        d2.rect(dx - 1.5 * k, dy - 1.5 * k, 3 * k, 3 * k, S.COLORS[i])
      end
    end
  end
end

local function leader(game)
  local best
  for i, c in ipairs(game.cars) do
    if c.present and (not best or c.rank < game.cars[best].rank) then best = i end
  end
  return best
end

-- Общие надписи поверх окон: лобби, отсчёт, старт, итоги.
local function overlay(game, x, y, w, h, d2, me, extra)
  local k = math.max(0.6, h / 216)
  local cx, cy = x + w / 2, y + h / 2
  local fs = 10 * k
  if game.phase == "lobby" then
    d2.rect(cx - 110 * k, cy - 62 * k, 220 * k, 124 * k, "#C0101828")
    d2.text("BLOCK RACING", cx, cy - 56 * k, fs * 2.4, "#FFEB3B", "center")
    local tn = game.t.src.name
    d2.text((tn[app.lang] or tn.en_us) .. " · " .. game.laps .. " lap" .. (game.laps == 1 and "" or "s"), cx, cy - 30 * k, fs,
      "#FFFFFF", "center")
    local yy = cy - 16 * k
    for i, c in ipairs(game.cars) do
      if c.present then
        d2.rect(cx - 78 * k, yy + 1 * k, 7 * k, 7 * k, S.COLORS[i])
        d2.text(c.driver == "" and "CPU" or short(c.driver), cx - 66 * k, yy, fs, "#FFFFFF", "left")
        if c.driver ~= "" then
          d2.text(c.ready and "READY" or "...", cx + 78 * k, yy, fs, c.ready and "#76FF03" or "#90A4AE", "right")
        end
        yy = yy + 11 * k
      end
    end
    d2.text(extra or "Gas = ready", cx, cy + 46 * k, fs, "#90CAF9", "center")
  elseif game.phase == "countdown" then
    d2.text(tostring(game:countdown()), cx, cy - 34 * k, fs * 7, "#FFEB3B", "center")
  elseif game.phase == "race" then
    if game.timer < 20 then d2.text("GO!", cx, cy - 34 * k, fs * 7, "#76FF03", "center") end
  elseif game.phase == "results" then
    d2.rect(cx - 90 * k, cy - 54 * k, 180 * k, 104 * k, "#C0101828")
    d2.text("RESULTS", cx, cy - 48 * k, fs * 2, "#FFEB3B", "center")
    for r = 1, S.CARS do
      for i, c in ipairs(game.cars) do
        if c.present and c.rank == r then
          local yy = cy - 24 * k + (r - 1) * 14 * k
          d2.rect(cx - 62 * k, yy + 1 * k, 8 * k, 8 * k, S.COLORS[i])
          d2.text(place(r) .. "  " .. (c.driver == "" and "CPU" or short(c.driver)), cx - 48 * k, yy, fs,
            (c.driver ~= "" and c.driver:lower() == me:lower()) and "#FFEB3B" or "#FFFFFF", "left")
        end
      end
    end
  end
end

-- Кадр игры в прямоугольнике (x, y, w, h). viewers — номера машинок, у которых своё окно (обычно — игроки).
function V.render(game, now, dt, x, y, w, h, d2, me, opts)
  opts = opts or {}
  V.setup(game)
  local q = opts.quality or 1
  local humans = {}
  for i, c in ipairs(game.cars) do
    if c.present and c.driver ~= "" and (not opts.only or c.driver:lower() == opts.only:lower()) then
      table.insert(humans, i)
    end
  end
  if game.phase == "lobby" or #humans == 0 then
    view(game, now, dt, x, y, w, h, game.phase ~= "lobby" and leader(game) or nil, d2, q)
  elseif #humans == 1 then
    view(game, now, dt, x, y, w, h, humans[1], d2, q)
  elseif #humans == 2 then
    local hw = math.floor(w / 2)
    view(game, now, dt, x, y, hw - 1, h, humans[1], d2, q)
    view(game, now, dt, x + hw + 1, y, w - hw - 1, h, humans[2], d2, q)
    d2.rect(x + hw - 1, y, 2, h, "#000000")
  else
    local hw, hh = math.floor(w / 2), math.floor(h / 2)
    for k = 1, 4 do
      local ci = humans[k] or leader(game)
      local vx = (k % 2 == 1) and x or x + hw + 1
      local vy = (k <= 2) and y or y + hh + 1
      view(game, now, dt, vx, vy, (k % 2 == 1) and hw - 1 or w - hw - 1, (k <= 2) and hh - 1 or h - hh - 1, ci, d2, q)
    end
    d2.rect(x + hw - 1, y, 2, h, "#000000")
    d2.rect(x, y + hh - 1, w, 2, "#000000")
  end
  overlay(game, x, y, w, h, d2, me, opts.lobbyHint)
end

return V
