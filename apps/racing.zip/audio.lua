-- Звук гонки: мотор своей машинки (высота тона — по скорости, с «передачами»), визг шин в заносе, шорох травы,
-- удары, отсчёт, старт, новый круг, финиш. Звуки — sounds/*.wav (tools/gen_racing_sounds.py).
-- На экране в мире громкость падает с расстоянием до экрана (display.current().distance).
local S = require("sim")

local A = {}
local engine, skid, offroad
local last = {}

-- Звуки остановлены (приложение свернули) — начать заново при следующем такте.
function A.reset()
  sound.stop()
  engine, skid, offroad = nil, nil, nil
  last = {}
end

local function play(name, vol)
  if vol > 0.01 then sound.play("sounds/" .. name .. ".wav", math.min(1, vol)) end
end

-- Каждый такт. game — игра, me — ник (своя машинка), vol — общая громкость 0..1.
function A.update(game, me, vol)
  local c, idx
  for i, o in ipairs(game.cars) do
    if o.present and o.driver ~= "" and o.driver:lower() == me:lower() then c, idx = o, i end
  end
  -- События для всех: отсчёт, старт.
  local cd = game:countdown()
  if cd ~= last.cd and cd > 0 then play("beep", 0.7 * vol) end
  if game.phase == "race" and last.phase == "countdown" then play("go", 0.8 * vol) end
  if game.phase == "results" and last.phase == "race" and not (c and c.done) then play("finish", 0.6 * vol) end
  last.cd, last.phase = cd, game.phase
  if not c or not sound.tune then -- sound.tune есть в моде с 0.17.2; без него — только короткие звуки
    if engine and sound.tune then
      sound.tune(engine, 0, 1)
    end
    return
  end
  -- Скорость и занос — по снимкам (одинаково у ведущего и гостя).
  local x, y, a = game:pose(idx, time.now())
  local kmh = game:kmh(idx)
  local s = math.min(1.2, kmh / 130)
  local turn = last.a and math.abs(S.wrap(a - last.a)) or 0
  last.a = a
  -- Обороты: 4 передачи — внутри передачи тон растёт, на переключении падает.
  local gear = math.min(3, math.floor(s * 4))
  local inGear = s * 4 - gear
  local pitch = 0.55 + gear * 0.12 + inGear * 0.55
  if game.phase ~= "race" then pitch = 0.55 + (S.has(c.input, S.UP) and 0.25 or 0) end
  if not engine then engine = sound.loop("sounds/engine.wav", 1) end
  sound.tune(engine, vol * (0.35 + 0.45 * math.min(1, s + (S.has(c.input, S.UP) and 0.2 or 0))), pitch)
  -- Визг шин: быстрый поворот на скорости.
  local slip = math.max(0, turn * kmh / 6 - 0.35)
  if not skid then skid = sound.loop("sounds/skid.wav", 1) end
  sound.tune(skid, vol * math.min(0.8, slip), 0.9 + s * 0.2)
  -- Трава / песок под колёсами.
  local d = S.locate(game.t, x, y, c.seg)
  local off = (d > S.HALF + S.CURB and kmh > 5) and math.min(1, kmh / 60) or 0
  if not offroad then offroad = sound.loop("sounds/offroad.wav", 1) end
  sound.tune(offroad, vol * 0.7 * off, 0.8 + s * 0.4)
  -- Удар: скорость резко упала.
  if last.kmh and last.kmh - kmh > 30 then play("crash", vol * math.min(1, (last.kmh - kmh) / 80)) end
  last.kmh = kmh
  -- Круг и финиш.
  if last.lap and c.lap > last.lap and c.lap >= 2 and not c.done then play("lap", 0.7 * vol) end
  if c.done and not last.done then play("finish", 0.8 * vol) end
  last.lap, last.done = c.lap, c.done
end

return A
