-- Дурак онлайн для BlockPhone
-- Сетевой прототип на основе API из инструкции CUSTOM_APPS.
-- Схема: создатель комнаты — ведущий (тасует колоду и проверяет ходы),
-- остальные игроки отправляют ему действия через net.send.
-- Ведущий должен держать приложение открытым во время партии.

local W, H = 160, 290
local screenName = "menu"
local status = "Создай комнату или подключись к ведущему."
local roomCode = ""
local hostName = ""
local players = {}
local hand = {}
local tableCards = {}
local deckCount = 36
local trump = "♠"
local phase = "waiting"
local myTurn = false
local selected = 1
local inputName = "room"
local pendingAction = nil
local gameOver = false
local lastSync = 0
local isHost = false
local localPlayer = app.player or "Игрок"
local rankOrder = {["6"]=1,["7"]=2,["8"]=3,["9"]=4,["10"]=5,["J"]=6,["Q"]=7,["K"]=8,["A"]=9}
local suits = {"♠", "♥", "♦", "♣"}
local suitNames = {["♠"]="пики",["♥"]="червы",["♦"]="бубны",["♣"]="трефы"}
local redSuits = {["♥"]=true,["♦"]=true}
local function notify(s) status = s; toast(s) end
local function copy(t)
  local r = {}
  for k,v in pairs(t or {}) do
    if type(v) == "table" then
      local q = {}; for a,b in pairs(v) do q[a]=b end; r[k]=q
    else r[k]=v end
  end
  return r
end
local function shuffle(t)
  for i=#t,2,-1 do local j=math.random(i); t[i],t[j]=t[j],t[i] end
end
local function makeDeck()
  local d={}
  for _,s in ipairs(suits) do
    for r,_ in pairs(rankOrder) do d[#d+1]={r=r,s=s} end
  end
  shuffle(d)
  return d
end
local function cardText(c)
  if not c then return "—" end
  return tostring(c.r)..c.s
end
local function beats(a,b)
  if a.s==b.s then return rankOrder[a.r] > rankOrder[b.r] end
  return a.s==trump and b.s~=trump
end
local function hasRankOnTable(c)
  for _,pair in ipairs(tableCards) do
    if pair.a.r==c.r or (pair.b and pair.b.r==c.r) then return true end
  end
  return false
end
local function publicState()
  local pubPlayers={}
  for _,p in ipairs(players) do pubPlayers[#pubPlayers+1]={name=p.name,count=#(p.hand or {}),out=p.out or false} end
  local pubPairs={}
  for _,p in ipairs(tableCards) do pubPairs[#pubPairs+1]={a=p.a,b=p.b,attacker=p.attacker} end
  return {kind="state",host=hostName,room=roomCode,players=pubPlayers,table=pubPairs,
    deck=deckCount,trump=trump,phase=phase,turn=players[1] and players[1].name or "",
    status=status,gameOver=gameOver}
end
local function sendState()
  if not isHost then return end
  local s=publicState()
  for _,p in ipairs(players) do
    if p.name~=localPlayer then net.send(p.name,s) end
  end
end
local function findPlayer(name)
  for i,p in ipairs(players) do if p.name==name then return p,i end end
end
local function hostBroadcast(kind, extra)
  if not isHost then return end
  local d=publicState(); d.kind=kind
  if extra then for k,v in pairs(extra) do d[k]=v end end
  for _,p in ipairs(players) do if p.name~=localPlayer then net.send(p.name,d) end end
end
local function deal()
  local d=makeDeck()
  players={}
  players[1]={name=localPlayer,hand={}}
  -- Joined players are remembered in lobbyNames.
  for _,n in ipairs(lobbyNames or {}) do
    if n~=localPlayer and #players<4 then players[#players+1]={name=n,hand={}} end
  end
  for _=1,6 do
    for _,p in ipairs(players) do if #d>0 then p.hand[#p.hand+1]=table.remove(d) end end
  end
  trump=d[#d] and d[#d].s or "♠"
  deckCount=#d-1
  if #d>0 then table.remove(d) end
  deck=d
  tableCards={}
  phase="attack"
  gameOver=false
  myTurn=true
  status="Козырь "..trump..". Ваш ход — атакуйте."
  screenName="game"
  hostBroadcast("state")
  for _,p in ipairs(players) do
    if p.name==localPlayer then
      hand=copy(p.hand)
    else
      net.send(p.name,{kind="private",hand=p.hand,myTurn=false})
    end
  end
end
local function startRoom()
  isHost=true
  hostName=localPlayer
  roomCode=tostring(math.random(1000,9999))
  lobbyNames={localPlayer}
  players={{name=localPlayer,hand={}}}
  screenName="lobby"
  notify("Комната создана. Код: "..roomCode..". Пригласи игроков.")
  hostBroadcast("lobby",{room=roomCode,host=hostName})
end
local function joinRoom()
  local code=ui.getText("room") or ""
  if code=="" then notify("Введи код комнаты."); return end
  isHost=false
  roomCode=code
  hostName=""
  screenName="lobby"
  notify("Отправляем запрос на подключение. Нужен ник ведущего.")
  local target=ui.getText("host") or ""
  if target=="" then notify("Введи ник ведущего в поле ниже."); return end
  hostName=target
  net.send(hostName,{kind="join",name=localPlayer,room=roomCode})
  status="Запрос отправлен ведущему "..hostName.."."
end
local function addPlayer(name)
  if not isHost or not name or name=="" then return end
  for _,n in ipairs(lobbyNames or {}) do if n==name then return end end
  if #(lobbyNames or {})>=4 then net.send(name,{kind="error",text="Комната заполнена (максимум 4)."}); return end
  lobbyNames[#lobbyNames+1]=name
  players[#players+1]={name=name,hand={}}
  status=name.." подключился."
  hostBroadcast("lobby",{room=roomCode,host=hostName,names=lobbyNames})
end
local function drawCard(x,y,w,h,c,face)
  gfx.roundRect(x,y,w,h,4,face and "#F8F5E9" or "#245B9E")
  gfx.border(x,y,w,h,4,face and "#D6D0C0" or "#7DA6D5")
  if face and c then
    local col=redSuits[c.s] and "#C7353C" or "#22252B"
    gfx.text(cardText(c),x+4,y+6,col,1.0)
    gfx.text(c.s,x+4,y+h-13,col,1.0)
  else
    gfx.textCenter("✦",x+w/2,y+h/2-5,"#FFFFFF",1.1)
  end
end
local function drawMenu()
  gfx.gradient(0,0,W,H,"#174D38","#0B2B21")
  gfx.textCenter("ДУРАК",W/2,24,"#F4D98B",2.0)
  gfx.textCenter("ОНЛАЙН",W/2,46,"#FFFFFF",1.2)
  gfx.roundRect(10,70,140,70,8,"#1E6548")
  gfx.textCenter("Карточная игра",W/2,82,"#FFFFFF",1.0)
  gfx.textCenter("2–4 игрока • 36 карт",W/2,100,"#CBE7D6",0.7)
  if ui.button(15,151,130,27,"Создать комнату","primary") then startRoom() end
  gfx.text("Подключиться",15,190,"#FFFFFF",0.9)
  ui.input("room",15,204,130,22,"Код комнаты")
  ui.input("host",15,232,130,22,"Ник ведущего")
  if ui.button(15,258,130,22,"Войти","normal") then joinRoom() end
end
local function drawLobby()
  gfx.gradient(0,0,W,H,"#174D38","#0B2B21")
  gfx.textCenter("КОМНАТА",W/2,16,"#F4D98B",1.4)
  gfx.textCenter("Код: "..(roomCode or "—"),W/2,39,"#FFFFFF",1.2)
  gfx.text("Ведущий: "..(hostName or "—"),10,57,"#D4E9DD",0.75)
  gfx.text("Игроки:",10,77,"#FFFFFF",0.9)
  local names = lobbyNames or {}
  if not isHost then names = {localPlayer,hostName} end
  for i,n in ipairs(names) do gfx.text(i..". "..n,14,91+(i-1)*16,"#D4E9DD",0.8) end
  if isHost then
    if ui.button(10,183,140,28,"Начать игру","primary") then
      if #players<2 then notify("Нужен хотя бы ещё один игрок.") else deal() end
    end
    if ui.button(10,217,140,25,"Обновить список","normal") then hostBroadcast("lobby",{room=roomCode,host=hostName,names=lobbyNames}) end
  else
    gfx.text("Ожидаем начала игры…",10,185,"#FFFFFF",0.8)
  end
  if ui.button(10,254,140,24,"В меню","normal") then screenName="menu" end
  gfx.text(status,8,280,"#EADFAF",0.55)
end
local function drawGame()
  gfx.gradient(0,0,W,H,"#176B45","#0A3D2A")
  gfx.textCenter("ДУРАК ОНЛАЙН",W/2,5,"#F4D98B",1.1)
  gfx.text("Козырь: "..trump,6,23,redSuits[trump] and "#FF9B9B" or "#FFFFFF",0.8)
  gfx.text("Колода: "..deckCount,88,23,"#FFFFFF",0.8)
  local y=40
  for i,p in ipairs(players) do
    gfx.text((p.name==localPlayer and "▶ " or "")..p.name.." ("..tostring(p.count or #(p.hand or {}))..")",6,y,"#FFFFFF",0.7)
    y=y+13
  end
  gfx.roundRect(5,91,150,78,5,"#0F5739")
  gfx.text("Стол",9,94,"#D5E8DB",0.65)
  for i,p in ipairs(tableCards) do
    local x=10+((i-1)%4)*36
    local yy=108+math.floor((i-1)/4)*28
    drawCard(x,yy,29,40,p.a,true)
    if p.b then drawCard(x+7,yy+8,29,40,p.b,true) end
  end
  gfx.text(status,6,174,"#FFF0B8",0.62)
  gfx.text("Ваша рука:",6,191,"#FFFFFF",0.75)
  local maxShow=7
  for i,c in ipairs(hand) do
    if i<=maxShow then
      local x=5+(i-1)*21
      drawCard(x,205,25,36,c,true)
      if selected==i then gfx.border(x-1,203,27,40,4,"#F4D98B") end
    end
  end
  if #hand>maxShow then gfx.text("+"..(#hand-maxShow),145,216,"#FFFFFF",0.7) end
  if ui.button(5,249,46,24,"Атака","primary") then
    if not isHost and not myTurn then notify("Сейчас не ваш ход.")
    elseif #hand==0 then notify("Нет карт.")
    elseif pendingAction=="attack" then
      if isHost then doAction(localPlayer,"attack",selected)
      else net.send(hostName,{kind="action",action="attack",card=selected}) end
      pendingAction=nil
    else
      pendingAction="attack"
      notify("Выбери карту в руке, затем нажми «Атака» ещё раз.")
    end
  end
  if ui.button(56,249,46,24,"Бито","normal") then
    if isHost then doAction(localPlayer,"beat",selected) else net.send(hostName,{kind="action",action="beat",card=selected}) end
  end
  if ui.button(107,249,48,24,"Взять","danger") then
    if isHost then doAction(localPlayer,"take",nil) else net.send(hostName,{kind="action",action="take"}) end
  end
  if ui.button(5,277,150,20,"Обновить состояние","normal") then
    if isHost then sendState() else net.send(hostName,{kind="sync",room=roomCode}) end
  end
end
function onStart()
  math.randomseed(time.now())
  screen.title("Дурак онлайн")
  screen.captureKeys(true)
  screenName="menu"
end
function onShow() end
function onHide() end
function onBack()
  if screenName~="menu" then screenName="menu"; return true end
  return false
end
function onClick(x,y,button)
  if screenName=="game" and y>=200 and y<245 then
    local idx=math.floor((x-5)/21)+1
    if idx>=1 and idx<=#hand and idx<=7 then selected=idx end
  end
end
function onMessage(from,data)
  if type(data)~="table" then return end
  if data.kind=="join" and isHost and data.room==roomCode then
    addPlayer(from)
  elseif data.kind=="lobby" and not isHost then
    if data.room==roomCode then
      hostName=data.host or from
      lobbyNames=data.names or {hostName,localPlayer}
      status="Подключено к комнате. Ожидаем ведущего."
    end
  elseif data.kind=="error" then
    notify(data.text or "Ошибка.")
  elseif data.kind=="state" and not isHost then
    players=data.players or players
    tableCards=data.table or {}
    deckCount=data.deck or deckCount
    trump=data.trump or trump
    phase=data.phase or phase
    status=data.status or status
    gameOver=data.gameOver or false
    if data.hand then hand=data.hand end
    screenName="game"
  elseif data.kind=="private" and not isHost then
    hand=data.hand or hand
    myTurn=data.myTurn or false
    screenName="game"
  elseif data.kind=="action" and isHost then
    doAction(from,data.action,data.card)
  elseif data.kind=="sync" and isHost then
    sendState()
    local p=findPlayer(from)
    if p then net.send(from,{kind="private",hand=p.hand,myTurn=(players[1] and players[1].name==from)}) end
  end
end
function doAction(name,action,cardIndex)
  if not isHost then return end
  local p,pi=findPlayer(name)
  if not p then return end
  if action=="attack" then
    if players[1] and players[1].name~=name and #tableCards==0 then net.send(name,{kind="error",text="Сейчас ход другого игрока."}); return end
    local c=p.hand[tonumber(cardIndex or selected) or 1]
    if not c then return end
    if #tableCards>0 and not hasRankOnTable(c) then net.send(name,{kind="error",text="Можно подкинуть только карту совпадающего достоинства."}); return end
    tableCards[#tableCards+1]={a=c,attacker=name}
    table.remove(p.hand,tonumber(cardIndex or selected) or 1)
    status=name.." атакует "..cardText(c)
  elseif action=="beat" then
    local last=tableCards[#tableCards]
    if not last or last.b then return end
    if not p.hand[tonumber(cardIndex or selected) or 1] then return end
    local c=p.hand[tonumber(cardIndex or selected) or 1]
    if not beats(c,last.a) then net.send(name,{kind="error",text="Этой картой нельзя побить."}); return end
    last.b=c; table.remove(p.hand,tonumber(cardIndex or selected) or 1)
    status=name.." побил "..cardText(last.a)
  elseif action=="take" then
    for _,pair in ipairs(tableCards) do
      p.hand[#p.hand+1]=pair.a
      if pair.b then p.hand[#p.hand+1]=pair.b end
    end
    tableCards={}
    status=name.." берёт карты."
  end
  -- Draw up to six cards in turn order, starting with attacker.
  if deck and #deck>0 then
    for _,pl in ipairs(players) do
      while #pl.hand<6 and #deck>0 do pl.hand[#pl.hand+1]=table.remove(deck,1) end
    end
    deckCount=#deck
  end
  local pub=publicState()
  for _,pl in ipairs(players) do
    if pl.name==localPlayer then hand=copy(pl.hand); myTurn=(players[1] and players[1].name==localPlayer)
    else
      net.send(pl.name,pub)
      net.send(pl.name,{kind="private",hand=pl.hand,myTurn=(players[1] and players[1].name==pl.name)})
    end
  end
end
function onTick()
  if isHost and time.now()-lastSync>1500 then
    lastSync=time.now()
    sendState()
  end
end
function onDraw(dt)
  W,H=screen.width(),screen.height()
  if screenName=="menu" then drawMenu()
  elseif screenName=="lobby" then drawLobby()
  else drawGame() end
end
